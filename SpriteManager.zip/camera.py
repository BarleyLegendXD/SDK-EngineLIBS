import math
import random

from . import anim
from . import controls as ctl
from . import util


class Camera:
    def __init__(self, manager, name, **cfg):
        self.manager = manager
        self.name = name
        self.x = 0.0
        self.y = 0.0
        self.zoom = 1.0
        self.rotation = 0.0
        self.min_zoom = 0.05
        self.max_zoom = 64.0
        self.target = None
        self.smooth = 8.0
        self.offset = (0.0, 0.0)
        self.deadzone = None
        self.lookahead = 0.0
        self.bounds = None
        self.wheel_zoom = False
        self.wheel_step = 1.1
        self.pan_button = None
        self.pixel_snap = False
        self.time = 0.0
        self.tweens = anim.TweenList(manager.call if manager else None)
        self._shake = None
        self.vx = 0.0
        self.vy = 0.0
        self.vzoom = 1.0
        self.vrot = 0.0
        if cfg:
            self.configure(**cfg)

    @property
    def alive(self):
        return True

    @property
    def pos(self):
        return (self.x, self.y)

    @pos.setter
    def pos(self, value):
        self.x, self.y = float(value[0]), float(value[1])

    @property
    def hints(self):
        return self.manager.hints if self.manager else None

    def configure(self, **cfg):
        h = self.hints
        who = f"camera '{self.name}'"
        for key, val in cfg.items():
            if key in ("x", "y", "zoom", "rotation", "min_zoom", "max_zoom", "smooth", "lookahead", "wheel_step"):
                if isinstance(val, bool) or not isinstance(val, (int, float)):
                    if h:
                        h.bad_value(who, key, val, "a number", f"{key}=2.0")
                    continue
                setattr(self, key, float(val))
            elif key == "pos":
                v = util.parse_vec2(val)
                if v is None:
                    if h:
                        h.bad_value(who, key, val, "(x, y)", "pos=(100, 50)")
                else:
                    self.x, self.y = v
            elif key in ("offset", "deadzone"):
                if val is None and key == "deadzone":
                    self.deadzone = None
                    continue
                v = util.parse_vec2(val)
                if v is None:
                    if h:
                        h.bad_value(who, key, val, "(width, height)" if key == "deadzone" else "(x, y)", f"{key}=(120, 80)")
                else:
                    setattr(self, key, v)
            elif key == "bounds":
                if val in (None, False):
                    self.bounds = None
                    continue
                r = util.parse_rect4(val)
                if r is None or r[0] >= r[2] or r[1] >= r[3]:
                    if h:
                        h.bad_value(who, key, val, "(min_x, min_y, max_x, max_y) with min < max", "bounds=(-2000, -1500, 2000, 1500)")
                else:
                    self.bounds = r
            elif key in ("wheel_zoom", "pixel_snap"):
                setattr(self, key, bool(val))
            elif key == "pan_button":
                if val in (None, False):
                    self.pan_button = None
                else:
                    b = ctl.button_code(val)
                    if b is None:
                        if h:
                            h.bad_value(who, key, val, "'left', 'right', 'middle' or 0/1/2", "pan_button='middle'")
                    else:
                        self.pan_button = b
            elif key in ("follow", "target"):
                self.follow(val)
            else:
                if h:
                    known = ("x", "y", "pos", "zoom", "rotation", "min_zoom", "max_zoom", "smooth", "offset", "deadzone",
                             "lookahead", "bounds", "wheel_zoom", "wheel_step", "pan_button", "pixel_snap", "follow")
                    near = util.close(key, known)
                    h.warn(("camcfg", key), f"unknown camera setting '{key}' for {who}",
                           ("did you mean: " + ", ".join(near)) if near else "valid: " + ", ".join(known))
        if self.min_zoom > self.max_zoom:
            self.min_zoom, self.max_zoom = self.max_zoom, self.min_zoom
        self.refresh()
        return self

    def refresh(self):
        if self.manager is not None:
            size = self.manager.engine.screen_size
            if size[0] > 0 and size[1] > 0:
                self.update(0.0, size)

    def follow(self, target=None, smooth=None, offset=None, deadzone=None, lookahead=None, snap=False):
        h = self.hints
        if isinstance(target, str) and self.manager is not None:
            found = self.manager.sprites.get(target)
            if found is None:
                if h:
                    h.no_such_name("sprite", target, self.manager.sprites.keys())
                return self
            target = found
        if target is None or target is False:
            self.target = None
            return self
        if target is True or not hasattr(target, "center"):
            if h:
                h.warn(("follow", self.name), f"camera '{self.name}'.follow() needs a sprite or a sprite name, got {target!r}",
                       "example: camera.follow(hero)  or  camera.follow('hero')")
            return self
        self.target = target
        if smooth is not None:
            self.smooth = float(smooth)
        if offset is not None:
            v = util.parse_vec2(offset)
            if v:
                self.offset = v
        if deadzone is not None:
            self.deadzone = util.parse_vec2(deadzone)
        if lookahead is not None:
            self.lookahead = float(lookahead)
        if snap:
            cx, cy = target.center
            self.x = cx + self.offset[0]
            self.y = cy + self.offset[1]
            self.refresh()
        return self

    def unfollow(self):
        self.target = None
        return self

    def look_at(self, x, y):
        self.x, self.y = float(x), float(y)
        self.refresh()
        return self

    def reset(self):
        self.x = self.y = 0.0
        self.zoom = 1.0
        self.rotation = 0.0
        self.target = None
        self._shake = None
        self.tweens.clear()
        self.refresh()
        return self

    def _tween(self, props, duration, ease, on_done, delay):
        fn = anim.get_ease(ease)
        if fn is None:
            h = self.hints
            if h:
                h.warn(("ease", str(ease)), f"unknown easing '{ease}' on camera '{self.name}'",
                       "did you mean: " + ", ".join(util.close(ease, anim.EASINGS)) if util.close(ease, anim.EASINGS) else "examples: linear, in_out_cubic, out_back, out_bounce",
                       "'in_out_cubic' is used instead")
            fn = anim.EASINGS["in_out_cubic"]
        if duration <= 0:
            for k, v in props.items():
                setattr(self, k, float(v))
            self.refresh()
            if on_done is not None:
                self.manager.call(on_done, self.name, "camera done", self)
            return None
        return self.tweens.add(anim.Tween(self, props, duration, fn, delay, on_done))

    def move_to(self, x, y, duration=0.6, ease="in_out_cubic", on_done=None, delay=0.0):
        self.target = None
        return self._tween({"x": x, "y": y}, duration, ease, on_done, delay)

    def zoom_to(self, zoom, duration=0.5, ease="in_out_cubic", on_done=None, delay=0.0):
        return self._tween({"zoom": util.clamp(float(zoom), self.min_zoom, self.max_zoom)}, duration, ease, on_done, delay)

    def rotate_to(self, degrees, duration=0.5, ease="in_out_cubic", on_done=None, delay=0.0):
        return self._tween({"rotation": degrees}, duration, ease, on_done, delay)

    def punch(self, amount=0.08, duration=0.18):
        base = self.zoom
        self.zoom = base * (1.0 + amount)
        return self._tween({"zoom": base}, duration, "out_cubic", None, 0.0)

    def shake(self, intensity=12.0, duration=0.35, frequency=28.0, rotation=0.0, decay="out_quad"):
        h = self.hints
        if intensity <= 0 or duration <= 0:
            if h:
                h.warn(("shake0", self.name), f"camera.shake(intensity={intensity}, duration={duration}) does nothing",
                       "both values must be above zero", "example: camera.shake(14, 0.4)  (intensity is in screen pixels)")
            return self
        fn = anim.get_ease(decay) or anim.EASINGS["out_quad"]
        cur = 0.0
        if self._shake:
            s = self._shake
            cur = s["i"] * (1.0 - s["ease"](min(1.0, s["t"] / s["d"])))
        if intensity >= cur:
            self._shake = {"i": float(intensity), "d": float(duration), "t": 0.0, "f": float(frequency),
                           "r": float(rotation), "ease": fn, "seed": random.random() * 100.0}
        return self

    def _shake_offset(self, dt):
        s = self._shake
        if not s:
            return 0.0, 0.0, 0.0
        s["t"] += dt
        p = s["t"] / s["d"]
        if p >= 1.0:
            self._shake = None
            return 0.0, 0.0, 0.0
        k = 1.0 - s["ease"](p)
        a = s["t"] * s["f"] + s["seed"]
        ox = (math.sin(a * 2.1) + 0.5 * math.sin(a * 4.7 + 1.3)) / 1.5
        oy = (math.sin(a * 1.7 + 2.0) + 0.5 * math.sin(a * 5.3 + 0.4)) / 1.5
        orr = math.sin(a * 2.9 + 0.8)
        return ox * s["i"] * k, oy * s["i"] * k, orr * s["r"] * k

    def _half_view(self, size):
        z = self.zoom if self.zoom > 0 else 1.0
        hw, hh = size[0] / (2.0 * z), size[1] / (2.0 * z)
        if self.rotation:
            r = math.radians(self.rotation)
            c, s = abs(math.cos(r)), abs(math.sin(r))
            hw, hh = hw * c + hh * s, hw * s + hh * c
        return hw, hh

    def _clamp(self, size):
        b = self.bounds
        if not b:
            return
        hw, hh = self._half_view(size)
        x0, y0, x1, y1 = b
        self.x = (x0 + x1) * 0.5 if x1 - x0 <= 2 * hw else min(max(self.x, x0 + hw), x1 - hw)
        self.y = (y0 + y1) * 0.5 if y1 - y0 <= 2 * hh else min(max(self.y, y0 + hh), y1 - hh)

    def update(self, dt, size):
        self.time += dt
        self.tweens.update(dt)
        t = self.target
        if t is not None:
            if not t.alive:
                self.target = None
                h = self.hints
                if h:
                    h.tip(("camlost", self.name), f"camera '{self.name}' lost its follow target '{t.name}' (it was destroyed)",
                          "the camera stays where it is, call camera.follow(other_sprite) to attach it again")
            elif not self.tweens.busy(self, ("x", "y")):
                cx, cy = t.center
                tx = cx + self.offset[0] + t.vx * self.lookahead
                ty = cy + self.offset[1] + t.vy * self.lookahead
                if self.deadzone:
                    hw, hh = self.deadzone[0] * 0.5, self.deadzone[1] * 0.5
                    dx, dy = tx - self.x, ty - self.y
                    wx = self.x if abs(dx) <= hw else tx - math.copysign(hw, dx)
                    wy = self.y if abs(dy) <= hh else ty - math.copysign(hh, dy)
                else:
                    wx, wy = tx, ty
                k = 1.0 if self.smooth <= 0 else 1.0 - math.exp(-self.smooth * dt)
                self.x += (wx - self.x) * k
                self.y += (wy - self.y) * k
        self.zoom = util.clamp(self.zoom, self.min_zoom, self.max_zoom)
        self._clamp(size)
        ox, oy, orr = self._shake_offset(dt)
        z = self.zoom
        vx = self.x + ox / z
        vy = self.y + oy / z
        if self.pixel_snap:
            vx = round(vx * z) / z
            vy = round(vy * z) / z
        self.vx, self.vy, self.vzoom = vx, vy, z
        self.vrot = math.radians(self.rotation + orr)

    def view(self):
        return (self.vx, self.vy, self.vzoom, self.vrot)

    def screen_to_world(self, px, py, size):
        sx = px - size[0] * 0.5
        sy = size[1] * 0.5 - py
        z = self.vzoom if self.vzoom else 1.0
        c, s = math.cos(self.vrot), math.sin(self.vrot)
        dx, dy = sx / z, sy / z
        return (self.vx + c * dx - s * dy, self.vy + s * dx + c * dy)

    def world_to_screen(self, wx, wy, size):
        z = self.vzoom if self.vzoom else 1.0
        c, s = math.cos(self.vrot), math.sin(self.vrot)
        dx, dy = wx - self.vx, wy - self.vy
        sx = (c * dx + s * dy) * z
        sy = (-s * dx + c * dy) * z
        return (sx + size[0] * 0.5, size[1] * 0.5 - sy)

    def visible_rect(self, size):
        z = self.vzoom if self.vzoom else 1.0
        hw, hh = size[0] / (2.0 * z), size[1] / (2.0 * z)
        if self.vrot:
            c, s = abs(math.cos(self.vrot)), abs(math.sin(self.vrot))
            hw, hh = hw * c + hh * s, hw * s + hh * c
        return (self.vx - hw, self.vy - hh, self.vx + hw, self.vy + hh)

    def zoom_at(self, factor, px, py, size):
        new = util.clamp(self.zoom * factor, self.min_zoom, self.max_zoom)
        if new == self.zoom:
            return
        self.tweens.clear(self)
        before = self.screen_to_world(px, py, size)
        self.zoom = new
        self.vzoom = new
        after = self.screen_to_world(px, py, size)
        if self.target is None:
            self.x += before[0] - after[0]
            self.y += before[1] - after[1]

    def pan_screen(self, dx_px, dy_px):
        if self.target is not None:
            self.target = None
            h = self.hints
            if h:
                h.tip(("panfollow", self.name), f"panning detached camera '{self.name}' from its follow target",
                      "call camera.follow(sprite) again to re-attach it")
        z = self.vzoom if self.vzoom else 1.0
        c, s = math.cos(self.vrot), math.sin(self.vrot)
        sx, sy = dx_px / z, -dy_px / z
        self.x -= c * sx - s * sy
        self.y -= s * sx + c * sy
