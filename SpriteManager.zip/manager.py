import inspect
import math
import os
import random
import traceback

import glfw

from . import anim
from . import controls as ctl
from . import util
from .camera import Camera
from .hints import Hints
from .render import Renderer
from .sprite import ALIASES, CLICK_EVENTS, ENTITY_KEYS, KIND_PRESETS, PARAMS, ClickInfo, Sprite

IMG_EXT = (".png", ".jpg", ".jpeg", ".bmp", ".tga", ".gif", ".webp")


def _sort_key(s):
    return (1 if s.fixed else 0, s.layer, -(s.y + s.sort_offset) if s.ysort else 0.0)


def _draw_key(s):
    return (s.layer, -(s.y + s.sort_offset) if s.ysort else 0.0)


def _span(v, default):
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        return (float(v), float(v))
    if isinstance(v, (list, tuple)) and len(v) == 2:
        return (float(v[0]), float(v[1]))
    return default


class SpriteManager:
    def __init__(self, engine):
        self.engine = engine
        self.hints = Hints(engine)
        self.renderer = Renderer(engine.ctx)
        self.sprites = {}
        self.kinds = {k: dict(v) for k, v in KIND_PRESETS.items()}
        self.templates = {}
        self.input = ctl.Input()
        self.cameras = {}
        self.camera = None
        self.tweens = anim.TweenList(self.call)
        self.world = None
        self.world_clamp = None
        self.solids = []
        self.world_cbs = []
        self.binds = []
        self.smooth = True
        self.hover = None
        self.pressed = {}
        self.drag = None
        self.mouse = (0.0, 0.0)
        self.mouse_fb = (0.0, 0.0)
        self.mouse_ui = (0.0, 0.0)
        self.mouse_over_ui = False
        self.frame = 0
        self.stats = (0, 0, 0)
        self._dead = []
        self._errors = set()
        self._arity = {}
        self._counter = 0
        self._last_fb = None
        self.camera = self.cam("main")
        e = engine
        e.on("update", self._on_update, priority=-50)
        e.on("draw", self._on_draw, priority=50)
        e.on("key", self._on_key)
        e.on("mouse_button", self._on_button)
        e.on("scroll", self._on_scroll)
        e.on("focus", self._on_focus)

    def shutdown(self):
        self.renderer.release()
        self.sprites.clear()
        self.binds.clear()
        self.world_cbs.clear()

    def call(self, fn, who, ev, *args):
        key = id(fn)
        hit = self._arity.get(key)
        if hit is None or hit[0] is not fn:
            n = 0
            try:
                sig = inspect.signature(fn)
            except (TypeError, ValueError):
                n = None
            else:
                for prm in sig.parameters.values():
                    if prm.kind == prm.VAR_POSITIONAL:
                        n = None
                        break
                    if prm.kind in (prm.POSITIONAL_ONLY, prm.POSITIONAL_OR_KEYWORD):
                        n += 1
            hit = (fn, n)
            self._arity[key] = hit
        n = hit[1]
        try:
            return fn(*args) if n is None else fn(*args[:n])
        except Exception as exc:
            self._report(who, ev, fn, exc)
            return None

    def _report(self, who, ev, fn, exc):
        key = (ev, id(fn), type(exc).__name__, str(exc))
        if key in self._errors:
            return
        self._errors.add(key)
        name = getattr(fn, "__name__", "callback")
        self.engine.log(f"[SpriteManager] ERROR in '{ev}' callback '{name}' of {who}: {type(exc).__name__}: {exc}", (255, 85, 85))
        traceback.print_exception(type(exc), exc, exc.__traceback__)
        self.hints.tip(("cb", key), "the error is inside YOUR function, the engine keeps running",
                       "the same error is not repeated, fix it and restart", "full traceback is printed in the real console")

    def cam(self, name=None, **cfg):
        if name is None:
            if cfg:
                self.camera.configure(**cfg)
            return self.camera
        c = self.cameras.get(name)
        if c is None:
            c = Camera(self, name)
            self.cameras[name] = c
            if self.world is not None:
                c.bounds = self.world
        if cfg:
            c.configure(**cfg)
        return c

    def use_camera(self, cam):
        if isinstance(cam, str):
            if cam not in self.cameras:
                self.hints.no_such_name("camera", cam, self.cameras.keys())
                return self.camera
            cam = self.cameras[cam]
        self.camera = cam
        cam.refresh()
        return cam

    def set_world(self, width, height, x=0.0, y=0.0, clamp_entities=True, camera_bounds=True):
        if width <= 0 or height <= 0:
            self.hints.bad_value("set_world", "size", (width, height), "positive width and height", "sm.set_world(4000, 3000)")
            return self
        self.world = (x - width / 2.0, y - height / 2.0, x + width / 2.0, y + height / 2.0)
        self.world_clamp = self.world if clamp_entities else None
        if camera_bounds:
            for c in self.cameras.values():
                c.bounds = self.world
                c.refresh()
        return self

    def register_kind(self, name, **defaults):
        for k in defaults:
            if ALIASES.get(k, k) not in PARAMS and k != "kind":
                self.hints.unknown_param(f"kind '{name}'", k, PARAMS.keys())
        base = defaults.pop("base", None)
        preset = dict(self.kinds.get(base, {})) if base else {}
        preset.update(defaults)
        self.kinds[name] = preset
        return self

    def help(self):
        self.hints.params(PARAMS)
        self.hints.tip("help2", "other things you can do",
                       "sm = engine.sprite_manager()   sm.camera.follow(hero)   sm.camera.shake(12, 0.4)",
                       "sm.on_world_click(lambda x, y: ...)   sm.bind('space', fn)   sm.burst(x, y)",
                       "sm.template('coin', 'coin.png', ...)   sm.spawn('coin', x=10, y=5)")

    def create(self, name=None, texture=None, **params):
        h = self.hints
        if name is not None and not isinstance(name, str):
            h.warn("namestr", f"sprite name should be a string, got {name!r}",
                   "example: engine.sprite('hero', 'hero.png')", "it was converted with str()")
            name = str(name)
        if isinstance(name, str) and texture is None and "texture" not in params and "image" not in params \
                and "img" not in params and name.lower().endswith(IMG_EXT):
            stem = os.path.splitext(os.path.basename(name))[0]
            h.warn(("namefile", name), f"'{name}' looks like a texture file but was passed as the sprite NAME",
                   f"the signature is engine.sprite(name, texture, ...), so I treated it as engine.sprite('{stem}', '{name}')")
            texture, name = name, stem
        p = {}
        for k, v in params.items():
            if k not in ALIASES:
                p[k] = v
        for k, v in params.items():
            if k in ALIASES:
                p.setdefault(ALIASES[k], v)
        if "texture" in p:
            if texture is None:
                texture = p["texture"]
            p.pop("texture")
        kind = p.pop("kind", None)
        if kind is None:
            guess = [k for k in ENTITY_KEYS if k in p]
            kind = "entity" if guess else "static"
            if guess:
                h.tip(("guess", guess[0]), f"kind was not set, so sprite '{name}' became an 'entity' because of '{guess[0]}'",
                      "pass kind='static' to keep it fixed, or kind='entity' to silence this tip")
        if kind not in self.kinds:
            near = util.close(kind, self.kinds.keys())
            h.warn(("kind", str(kind)), f"unknown kind '{kind}'",
                   ("did you mean: " + ", ".join(near)) if near else "known kinds: " + ", ".join(self.kinds),
                   "add your own with sm.register_kind('name', layer=5, ...)", "'static' is used instead")
            kind = "static"
        if name is None:
            self._counter += 1
            name = f"{kind}_{self._counter}"
        existing = self.sprites.get(name)
        if existing is not None and existing.alive:
            n = 2
            while f"{name}_{n}" in self.sprites:
                n += 1
            h.warn(("dup", name), f"a sprite named '{name}' already exists",
                   f"the new one is called '{name}_{n}' so sm.get('{name}') still returns the first one",
                   "destroy the old sprite first if you wanted to replace it")
            name = f"{name}_{n}"
        merged = dict(self.kinds[kind])
        merged.update(p)
        merged["kind"] = kind
        sp = Sprite(self, name, texture, merged)
        self.sprites[name] = sp
        count = len(self.sprites)
        if count == 5000:
            h.tip("many5k", "5000 sprites alive", "rendering is batched per texture so this is fine, but sorting and updating are done in Python",
                  "use kind='static' for scenery, active=False for far objects, and life= for effects")
        elif count == 20000:
            h.warn("many20k", "20000 sprites alive", "frame time will suffer; destroy sprites that left the world or merge scenery into one big sprite with tile=")
        if sp.pending_keys:
            if isinstance(sp.pending_keys, dict):
                for k, fn in sp.pending_keys.items():
                    self.bind(k, fn, "press", owner=sp)
            else:
                h.bad_value(f"sprite '{name}'", "on_key", sp.pending_keys, "a dict {key: function}", "on_key={'space': jump}")
        if sp.camera_spec not in (None, False):
            self._bind_camera(sp, sp.camera_spec)
        sp.fire("create")
        return sp

    def _bind_camera(self, sp, spec):
        h = self.hints
        cam = self.camera
        cfg = {}
        if isinstance(spec, dict):
            cfg = dict(spec)
            nm = cfg.pop("name", None)
            if nm:
                cam = self.cam(nm)
        elif isinstance(spec, str):
            cam = self.cam(spec)
        elif isinstance(spec, Camera):
            cam = spec
        elif spec is not True:
            h.bad_value(f"sprite '{sp.name}'", "camera", spec, "True, a camera name, or a dict of camera settings", "camera={'zoom': 2, 'smooth': 6}")
            return
        if cam is not self.camera:
            self.use_camera(cam)
        if cfg:
            cam.configure(**cfg)
        cam.follow(sp, snap=True)

    def template(self, key, texture=None, **params):
        self.templates[key] = (texture, params)
        return self

    def spawn(self, key, name=None, **overrides):
        t = self.templates.get(key)
        if t is None:
            self.hints.no_such_name("template", key, self.templates.keys())
            return None
        params = dict(t[1])
        params.update(overrides)
        texture = params.pop("texture", t[0])
        if name is None:
            self._counter += 1
            name = f"{key}_{self._counter}"
        return self.create(name, texture, **params)

    def burst(self, x=0.0, y=0.0, count=12, texture=None, color="white", speed=(60, 240), life=(0.4, 0.9),
              size=(5, 11), gravity=(0, 0), spread=360.0, angle=0.0, layer=50, fade=True, shrink=True, **extra):
        smin, smax = _span(speed, (60.0, 240.0))
        lmin, lmax = _span(life, (0.4, 0.9))
        zmin, zmax = _span(size, (5.0, 11.0))
        out = []
        for _ in range(int(count)):
            a = math.radians(angle + random.uniform(-spread / 2.0, spread / 2.0))
            sp = random.uniform(smin, smax)
            col = random.choice(color) if isinstance(color, list) else color
            z = random.uniform(zmin, zmax)
            out.append(self.create(None, texture, kind="particle", x=x, y=y, size=(z, z), color=col,
                                   velocity=(math.cos(a) * sp, math.sin(a) * sp), life=random.uniform(lmin, lmax),
                                   gravity=gravity, layer=layer, fade_out=fade, shrink=shrink, **extra))
        return out

    def get(self, name):
        s = self.sprites.get(name)
        if s is None or not s.alive:
            self.hints.no_such_name("sprite", name, [n for n, v in self.sprites.items() if v.alive])
            return None
        return s

    def all(self):
        return [s for s in self.sprites.values() if s.alive]

    def find(self, tag=None, kind=None, where=None):
        out = []
        for s in self.sprites.values():
            if not s.alive:
                continue
            if tag is not None and tag not in s.tags:
                continue
            if kind is not None and s.kind != kind:
                continue
            if where is not None and not where(s):
                continue
            out.append(s)
        return out

    def remove(self, target):
        s = self.get(target) if isinstance(target, str) else target
        if s is not None:
            s.destroy()
        return self

    def clear(self, kind=None, tag=None):
        for s in self.find(tag=tag, kind=kind):
            s.destroy()
        return self

    def _mark_dead(self, sp):
        self._dead.append(sp)
        self.binds = [b for b in self.binds if b[3] is not sp]
        for k in [k for k, v in self.pressed.items() if v is sp]:
            del self.pressed[k]
        if self.hover is sp:
            self.hover = None
        if self.drag and self.drag["sprite"] is sp:
            self.drag = None

    def _cleanup(self):
        if not self._dead:
            return
        for sp in self._dead:
            if self.sprites.get(sp.name) is sp:
                del self.sprites[sp.name]
        self._dead = []

    def bind(self, key, fn, event="press", owner=None):
        codes = ctl.key_codes(key)
        if not codes:
            near = util.close(key, ctl.key_names())
            self.hints.warn(("key", str(key)), f"unknown key '{key}'",
                            ("did you mean: " + ", ".join(near)) if near else "examples: 'space', 'enter', 'escape', 'f1', 'a', 'left_shift'")
            return self
        if event not in ("press", "release"):
            self.hints.warn(("keyev", str(event)), f"unknown key event '{event}'", "use 'press' or 'release'")
            return self
        if not callable(fn):
            self.hints.bad_value("bind", "fn", fn, "a function", "sm.bind('space', lambda: print('jump'))")
            return self
        self.binds.append((codes, event, fn, owner))
        return self

    def unbind(self, fn):
        self.binds = [b for b in self.binds if b[2] is not fn]
        return self

    def on_world_click(self, fn=None, button=0, always=False):
        def add(f):
            b = None if button in (None, "any") else ctl.button_code(button)
            if b is None and button not in (None, "any"):
                self.hints.bad_value("on_world_click", "button", button, "'left', 'right', 'middle', 0, 1, 2 or None", "button='left'")
                return f
            self.world_cbs.append((f, b, always))
            return f
        return add(fn) if fn is not None else add

    def screen_to_world(self, px, py):
        return self.camera.screen_to_world(px, py, self.engine.screen_size)

    def world_to_screen(self, x, y):
        return self.camera.world_to_screen(x, y, self.engine.screen_size)

    def _sprite_point(self, s):
        if s.fixed:
            return self.mouse_ui
        c = self.camera
        return (self.mouse[0] - c.vx * (1.0 - s.parallax_x), self.mouse[1] - c.vy * (1.0 - s.parallax_y))

    def _pick_at(self, world_pt, ui_pt, clickable_only):
        c = self.camera
        cands = [s for s in self.sprites.values()
                 if s.alive and s.visible and not s.pending and (s._clickable or not clickable_only)]
        cands.sort(key=_sort_key)
        for s in reversed(cands):
            if s.fixed:
                pt = ui_pt
            elif s.parallax_x == 1.0 and s.parallax_y == 1.0:
                pt = world_pt
            else:
                pt = (world_pt[0] - c.vx * (1.0 - s.parallax_x), world_pt[1] - c.vy * (1.0 - s.parallax_y))
            if s.hit(pt[0], pt[1]):
                return s
        return None

    def pick(self, x, y, clickable_only=False):
        return self._pick_at((x, y), (x, y), clickable_only)

    def _poll_mouse(self, size):
        try:
            mx, my = glfw.get_cursor_pos(self.engine.window)
        except Exception:
            return
        ww, wh = self.engine.window_size
        fx = mx * size[0] / ww if ww > 0 else mx
        fy = my * size[1] / wh if wh > 0 else my
        self.mouse_fb = (fx, fy)
        self.mouse_ui = (fx - size[0] * 0.5, size[1] * 0.5 - fy)
        self.mouse = self.camera.screen_to_world(fx, fy, size)

    def _info(self, sp, button):
        pt = self._sprite_point(sp)
        return ClickInfo(pt[0], pt[1], button, sp, self.mouse_fb)

    def _on_key(self, ev):
        key, action = ev["key"], ev["action"]
        self.input.key_event(key, action)
        if action == glfw.REPEAT:
            return
        kind = "press" if action == glfw.PRESS else "release"
        for codes, event, fn, owner in list(self.binds):
            if event == kind and key in codes and (owner is None or owner.alive):
                self.call(fn, owner.name if owner else "bind", "key " + kind, *((owner,) if owner else ()))

    def _on_focus(self, ev):
        if not ev.get("focused", True):
            self.input.clear()
            self.pressed.clear()
            self.drag = None

    def _on_scroll(self, ev):
        size = self.engine.screen_size
        cam = self.camera
        if cam.wheel_zoom and size[0] > 0:
            self._poll_mouse(size)
            cam.zoom_at(cam.wheel_step ** ev["dy"], self.mouse_fb[0], self.mouse_fb[1], size)

    def _on_button(self, ev):
        b, a = ev["button"], ev["action"]
        self.input.button_event(b, a)
        size = self.engine.screen_size
        if size[0] <= 0 or size[1] <= 0:
            return
        self._poll_mouse(size)
        if a == glfw.PRESS:
            self._press(b)
        elif a == glfw.RELEASE:
            self._release(b)

    def _press(self, b):
        hit = self._pick_at(self.mouse, self.mouse_ui, True)
        wx, wy = self.mouse
        if hit is not None:
            self.pressed[b] = hit
            info = self._info(hit, b)
            hit.fire("press", info)
            if b == 0 and hit.draggable:
                self.drag = {"sprite": hit, "dx": hit.x - info.x, "dy": hit.y - info.y, "moved": False}
        consumed = hit is not None
        for fn, button, always in list(self.world_cbs):
            if (button is None or button == b) and (always or not consumed):
                self.call(fn, "world click", "world_click", wx, wy, b, hit)
        if not consumed and b == 0:
            for s in list(self.sprites.values()):
                if s.alive and s.physics and s.controls is not None and s.controls.click:
                    s.move_to(wx, wy)

    def _release(self, b):
        moved = False
        if self.drag and b == 0:
            d, self.drag = self.drag, None
            moved = d["moved"]
            if d["sprite"].alive:
                d["sprite"].fire("drop", self._info(d["sprite"], b))
        hit = self.pressed.pop(b, None)
        if hit is None or not hit.alive:
            return
        info = self._info(hit, b)
        hit.fire("release", info)
        if not moved and self._pick_at(self.mouse, self.mouse_ui, True) is hit:
            if b == 0:
                hit.fire("click", info)
            elif b == 1:
                hit.fire("right_click", info)

    def _drag_and_hover(self):
        d = self.drag
        if d is not None:
            s = d["sprite"]
            if not s.alive or 0 not in self.input.buttons:
                self.drag = None
            else:
                pt = self._sprite_point(s)
                nx, ny = pt[0] + d["dx"], pt[1] + d["dy"]
                if nx != s.x or ny != s.y:
                    s.x, s.y = nx, ny
                    d["moved"] = True
                    s.fire("drag", self._info(s, 0))
                return
        hit = self._pick_at(self.mouse, self.mouse_ui, True)
        self.mouse_over_ui = bool(hit is not None and hit.fixed)
        if hit is not self.hover:
            old, self.hover = self.hover, hit
            if old is not None and old.alive:
                old.fire("leave")
            if hit is not None:
                hit.fire("hover")

    def _overlaps(self):
        listeners = [s for s in self.sprites.values() if s.alive and "overlap" in s.handlers]
        if not listeners:
            return
        everyone = [s for s in self.sprites.values() if s.alive]
        for s in listeners:
            if not s.alive:
                continue
            r = s.rect()
            tags = s.overlap_tags
            now = set()
            for o in everyone:
                if o is s or not o.alive:
                    continue
                if tags and not (tags & o.tags):
                    continue
                q = o.rect()
                if r[0] < q[2] and r[2] > q[0] and r[1] < q[3] and r[3] > q[1]:
                    now.add(o)
                    if s.overlap_stay or o not in s._touching:
                        s.fire("overlap", o)
                        if not s.alive:
                            break
            s._touching = now

    def _on_update(self, state):
        dt = state["dt"]
        self.frame += 1
        size = self.engine.screen_size
        ok = size[0] > 0 and size[1] > 0
        inp = self.input
        cam = self.camera
        if ok:
            self._poll_mouse(size)
            if cam.pan_button is not None and cam.pan_button in inp.buttons and self._last_fb is not None and not self.mouse_over_ui:
                cam.pan_screen(self.mouse_fb[0] - self._last_fb[0], self.mouse_fb[1] - self._last_fb[1])
            self._last_fb = self.mouse_fb
        self.solids = [s for s in self.sprites.values() if s.solid and s.alive]
        for s in list(self.sprites.values()):
            if s.alive and s.active:
                s.update(dt, inp)
        self.tweens.update(dt)
        self._overlaps()
        if ok:
            cam.update(dt, size)
            self._poll_mouse(size)
            self._drag_and_hover()
        self._cleanup()
        inp.end_frame()
        self._diagnose(size)

    def _on_draw(self, state):
        size = self.engine.screen_size
        if size[0] <= 0 or size[1] <= 0:
            return
        cam = self.camera
        rect = cam.visible_rect(size)
        world, ui, culled = [], [], 0
        cx, cy = cam.vx, cam.vy
        for s in self.sprites.values():
            if not s.alive or not s.visible or s.pending or s._rgba[3] <= 0.0:
                continue
            if s.fixed:
                ui.append(s)
                continue
            px, py = s.parallax_x, s.parallax_y
            x = s.x if px == 1.0 else s.x + cx * (1.0 - px)
            y = s.y if py == 1.0 else s.y + cy * (1.0 - py)
            r = s.radius()
            if x + r < rect[0] or x - r > rect[2] or y + r < rect[1] or y - r > rect[3]:
                culled += 1
                continue
            world.append(s)
        world.sort(key=_draw_key)
        ui.sort(key=_draw_key)
        self.renderer.calls = 0
        self.renderer.draw(world, cam.view(), size, cx, cy)
        self.renderer.draw(ui, (0.0, 0.0, 1.0, 0.0), size, 0.0, 0.0)
        self.stats = (len(world), len(ui), culled)

    def _diagnose(self, size):
        h = self.hints
        if not h.on:
            return
        if self.frame == 180 and not self.sprites:
            h.tip("nosprites", "no sprites exist after 3 seconds",
                  "create one in your mod: engine.sprite('box', color='red', size=(80, 80))",
                  "mods run from the mods/ folder, look for 'MOD: Injected <name>' in the log",
                  "if your mod printed a MOD Error, the line that creates the sprite never ran")
        if self.frame == 120 and self.sprites and self.stats[0] + self.stats[1] == 0:
            alive = self.all()
            hidden = sum(1 for s in alive if not s.visible)
            clear = sum(1 for s in alive if s._rgba[3] <= 0.0)
            pend = sum(1 for s in alive if s.pending)
            c = self.camera
            lines = [f"{len(alive)} sprites exist but none were drawn: {hidden} hidden, {clear} with alpha 0, {pend} still loading, {self.stats[2]} outside the camera view"]
            if self.stats[2]:
                s0 = next(s for s in alive if s.visible and not s.fixed)
                lines.append(f"camera is at ({c.x:.0f}, {c.y:.0f}) zoom {c.zoom:.2f}; for example '{s0.name}' is at ({s0.x:.0f}, {s0.y:.0f})")
                lines.append("y points UP in this engine, and the camera shows the area around its position (0, 0 is the screen center)")
                lines.append("fix: sprite.pos closer to the camera, camera.look_at(x, y), or camera=True on the sprite to follow it")
            h.warn("invisible", "nothing is visible on screen", *lines)
