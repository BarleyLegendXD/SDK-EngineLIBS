import math

from . import anim
from . import controls as ctl
from . import util

DEG = math.pi / 180.0

EVENTS = ("click", "right_click", "press", "release", "hover", "leave", "drag", "drop",
          "update", "create", "destroy", "collide", "overlap", "anim_end", "arrive")
CLICK_EVENTS = ("click", "right_click", "press", "release", "hover", "leave", "drag", "drop")

ALIASES = {
    "angle": "rotation", "pivot": "origin", "tint": "color", "opacity": "alpha", "z": "layer", "tag": "tags",
    "w": "width", "h": "height", "image": "texture", "img": "texture", "tex": "texture", "position": "pos",
    "vel": "velocity",
}

PARAMS = {
    "kind": ("general", "static, entity, ui, background..."),
    "tags": ("general", "'enemy' or ['enemy','boss'] for find()"),
    "data": ("general", "dict with your own values"),
    "visible": ("general", "False hides the sprite"),
    "active": ("general", "False freezes its update"),
    "life": ("general", "destroy itself after N seconds"),
    "x": ("transform", "world x"),
    "y": ("transform", "world y (up is positive)"),
    "pos": ("transform", "(x, y)"),
    "size": ("transform", "(w, h) or one number"),
    "width": ("transform", "width, height follows the aspect"),
    "height": ("transform", "height, width follows the aspect"),
    "scale": ("transform", "number or (sx, sy)"),
    "rotation": ("transform", "degrees, counter-clockwise"),
    "origin": ("transform", "'center','bottom','topleft'.. or (0.5,0)"),
    "flip_x": ("look", "mirror horizontally"),
    "flip_y": ("look", "mirror vertically"),
    "color": ("look", "tint: 'red', '#ff8800', (255,0,0)"),
    "alpha": ("look", "opacity 0..1"),
    "layer": ("look", "draw order, higher is on top"),
    "ysort": ("look", "lower on screen draws on top"),
    "sort_offset": ("look", "shifts the ysort point"),
    "parallax": ("look", "1 normal, 0.5 slower, 0 sticks to cam"),
    "fixed": ("look", "HUD: screen pixels from center, no cam"),
    "tile": ("look", "repeat texture (nx, ny) times"),
    "scroll": ("look", "(u, v) texture scroll per second"),
    "smooth": ("look", "False = crisp pixel art filtering"),
    "repeat": ("look", "texture wraps instead of clamping"),
    "async_load": ("look", "decode the image in a worker thread"),
    "sheet": ("sheet", "(cols, rows) grid of frames"),
    "frame_size": ("sheet", "(w, h) of one frame in pixels"),
    "frame": ("sheet", "frame index, left to right, top down"),
    "region": ("sheet", "(x, y, w, h) pixel rect of the image"),
    "anims": ("animation", "{'walk': '0-3', 'idle': {'row':1}}"),
    "anim": ("animation", "clip to start with"),
    "fps": ("animation", "default fps of clips (8)"),
    "auto_anim": ("animation", "True or {'idle':..,'move':..}"),
    "auto_flip": ("animation", "True: mirror by move direction"),
    "face_move": ("animation", "True or degree offset: rotate to move"),
    "physics": ("movement", "enable velocity (entities have it)"),
    "speed": ("movement", "pixels per second (200)"),
    "run_key": ("movement", "key that multiplies speed"),
    "run_mult": ("movement", "run speed factor (1.6)"),
    "accel": ("movement", "acceleration, 0 = instant"),
    "friction": ("movement", "slowdown when not steering"),
    "max_speed": ("movement", "velocity cap"),
    "vx": ("movement", "start velocity x"),
    "vy": ("movement", "start velocity y"),
    "velocity": ("movement", "(vx, vy)"),
    "gravity": ("movement", "(gx, gy) acceleration"),
    "controls": ("movement", "'wasd' 'arrows' 'both' 'click' 'mouse'"),
    "move_to": ("movement", "(x, y) walk there on start"),
    "chase": ("movement", "sprite or name to run after"),
    "patrol": ("movement", "[(x,y),...] or {'points':..,'mode':..}"),
    "arrive": ("movement", "arrival distance (2)"),
    "collide": ("collision", "blocked by solid sprites"),
    "solid": ("collision", "blocks colliding entities"),
    "hitbox": ("collision", "(w,h) or (ox,oy,w,h) around center"),
    "bounds": ("collision", "(x0,y0,x1,y1) or False"),
    "overlap_tags": ("collision", "tags that trigger on_overlap"),
    "overlap_stay": ("collision", "on_overlap every frame"),
    "clickable": ("mouse", "auto True when a click handler exists"),
    "draggable": ("mouse", "drag with the left button"),
    "hit_pad": ("mouse", "extra pixels around the click area"),
    "on_key": ("mouse", "{'space': func} key bindings"),
    "camera": ("camera", "True, 'name' or {'zoom':2,'smooth':6}"),
}
for _ev in EVENTS:
    PARAMS["on_" + _ev] = ("events", "callback for '" + _ev + "'")

KIND_PRESETS = {
    "static": {},
    "entity": {"physics": True, "collide": True},
    "ui": {"fixed": True, "layer": 1000},
    "background": {"layer": -1000},
}

ENTITY_KEYS = ("controls", "speed", "vx", "vy", "velocity", "accel", "friction", "gravity", "max_speed", "chase",
               "patrol", "move_to", "auto_anim", "face_move", "auto_flip", "collide", "bounds", "run_key", "physics")

TWEENABLE = ("x", "y", "rotation", "alpha", "scale", "scale_x", "scale_y", "w", "h", "color", "vx", "vy", "speed")


class ClickInfo:
    def __init__(self, x, y, button, sprite, screen):
        self.x = x
        self.y = y
        self.button = button
        self.sprite = sprite
        self.screen = screen


def _handler_property(ev):
    def get(self):
        return self.handlers.get(ev)

    def set_(self, fn):
        if fn is None:
            self.handlers.pop(ev, None)
        elif callable(fn):
            self.handlers[ev] = fn
        else:
            self.mgr.hints.bad_value(f"sprite '{self.name}'", "on_" + ev, fn, "a function", f"on_{ev}=lambda s: print(s)")
        self._refresh_click()

    return property(get, set_)


class Sprite:
    def __init__(self, mgr, name, texture, params):
        self.mgr = mgr
        self.name = name
        self.alive = True
        self.pending = False
        self.kind = "static"
        self.physics = False
        self.handlers = {}
        self.data = {}
        self.tags = set()
        self.x = 0.0
        self.y = 0.0
        self.vx = 0.0
        self.vy = 0.0
        self.w = 32.0
        self.h = 32.0
        self.scale_x = 1.0
        self.scale_y = 1.0
        self.rotation = 0.0
        self.ox = 0.5
        self.oy = 0.5
        self._rgba = [1.0, 1.0, 1.0, 1.0]
        self.flip_x = False
        self.flip_y = False
        self.layer = 0
        self.ysort = False
        self.sort_offset = 0.0
        self.parallax_x = 1.0
        self.parallax_y = 1.0
        self.fixed = False
        self.visible = True
        self.active = True
        self.texture = None
        self.tex_name = None
        self.tex_size = (1.0, 1.0)
        self.cols = 1
        self.rows = 1
        self.fw = 1.0
        self.fh = 1.0
        self.fx0 = 0.0
        self.fy0 = 0.0
        self.frame = 0
        self.frame_count = 1
        self.uv = (0.0, 0.0, 1.0, 1.0)
        self.tile = (1.0, 1.0)
        self._scroll = None
        self._uo = 0.0
        self._vo = 0.0
        self.animator = anim.Animator(self)
        self.auto_anim = None
        self.auto_flip = None
        self.face_move = None
        self.speed = 200.0
        self.run_key = None
        self.run_mult = 1.6
        self.accel = 0.0
        self.friction = 0.0
        self.max_speed = 0.0
        self.gravity = (0.0, 0.0)
        self.controls = None
        self.collide = False
        self.solid = False
        self.hitbox = None
        self.bounds = None
        self.arrive = 2.0
        self._goal = None
        self._chase = None
        self._path = None
        self.life = None
        self.age = 0.0
        self._click_flag = None
        self._clickable = False
        self.draggable = False
        self.hit_pad = 0.0
        self.overlap_tags = None
        self.overlap_stay = False
        self._touching = set()
        self.camera_spec = None
        self.pending_keys = None
        self.ext = {}
        self._cfg = {}
        self._warned = set()
        self._build(texture, dict(params))

    def _build(self, texture, p):
        mgr = self.mgr
        hints = mgr.hints
        who = f"sprite '{self.name}'"

        def num(key, default):
            if key not in p:
                return default
            v = p.pop(key)
            if isinstance(v, bool) or not isinstance(v, (int, float)):
                hints.bad_value(who, key, v, "a number", f"{key}=10")
                return default
            return float(v)

        def vec(key, default):
            if key not in p:
                return default
            v = p.pop(key)
            r = util.parse_vec2(v)
            if r is None:
                hints.bad_value(who, key, v, "a number or (x, y)", f"{key}=(64, 64)")
                return default
            return r

        def flag(key, default):
            return bool(p.pop(key)) if key in p else default

        self.kind = p.pop("kind", "static")
        self.physics = flag("physics", False)
        self.visible = flag("visible", True)
        self.active = flag("active", True)
        tags = p.pop("tags", None)
        if isinstance(tags, str):
            self.tags = {tags}
        elif isinstance(tags, (list, tuple, set)):
            self.tags = {str(t) for t in tags}
        elif tags is not None:
            hints.bad_value(who, "tags", tags, "a string or a list of strings", "tags=['enemy']")
        data = p.pop("data", None)
        if isinstance(data, dict):
            self.data.update(data)
        elif data is not None:
            hints.bad_value(who, "data", data, "a dict", "data={'hp': 10}")

        self.x = num("x", 0.0)
        self.y = num("y", 0.0)
        if "pos" in p:
            v = p.pop("pos")
            r = util.parse_vec2(v) if isinstance(v, (list, tuple)) else None
            if r is None:
                hints.bad_value(who, "pos", v, "(x, y)", "pos=(100, 50)")
            else:
                self.x, self.y = r
        self.rotation = num("rotation", 0.0)
        if "origin" in p:
            v = p.pop("origin")
            o = util.parse_origin(v)
            if o is None:
                hints.bad_value(who, "origin", v, "a name (center, bottom, topleft, ...) or (ox, oy) from 0 to 1", "origin='bottom'")
            else:
                self.ox, self.oy = o
        sc = vec("scale", (1.0, 1.0))
        self.scale_x, self.scale_y = sc
        self.flip_x = flag("flip_x", False)
        self.flip_y = flag("flip_y", False)
        if "color" in p:
            v = p.pop("color")
            c = util.parse_color(v)
            if c is None:
                hints.bad_value(who, "color", v, "a color name, '#rrggbb', or (r, g, b[, a])", "color='red' or color=(255, 128, 0)")
            else:
                self._rgba = c
        if "alpha" in p:
            self._rgba[3] = util.clamp(num("alpha", 1.0), 0.0, 1.0)
        self.layer = int(num("layer", 0))
        self.ysort = flag("ysort", False)
        self.sort_offset = num("sort_offset", 0.0)
        par = vec("parallax", (1.0, 1.0))
        self.parallax_x, self.parallax_y = par
        self.fixed = flag("fixed", False)
        self.tile = vec("tile", (1.0, 1.0))
        scr = vec("scroll", None)
        if scr is not None:
            self._scroll = scr
        smooth = p.pop("smooth", None)
        smooth = mgr.smooth if smooth is None else bool(smooth)
        repeat = flag("repeat", False) or self.tile != (1.0, 1.0) or self._scroll is not None
        async_load = flag("async_load", False)

        self.speed = num("speed", 200.0)
        self.run_key = p.pop("run_key", None)
        if self.run_key is not None and not ctl.key_codes(self.run_key):
            hints.warn(("runkey", str(self.run_key)), f"unknown run_key {self.run_key!r} for {who}",
                       "did you mean: " + ", ".join(util.close(self.run_key, ctl.key_names())) if util.close(self.run_key, ctl.key_names()) else "examples: 'shift', 'space', 'left_control'")
            self.run_key = None
        self.run_mult = num("run_mult", 1.6)
        self.accel = max(0.0, num("accel", 0.0))
        self.friction = max(0.0, num("friction", 0.0))
        self.max_speed = max(0.0, num("max_speed", 0.0))
        self.vx = num("vx", 0.0)
        self.vy = num("vy", 0.0)
        if "velocity" in p:
            v = p.pop("velocity")
            r = util.parse_vec2(v) if isinstance(v, (list, tuple)) else None
            if r is None:
                hints.bad_value(who, "velocity", v, "(vx, vy)", "velocity=(100, 0)")
            else:
                self.vx, self.vy = r
        if "gravity" in p:
            v = p.pop("gravity")
            if isinstance(v, (int, float)) and not isinstance(v, bool):
                v = (0.0, -float(v))
            r = util.parse_vec2(v) if isinstance(v, (list, tuple)) else None
            if r is None:
                hints.bad_value(who, "gravity", v, "(gx, gy) or a number pulling down", "gravity=(0, -900)")
            else:
                self.gravity = r
        if "controls" in p:
            spec = p.pop("controls")
            if spec not in (None, False, "", "none"):
                c, bad = ctl.Controls.parse(spec)
                if bad:
                    hints.warn(("ctl", tuple(bad)), f"unknown control token(s) {bad} for {who}",
                               "presets: 'wasd', 'arrows', 'both', 'ijkl', 'click', 'mouse', combine with '+': 'wasd+click'",
                               "or a dict: {'left': 'a', 'right': 'd', 'up': 'w', 'down': 's'}")
                if c.empty:
                    hints.warn(("ctlempty", self.name), f"controls={spec!r} for {who} binds nothing, the sprite will not move")
                else:
                    self.controls = c
        self.arrive = num("arrive", 2.0)
        self.collide = flag("collide", False)
        self.solid = flag("solid", False)
        if "hitbox" in p:
            v = p.pop("hitbox")
            if isinstance(v, (list, tuple)) and len(v) in (2, 4):
                try:
                    self.hitbox = tuple(float(i) for i in v)
                except (TypeError, ValueError):
                    hints.bad_value(who, "hitbox", v, "(w, h) or (ox, oy, w, h)", "hitbox=(24, 24)")
            else:
                hints.bad_value(who, "hitbox", v, "(w, h) or (ox, oy, w, h)", "hitbox=(24, 24)")
        if "bounds" in p:
            v = p.pop("bounds")
            if v is False:
                self.bounds = False
            elif v is not None:
                r = util.parse_rect4(v)
                if r is None:
                    hints.bad_value(who, "bounds", v, "(min_x, min_y, max_x, max_y) or False", "bounds=(-500, -300, 500, 300)")
                else:
                    self.bounds = r
        ot = p.pop("overlap_tags", None)
        if isinstance(ot, str):
            self.overlap_tags = {ot}
        elif isinstance(ot, (list, tuple, set)):
            self.overlap_tags = {str(t) for t in ot}
        self.overlap_stay = flag("overlap_stay", False)

        if "life" in p:
            lf = num("life", 0.0)
            if lf > 0:
                self.life = lf
            else:
                hints.bad_value(who, "life", lf, "seconds above zero", "life=2.5")

        self._click_flag = p.pop("clickable", None)
        self.draggable = flag("draggable", False)
        self.hit_pad = num("hit_pad", 0.0)
        for ev in EVENTS:
            fn = p.pop("on_" + ev, None)
            if fn is None:
                continue
            if callable(fn):
                self.handlers[ev] = fn
            else:
                hints.bad_value(who, "on_" + ev, fn, "a function", f"on_{ev}=lambda s: print(s.name)")
        self.pending_keys = p.pop("on_key", None)
        self.camera_spec = p.pop("camera", None)

        fps = num("fps", 8.0)
        size = vec("size", None)
        width = num("width", None) if "width" in p else None
        height = num("height", None) if "height" in p else None
        self._cfg = {
            "sheet": p.pop("sheet", None), "frame_size": p.pop("frame_size", None), "region": p.pop("region", None),
            "frame": int(num("frame", 0)), "anims": p.pop("anims", None), "anim": p.pop("anim", None), "fps": fps,
            "size": size, "width": width, "height": height,
        }
        aa = p.pop("auto_anim", None)
        self._auto_spec = aa
        af = p.pop("auto_flip", None)
        if af in (True, "right"):
            self.auto_flip = "right"
        elif af == "left":
            self.auto_flip = "left"
        elif af not in (None, False):
            hints.bad_value(who, "auto_flip", af, "True, 'right' (art faces right) or 'left'", "auto_flip=True")
        fm = p.pop("face_move", None)
        if fm is True:
            self.face_move = 0.0
        elif isinstance(fm, (int, float)) and not isinstance(fm, bool):
            self.face_move = float(fm)

        for k in [k for k in p if k in mgr.extensions]:
            self.ext[k] = p.pop(k)
        for k, v in p.items():
            hints.unknown_param(who, k, PARAMS.keys())
            self.data[k] = v

        self._refresh_click()
        self._load(texture, smooth, repeat, async_load)
        self._post_build(who)

    def _post_build(self, who):
        mgr = self.mgr
        hints = mgr.hints
        if not hints.on:
            return
        if self.kind == "static" and (self.controls or self.vx or self.vy or self._goal):
            hints.warn(("staticmove", self.name), f"{who} is kind='static' but has movement settings",
                       "static sprites never move by themselves; use kind='entity' (or just drop kind and let it be guessed)")
        if self.controls and self.speed <= 0:
            hints.warn(("speed0", self.name), f"{who} has controls but speed={self.speed}", "it will not move, use speed=200")
        if self._click_flag is False and any(e in self.handlers for e in CLICK_EVENTS):
            hints.warn(("clickoff", self.name), f"{who} has a click handler but clickable=False",
                       "remove clickable=False, handlers switch clicking on automatically")
        if self.alpha <= 0:
            hints.warn(("alpha0", self.name), f"{who} is fully transparent (alpha=0), it will not be drawn")
        if self.w <= 0 or self.h <= 0:
            hints.warn(("size0", self.name), f"{who} has zero size ({self.w}x{self.h}), nothing will be drawn",
                       "set size=(64, 64) or give it a texture")
        if self.texture is self.mgr.renderer.white and self._rgba[:3] == [1.0, 1.0, 1.0] and self.tex_name is None \
                and self.kind != "ui":
            hints.tip("plain", f"{who} has no texture and no color: it is a plain white square",
                      "pass a texture name as 2nd argument, or color='red', size=(40, 40)")

    def _load(self, texture, smooth, repeat, async_load):
        mgr = self.mgr
        who = f"sprite '{self.name}'"
        if texture is None:
            self._texture_ready(mgr.renderer.white, None)
            return
        if isinstance(texture, str):
            self.tex_name = texture
            eng = mgr.engine
            if async_load and eng.asset_path(texture, quiet=True) is not None:
                self.pending = True
                eng.texture_async(texture, self._async_done, smooth=smooth, repeat=repeat)
                return
            try:
                tex = eng.texture(texture, smooth=smooth, repeat=repeat)
            except RuntimeError:
                mgr.hints.error(("thread", self.name), f"{who} was created outside the main thread",
                                "textures need the OpenGL context: create sprites in init(), update, draw or callbacks",
                                "or pass async_load=True to decode in a worker")
                tex = None
            if tex is None:
                mgr.hints.texture_missing(who, texture, eng)
                self._cfg["missing"] = True
                tex = mgr.renderer.missing
            self._texture_ready(tex, texture)
            return
        if hasattr(texture, "use") and hasattr(texture, "size"):
            self._texture_ready(texture, None)
            return
        mgr.hints.bad_value(who, "texture", texture, "an asset name like 'hero.png' or a moderngl texture", "engine.sprite('hero', 'hero.png')")
        self._texture_ready(mgr.renderer.white, None)

    def _async_done(self, tex):
        if not self.alive:
            return
        self.pending = False
        self._texture_ready(tex, self.tex_name)

    def _texture_ready(self, tex, name):
        mgr = self.mgr
        hints = mgr.hints
        who = f"sprite '{self.name}'"
        cfg = self._cfg
        self.texture = tex
        tw, th = tex.size
        self.tex_size = (float(tw), float(th))
        self.cols, self.rows, self.fx0, self.fy0 = 1, 1, 0.0, 0.0
        self.fw, self.fh = self.tex_size
        region, sheet, fsize = cfg.get("region"), cfg.get("sheet"), cfg.get("frame_size")
        if region is not None:
            r = util.parse_rect4(region)
            if r is None or r[2] <= 0 or r[3] <= 0:
                hints.bad_value(who, "region", region, "(x, y, w, h) in image pixels", "region=(32, 0, 16, 16)")
            else:
                self.fx0, self.fy0, self.fw, self.fh = r
        elif sheet is not None:
            ok = isinstance(sheet, (list, tuple)) and len(sheet) == 2 and all(isinstance(i, int) and i > 0 for i in sheet)
            if not ok:
                hints.bad_value(who, "sheet", sheet, "(columns, rows) of positive integers", "sheet=(4, 2)")
            else:
                self.cols, self.rows = sheet
                self.fw, self.fh = tw / self.cols, th / self.rows
                if tw % self.cols or th % self.rows:
                    hints.warn(("sheetdiv", self.name), f"{who}: image {tw}x{th} does not divide evenly by sheet={tuple(sheet)}",
                               f"frames would be {self.fw:.2f}x{self.fh:.2f} px, so they will bleed into each other",
                               "check the sheet=(cols, rows) numbers or the image size")
        elif fsize is not None:
            v = util.parse_vec2(fsize) if isinstance(fsize, (list, tuple)) else None
            if v is None or v[0] <= 0 or v[1] <= 0:
                hints.bad_value(who, "frame_size", fsize, "(width, height) in pixels", "frame_size=(32, 32)")
            else:
                self.fw, self.fh = v
                self.cols = max(1, int(tw // v[0]))
                self.rows = max(1, int(th // v[1]))
        self.frame_count = self.cols * self.rows
        size, width, height = cfg.get("size"), cfg.get("width"), cfg.get("height")
        base_w, base_h = self.fw, self.fh
        if tex is mgr.renderer.white:
            base_w, base_h = 32.0, 32.0
        elif tex is mgr.renderer.missing:
            base_w, base_h = 64.0, 64.0
        if size is not None:
            self.w, self.h = size
        elif width is not None and height is not None:
            self.w, self.h = width, height
        elif width is not None:
            self.w, self.h = width, width * base_h / base_w
        elif height is not None:
            self.w, self.h = height * base_w / base_h, height
        else:
            self.w, self.h = base_w, base_h
        self.animator = anim.Animator(self)
        anims = cfg.get("anims")
        if anims is not None:
            if not isinstance(anims, dict):
                hints.bad_value(who, "anims", anims, "a dict {name: frames}", "anims={'walk': '0-3', 'idle': [4]}")
            else:
                for cname, spec in anims.items():
                    try:
                        clip = anim.parse_clip(cname, spec, cfg.get("fps", 8.0), self.cols, self.rows)
                    except (ValueError, TypeError) as e:
                        hints.warn(("clip", self.name, cname), f"animation '{cname}' of {who} is invalid: {e}",
                                   "accepted: [0,1,2], '0-3', '0-3,5', {'row': 1, 'count': 4, 'fps': 10}, {'frames': '0-3', 'loop': False}")
                        continue
                    bad = [f for f in clip.frames if f < 0 or f >= self.frame_count]
                    if bad:
                        hints.warn(("clipframe", self.name, cname), f"animation '{cname}' of {who} uses frames {bad[:6]} but the sheet has only {self.frame_count} frames (0-{self.frame_count - 1})",
                                   "those frames are clamped to the last valid one",
                                   "forgot sheet=(cols, rows) or frame_size=(w, h)?" if self.frame_count == 1 else "check the sheet size")
                    self.animator.clips[cname] = clip
        self._resolve_auto(self._auto_spec, who)
        want = cfg.get("anim")
        self.set_frame(cfg.get("frame", 0))
        if want is not None:
            if not self.play(want):
                pass
        elif self.auto_anim and self.auto_anim[0]:
            self.play(self.auto_anim[0])
        elif self.animator.clips and not self.auto_anim:
            self.play(next(iter(self.animator.clips)))

    def _resolve_auto(self, spec, who):
        self.auto_anim = None
        if spec in (None, False):
            return
        clips = self.animator.clips
        hints = self.mgr.hints
        if spec is True:
            idle = next((n for n in ("idle", "stand") if n in clips), None)
            move = next((n for n in ("walk", "run", "move") if n in clips), None)
        elif isinstance(spec, dict):
            idle, move = spec.get("idle"), spec.get("move")
        else:
            hints.bad_value(who, "auto_anim", spec, "True or {'idle': 'stand', 'move': 'run'}", "auto_anim=True")
            return
        for label, n in (("idle", idle), ("move", move)):
            if n is not None and n not in clips:
                hints.warn(("autoanim", self.name, label), f"auto_anim of {who}: no clip '{n}' for {label}",
                           "available clips: " + (", ".join(clips) if clips else "none (add anims={...})"))
                if label == "idle":
                    idle = None
                else:
                    move = None
        if idle is None and move is None:
            hints.warn(("autoanim0", self.name), f"auto_anim=True on {who} found no clip named idle/walk/run",
                       "name your clips 'idle' and 'walk', or pass auto_anim={'idle': 'name', 'move': 'name'}",
                       "available clips: " + (", ".join(clips) if clips else "none"))
            return
        self.auto_anim = (idle, move)

    def set_texture(self, texture, sheet=None, frame_size=None, region=None, frame=0, anims=None, anim=None,
                    fps=8.0, size=None, smooth=None, repeat=False, keep_size=False):
        self._cfg = {"sheet": sheet, "frame_size": frame_size, "region": region, "frame": frame, "anims": anims,
                     "anim": anim, "fps": fps, "size": (self.w, self.h) if keep_size and size is None else (util.parse_vec2(size) if size is not None else None),
                     "width": None, "height": None}
        self._load(texture, self.mgr.smooth if smooth is None else bool(smooth), repeat, False)
        return self

    def set_frame(self, i):
        try:
            i = int(i)
        except (TypeError, ValueError):
            return self
        if i < 0 or i >= self.frame_count:
            self.mgr.hints.warn(("frame", self.name), f"frame {i} of sprite '{self.name}' is out of range (0-{self.frame_count - 1})",
                                "it is clamped; sheet=(cols, rows) or frame_size=(w, h) defines how many frames exist")
            i = max(0, min(self.frame_count - 1, i))
        self.frame = i
        col, row = i % self.cols, i // self.cols
        x = self.fx0 + col * self.fw
        y = self.fy0 + row * self.fh
        tw, th = self.tex_size
        u0, u1 = x / tw, (x + self.fw) / tw
        vt, vb = 1.0 - y / th, 1.0 - (y + self.fh) / th
        tx, ty = self.tile
        if tx != 1.0:
            u1 = u0 + (u1 - u0) * tx
        if ty != 1.0:
            vb = vt - (vt - vb) * ty
        self.uv = (u0, vb, u1, vt)
        return self

    def play(self, name, restart=False, speed=None, fps=None, loop=None, on_end=None):
        if not self.alive:
            self._dead("play")
            return False
        if not self.animator.play(name, restart, speed, fps, loop, on_end):
            clips = list(self.animator.clips)
            self.mgr.hints.warn(("noclip", self.name, name), f"sprite '{self.name}' has no animation '{name}'",
                                ("did you mean: " + ", ".join(util.close(name, clips))) if util.close(name, clips) else "available: " + (", ".join(clips) if clips else "none, define them with anims={'walk': '0-3'}"),
                                "add one later with sprite.add_anim('name', frames)")
            return False
        return True

    def add_anim(self, name, spec, fps=None):
        try:
            clip = anim.parse_clip(name, spec, self._cfg.get("fps", 8.0) if fps is None else fps, self.cols, self.rows)
        except (ValueError, TypeError) as e:
            self.mgr.hints.warn(("addclip", self.name, name), f"add_anim('{name}') on sprite '{self.name}' failed: {e}")
            return self
        self.animator.clips[name] = clip
        return self

    def pause(self):
        self.animator.playing = False
        return self

    def resume(self):
        if self.animator.clip is not None:
            self.animator.playing = True
        return self

    def stop_anim(self):
        self.animator.playing = False
        self.animator.clip = None
        return self

    @property
    def anim_name(self):
        return self.animator.name

    def _dead(self, what):
        self.mgr.hints.tip(("dead", self.name, what), f"{what}() was called on destroyed sprite '{self.name}'",
                           "the call is ignored; keep a check like  if sprite.alive:  or fetch it again with engine.sprite_manager().get(name)")

    @property
    def rgba(self):
        return self._rgba

    @rgba.setter
    def rgba(self, value):
        self._rgba = [float(v) for v in value]

    @property
    def color(self):
        return tuple(self._rgba)

    @color.setter
    def color(self, value):
        c = util.parse_color(value)
        if c is None:
            self.mgr.hints.bad_value(f"sprite '{self.name}'", "color", value, "a color name, '#rrggbb', or (r, g, b[, a])", "sprite.color = 'red'")
        else:
            self._rgba = c

    @property
    def alpha(self):
        return self._rgba[3]

    @alpha.setter
    def alpha(self, value):
        self._rgba[3] = util.clamp(float(value), 0.0, 1.0)

    @property
    def scale(self):
        return self.scale_x

    @scale.setter
    def scale(self, value):
        if isinstance(value, (list, tuple)):
            self.scale_x, self.scale_y = float(value[0]), float(value[1])
        else:
            self.scale_x = self.scale_y = float(value)

    @property
    def pos(self):
        return (self.x, self.y)

    @pos.setter
    def pos(self, value):
        self.x, self.y = float(value[0]), float(value[1])

    @property
    def velocity(self):
        return (self.vx, self.vy)

    @velocity.setter
    def velocity(self, value):
        self.vx, self.vy = float(value[0]), float(value[1])

    @property
    def size(self):
        return (self.w * self.scale_x, self.h * self.scale_y)

    @size.setter
    def size(self, value):
        v = util.parse_vec2(value)
        if v is None:
            self.mgr.hints.bad_value(f"sprite '{self.name}'", "size", value, "(w, h) or one number", "sprite.size = (64, 64)")
            return
        self.w, self.h = v
        self.scale_x = self.scale_y = 1.0

    @property
    def center(self):
        return (self.x + (0.5 - self.ox) * self.w * self.scale_x, self.y + (0.5 - self.oy) * self.h * self.scale_y)

    @property
    def clickable(self):
        return self._clickable

    @clickable.setter
    def clickable(self, value):
        self._click_flag = None if value is None else bool(value)
        self._refresh_click()

    def _refresh_click(self):
        if self._click_flag is not None:
            self._clickable = self._click_flag
        else:
            self._clickable = self.draggable or any(e in self.handlers for e in CLICK_EVENTS)

    def rect(self):
        W, H = abs(self.w * self.scale_x), abs(self.h * self.scale_y)
        cx = self.x + (0.5 - self.ox) * W
        cy = self.y + (0.5 - self.oy) * H
        hb = self.hitbox
        if hb is None:
            hw, hh = W * 0.5, H * 0.5
        elif len(hb) == 2:
            hw, hh = hb[0] * 0.5, hb[1] * 0.5
        else:
            cx += hb[0]
            cy += hb[1]
            hw, hh = hb[2] * 0.5, hb[3] * 0.5
        return (cx - hw, cy - hh, cx + hw, cy + hh)

    def radius(self):
        W, H = abs(self.w * self.scale_x), abs(self.h * self.scale_y)
        return math.hypot(max(self.ox, 1.0 - self.ox) * W, max(self.oy, 1.0 - self.oy) * H)

    def hit(self, px, py):
        W, H = abs(self.w * self.scale_x), abs(self.h * self.scale_y)
        dx, dy = px - self.x, py - self.y
        if self.rotation:
            r = -self.rotation * DEG
            c, s = math.cos(r), math.sin(r)
            dx, dy = c * dx - s * dy, s * dx + c * dy
        lx, ly = dx + self.ox * W, dy + self.oy * H
        pad = self.hit_pad
        return -pad <= lx <= W + pad and -pad <= ly <= H + pad

    def contains(self, x, y):
        return self.hit(x, y)

    def overlaps(self, other):
        a, b = self.rect(), other.rect()
        return a[0] < b[2] and a[2] > b[0] and a[1] < b[3] and a[3] > b[1]

    def distance_to(self, other_or_x, y=None):
        if y is None:
            return math.hypot(other_or_x.x - self.x, other_or_x.y - self.y)
        return math.hypot(other_or_x - self.x, y - self.y)

    def has_tag(self, tag):
        return tag in self.tags

    def add_tag(self, *tags):
        self.tags.update(tags)
        return self

    def row(self, camx, camy):
        u0, v0, u1, v1 = self.uv
        if self._uo or self._vo:
            u0 += self._uo
            u1 += self._uo
            v0 += self._vo
            v1 += self._vo
        if self.flip_x:
            u0, u1 = u1, u0
        if self.flip_y:
            v0, v1 = v1, v0
        px, py = self.parallax_x, self.parallax_y
        x = self.x if px == 1.0 else self.x + camx * (1.0 - px)
        y = self.y if py == 1.0 else self.y + camy * (1.0 - py)
        c = self._rgba
        return (x, y, self.w * self.scale_x, self.h * self.scale_y, self.ox, self.oy, self.rotation * DEG,
                u0, v0, u1, v1, c[0], c[1], c[2], c[3])

    def move(self, dx, dy):
        self.x += dx
        self.y += dy
        return self

    def move_to(self, x, y, speed=None, on_arrive=None):
        if not self.alive:
            self._dead("move_to")
            return self
        if not self.physics:
            self.mgr.hints.warn(("mvstatic", self.name), f"move_to() on sprite '{self.name}' which is kind='{self.kind}' (no physics)",
                                "walking needs an entity: create it with kind='entity' or give it speed=/controls=",
                                "to just place it somewhere use sprite.pos = (x, y) or sprite.tween(x=..., y=..., duration=1)")
            return self
        if speed is not None:
            self.speed = float(speed)
        if self.speed <= 0:
            self.mgr.hints.warn(("mv0", self.name), f"sprite '{self.name}' cannot move_to() with speed={self.speed}", "pass speed=200")
        self._goal = (float(x), float(y))
        self._chase = None
        self._path = None
        if on_arrive is not None:
            self.handlers["arrive"] = on_arrive
        return self

    def stop(self):
        self._goal = self._chase = self._path = None
        self.vx = self.vy = 0.0
        return self

    def chase(self, target, stop_distance=8.0, speed=None):
        if isinstance(target, str):
            found = self.mgr.sprites.get(target)
            if found is None:
                self.mgr.hints.no_such_name("sprite", target, self.mgr.sprites.keys())
                return self
            target = found
        if speed is not None:
            self.speed = float(speed)
        self._chase = (target, float(stop_distance))
        self._goal = None
        self._path = None
        return self

    def patrol(self, points, mode="loop", speed=None):
        pts = []
        for p in points:
            v = util.parse_vec2(p) if isinstance(p, (list, tuple)) else None
            if v:
                pts.append(v)
        if not pts or mode not in ("loop", "pingpong", "once"):
            self.mgr.hints.warn(("patrol", self.name), f"bad patrol for sprite '{self.name}'",
                                "points must be [(x, y), ...] and mode one of 'loop', 'pingpong', 'once'")
            return self
        if speed is not None:
            self.speed = float(speed)
        self._path = {"pts": pts, "i": 0, "mode": mode, "dir": 1}
        self._goal = None
        self._chase = None
        return self

    def look_at(self, x, y, offset=0.0):
        self.rotation = math.degrees(math.atan2(y - self.y, x - self.x)) + offset
        return self

    def on(self, event, fn=None):
        if event not in EVENTS:
            self.mgr.hints.warn(("event", event), f"unknown event '{event}' for sprite '{self.name}'",
                                "did you mean: " + ", ".join(util.close(event, EVENTS)) if util.close(event, EVENTS) else "events: " + ", ".join(EVENTS))
            return fn if fn is not None else (lambda f: f)
        if fn is None:
            def deco(f):
                self.handlers[event] = f
                self._refresh_click()
                return f
            return deco
        self.handlers[event] = fn
        self._refresh_click()
        return fn

    def bind(self, key, fn, event="press"):
        self.mgr.bind(key, fn, event, owner=self)
        return self

    def fire(self, ev, *args):
        fn = self.handlers.get(ev)
        if fn is not None:
            self.mgr.call(fn, self.name, ev, self, *args)

    def tween(self, duration=0.5, ease="in_out_cubic", delay=0.0, on_done=None, repeat=0, yoyo=False, **props):
        if not self.alive:
            self._dead("tween")
            return None
        hints = self.mgr.hints
        out = {}
        for k, v in props.items():
            if k == "color":
                c = util.parse_color(v)
                if c is None:
                    hints.bad_value(f"sprite '{self.name}'", "tween color", v, "a color name, '#rrggbb', or (r, g, b[, a])", "color='red'")
                    continue
                out["rgba"] = c
            elif k in TWEENABLE:
                if isinstance(v, bool) or not isinstance(v, (int, float)):
                    hints.bad_value(f"sprite '{self.name}'", "tween " + k, v, "a number", f"{k}=100")
                    continue
                out[k] = v
            elif k == "pos":
                r = util.parse_vec2(v) if isinstance(v, (list, tuple)) else None
                if r is None:
                    hints.bad_value(f"sprite '{self.name}'", "tween pos", v, "(x, y)", "pos=(100, 50)")
                    continue
                out["x"], out["y"] = r
            else:
                near = util.close(k, TWEENABLE)
                hints.warn(("tweenattr", k), f"cannot tween '{k}' on sprite '{self.name}'",
                           ("did you mean: " + ", ".join(near)) if near else "tweenable: " + ", ".join(TWEENABLE) + ", pos",
                           "example: sprite.tween(x=300, alpha=0.5, duration=1, ease='out_back')")
        if not out:
            return None
        fn = anim.get_ease(ease)
        if fn is None:
            near = util.close(ease, anim.EASINGS)
            hints.warn(("ease", str(ease)), f"unknown easing '{ease}'",
                       ("did you mean: " + ", ".join(near)) if near else "examples: linear, in_out_cubic, out_back, out_bounce, in_out_sine",
                       "'in_out_cubic' is used instead")
            fn = anim.EASINGS["in_out_cubic"]
        if duration <= 0:
            for k, v in out.items():
                setattr(self, k, v)
            return None
        return self.mgr.tweens.add(anim.Tween(self, out, duration, fn, delay, on_done, repeat, yoyo))

    def fade_to(self, alpha, duration=0.4, **kw):
        return self.tween(duration=duration, alpha=alpha, **kw)

    def fade_in(self, duration=0.4, **kw):
        self.alpha = 0.0
        return self.tween(duration=duration, alpha=1.0, **kw)

    def fade_out(self, duration=0.4, destroy=False, **kw):
        if destroy:
            kw["on_done"] = lambda s: s.destroy()
        return self.tween(duration=duration, alpha=0.0, **kw)

    def flash(self, color="white", duration=0.15):
        c = util.parse_color(color)
        if c is None:
            self.mgr.hints.bad_value(f"sprite '{self.name}'", "flash color", color, "a color name or (r, g, b)", "sprite.flash('red')")
            return None
        back = list(self._rgba)
        self._rgba = c[:3] + [back[3]]
        return self.tween(duration=duration, ease="linear", color=back)

    def show(self):
        self.visible = True
        return self

    def hide(self):
        self.visible = False
        return self

    def destroy(self, delay=0.0):
        if not self.alive:
            return self
        if delay > 0:
            self.life = self.age + float(delay)
            return self
        self.alive = False
        self.fire("destroy")
        self.mgr._mark_dead(self)
        return self

    def _physics(self, dt, inp):
        mgr = self.mgr
        c = self.controls
        spd = self.speed
        if self.run_key is not None and inp.down(self.run_key):
            spd *= self.run_mult
        old_vx, old_vy = self.vx, self.vy
        want = None
        if c is not None:
            mx, my = c.vector(inp)
            if mx or my:
                want = (mx * spd, my * spd)
                self._goal = None
                self._path = None
            elif c.mouse and inp.mouse_down(0) and not mgr.mouse_over_ui:
                tx, ty = mgr.mouse
                d = math.hypot(tx - self.x, ty - self.y)
                if d > self.arrive:
                    want = ((tx - self.x) / d * spd, (ty - self.y) / d * spd)
        if want is None and self._goal is not None:
            gx, gy = self._goal
            d = math.hypot(gx - self.x, gy - self.y)
            if d <= max(self.arrive, spd * dt):
                self.x, self.y = gx, gy
                self._goal = None
                self.vx = self.vy = 0.0
                self.fire("arrive")
            else:
                want = ((gx - self.x) / d * spd, (gy - self.y) / d * spd)
        if want is None and self._chase is not None:
            t, stop = self._chase
            if not t.alive:
                self._chase = None
            else:
                d = math.hypot(t.x - self.x, t.y - self.y)
                if d > stop:
                    want = ((t.x - self.x) / d * spd, (t.y - self.y) / d * spd)
        if want is None and self._path is not None:
            path = self._path
            pts = path["pts"]
            tx, ty = pts[path["i"]]
            d = math.hypot(tx - self.x, ty - self.y)
            if d <= max(self.arrive, spd * dt):
                n = len(pts)
                if path["mode"] == "loop":
                    path["i"] = (path["i"] + 1) % n
                elif path["mode"] == "pingpong":
                    nxt = path["i"] + path["dir"]
                    if nxt >= n or nxt < 0:
                        path["dir"] = -path["dir"]
                        nxt = path["i"] + path["dir"]
                    path["i"] = max(0, min(n - 1, nxt))
                else:
                    path["i"] += 1
                    if path["i"] >= n:
                        self._path = None
                        self.fire("arrive")
            else:
                want = ((tx - self.x) / d * spd, (ty - self.y) / d * spd)
        steered = c is not None or self._goal is not None or self._chase is not None or self._path is not None
        if want is not None:
            if self.accel > 0:
                step = self.accel * dt
                self.vx = util.approach(self.vx, want[0], step)
                self.vy = util.approach(self.vy, want[1], step)
            else:
                self.vx, self.vy = want
        elif steered:
            if self.accel > 0:
                step = self.accel * dt
                self.vx = util.approach(self.vx, 0.0, step)
                self.vy = util.approach(self.vy, 0.0, step)
            elif self.friction > 0:
                k = math.exp(-self.friction * dt)
                self.vx *= k
                self.vy *= k
            else:
                self.vx = self.vy = 0.0
        elif self.friction > 0:
            k = math.exp(-self.friction * dt)
            self.vx *= k
            self.vy *= k
        if c is not None and not (c.click or c.mouse) and self._goal is None and self._chase is None and self._path is None:
            if not c.horizontal:
                self.vx = old_vx
            if not c.vertical:
                self.vy = old_vy
        gx, gy = self.gravity
        if gx or gy:
            self.vx += gx * dt
            self.vy += gy * dt
        if self.max_speed > 0:
            sp = math.hypot(self.vx, self.vy)
            if sp > self.max_speed:
                k = self.max_speed / sp
                self.vx *= k
                self.vy *= k
        dx, dy = self.vx * dt, self.vy * dt
        if dx or dy:
            if self.collide and mgr.solids:
                self._move_collide(dx, dy)
            else:
                self.x += dx
                self.y += dy
            b = self.bounds if self.bounds is not None else mgr.world_clamp
            if b:
                r = self.rect()
                if r[0] < b[0]:
                    self.x += b[0] - r[0]
                    self.vx = max(self.vx, 0.0)
                elif r[2] > b[2]:
                    self.x -= r[2] - b[2]
                    self.vx = min(self.vx, 0.0)
                if r[1] < b[1]:
                    self.y += b[1] - r[1]
                    self.vy = max(self.vy, 0.0)
                elif r[3] > b[3]:
                    self.y -= r[3] - b[3]
                    self.vy = min(self.vy, 0.0)
        if self.face_move is not None and (abs(self.vx) > 1.0 or abs(self.vy) > 1.0):
            self.rotation = math.degrees(math.atan2(self.vy, self.vx)) + self.face_move
        if self.auto_flip is not None and abs(self.vx) > 1.0:
            self.flip_x = self.vx < 0 if self.auto_flip == "right" else self.vx > 0

    def _move_collide(self, dx, dy):
        solids = self.mgr.solids
        if dx:
            self.x += dx
            r = self.rect()
            for s in solids:
                if s is self or not s.alive:
                    continue
                o = s.rect()
                if r[0] < o[2] and r[2] > o[0] and r[1] < o[3] and r[3] > o[1]:
                    self.x += (o[0] - r[2]) if dx > 0 else (o[2] - r[0])
                    self.vx = 0.0
                    r = self.rect()
                    self.fire("collide", s)
        if dy:
            self.y += dy
            r = self.rect()
            for s in solids:
                if s is self or not s.alive:
                    continue
                o = s.rect()
                if r[0] < o[2] and r[2] > o[0] and r[1] < o[3] and r[3] > o[1]:
                    self.y += (o[1] - r[3]) if dy > 0 else (o[3] - r[1])
                    self.vy = 0.0
                    r = self.rect()
                    self.fire("collide", s)

    def _auto_anim(self):
        idle, move = self.auto_anim
        moving = abs(self.vx) > 5.0 or abs(self.vy) > 5.0
        name = (move if moving else idle) or (idle if moving else move)
        if name and self.animator.name != name:
            self.animator.play(name)

    def update(self, dt, inp):
        if self.life is not None:
            self.age += dt
            left = self.life - self.age
            if left <= 0.0:
                self.destroy()
                return
        if self.physics:
            self._physics(dt, inp)
        if self._scroll is not None:
            self._uo = (self._uo + self._scroll[0] * dt) % 1.0 or 1e-9
            self._vo = (self._vo + self._scroll[1] * dt) % 1.0 or 1e-9
        a = self.animator
        if a.clips:
            if self.auto_anim:
                self._auto_anim()
            a.update(dt)
        h = self.handlers.get("update")
        if h is not None:
            self.mgr.call(h, self.name, "update", self, dt)

    def __repr__(self):
        return f"<Sprite '{self.name}' {self.kind} at ({self.x:.1f}, {self.y:.1f})>"


for _ev in EVENTS:
    setattr(Sprite, "on_" + _ev, _handler_property(_ev))
