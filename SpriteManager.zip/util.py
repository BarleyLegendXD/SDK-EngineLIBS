import difflib
import math

NAMED = {
    "white": (255, 255, 255), "black": (0, 0, 0), "red": (255, 64, 64), "green": (64, 220, 96),
    "blue": (64, 128, 255), "yellow": (255, 220, 64), "orange": (255, 150, 50), "purple": (170, 90, 255),
    "pink": (255, 120, 190), "cyan": (64, 230, 255), "gray": (128, 128, 128), "grey": (128, 128, 128),
    "brown": (140, 90, 50), "transparent": (255, 255, 255, 0),
}

ORIGINS = {
    "center": (0.5, 0.5), "middle": (0.5, 0.5), "bottom": (0.5, 0.0), "feet": (0.5, 0.0), "top": (0.5, 1.0),
    "left": (0.0, 0.5), "right": (1.0, 0.5), "bottomleft": (0.0, 0.0), "bottomright": (1.0, 0.0),
    "topleft": (0.0, 1.0), "topright": (1.0, 1.0),
}


def parse_color(value):
    if isinstance(value, str):
        v = value.strip().lower()
        if v in NAMED:
            value = NAMED[v]
        elif v.startswith("#"):
            h = v[1:]
            if len(h) in (3, 4):
                h = "".join(c * 2 for c in h)
            if len(h) not in (6, 8):
                return None
            try:
                value = tuple(int(h[i:i + 2], 16) for i in range(0, len(h), 2))
            except ValueError:
                return None
        else:
            return None
    if isinstance(value, (list, tuple)) and len(value) in (3, 4):
        try:
            vals = [float(c) for c in value]
        except (TypeError, ValueError):
            return None
        normalized = any(isinstance(c, float) for c in value) and max(vals) <= 1.0
        if not normalized:
            vals = [c / 255.0 for c in vals]
        if len(vals) == 3:
            vals.append(1.0)
        return [min(1.0, max(0.0, c)) for c in vals]
    return None


def parse_vec2(value):
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return (float(value), float(value))
    if isinstance(value, (list, tuple)) and len(value) == 2:
        try:
            return (float(value[0]), float(value[1]))
        except (TypeError, ValueError):
            return None
    return None


def parse_rect4(value):
    if isinstance(value, (list, tuple)) and len(value) == 4:
        try:
            return tuple(float(v) for v in value)
        except (TypeError, ValueError):
            return None
    return None


def parse_origin(value):
    if isinstance(value, str):
        key = value.strip().lower().replace(" ", "").replace("_", "").replace("-", "")
        return ORIGINS.get(key)
    return parse_vec2(value)


def close(name, options, n=3, cutoff=0.5):
    return difflib.get_close_matches(str(name), [str(o) for o in options], n=n, cutoff=cutoff)


def clamp(v, lo, hi):
    return lo if v < lo else hi if v > hi else v


def approach(v, target, step):
    if v < target:
        return min(v + step, target)
    return max(v - step, target)


def lerp(a, b, t):
    return a + (b - a) * t
