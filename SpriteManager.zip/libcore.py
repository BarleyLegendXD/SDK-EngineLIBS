NAME = "SpriteManager"
VERSION = "1.0.0"
ENGINE = ">=2.1.0"
PRIORITY = 100

MANAGER = None

from . import manager as _manager


def _sprite(engine, name=None, texture=None, **params):
    return MANAGER.create(name, texture, **params)


def _camera(engine, name=None, **cfg):
    return MANAGER.cam(name, **cfg)


def _sprite_manager(engine):
    return MANAGER


def init(engine):
    global MANAGER
    MANAGER = _manager.SpriteManager(engine)
    engine.state["sprites"] = MANAGER
    engine.add_method("engine", "sprite", _sprite)
    engine.add_method("engine", "camera", _camera)
    engine.add_method("engine", "sprite_manager", _sprite_manager)
    MANAGER.hints.banner(VERSION)


def shutdown(engine):
    global MANAGER
    if MANAGER is not None:
        MANAGER.shutdown()
    engine.state.pop("sprites", None)
    MANAGER = None
