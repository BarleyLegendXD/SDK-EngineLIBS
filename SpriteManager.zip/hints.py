import textwrap

from . import util

TAG = "SpriteManager"
CYAN = (120, 230, 255)
AMBER = (255, 205, 70)
RED = (255, 95, 95)
GREEN = (120, 255, 160)
DIM = (185, 185, 165)


class Hints:
    def __init__(self, engine):
        self.engine = engine
        self.seen = set()

    @property
    def on(self):
        return bool(self.engine.cfg.get("debug", True))

    def say(self, key, color, head, lines=()):
        if not self.on or key in self.seen:
            return False
        self.seen.add(key)
        log = self.engine.log
        log(f"[{TAG}] {head}", color)
        for line in lines:
            wrapped = textwrap.wrap(str(line), 66) or [""]
            log("   > " + wrapped[0], DIM)
            for extra in wrapped[1:]:
                log("     " + extra, DIM)
        return True

    def warn(self, key, head, *lines):
        return self.say(key, AMBER, "WARN: " + head, lines)

    def error(self, key, head, *lines):
        return self.say(key, RED, "ERROR: " + head, lines)

    def tip(self, key, head, *lines):
        return self.say(key, CYAN, "TIP: " + head, lines)

    def ok(self, key, head, *lines):
        return self.say(key, GREEN, head, lines)

    def banner(self, version):
        if not self.on:
            return
        w = 60
        inner = w - 4

        def row(text=""):
            return "| " + text[:inner].ljust(inner) + " |"

        edge = "+" + "-" * (w - 2) + "+"
        lines = [
            edge,
            row("S P R I T E   M A N A G E R   v" + version),
            row("sprites | cameras | animation | input | picking"),
            edge,
            row('hero = engine.sprite("hero", "hero.png",'),
            row('                     controls="wasd", camera=True)'),
            row(),
            row("hints are ON (set debug = false in config.cfg to mute)"),
            row("engine.sprite_manager().help() lists every parameter"),
            edge,
        ]
        a, b = (90, 255, 210), (90, 150, 255)
        n = len(lines) - 1
        for i, line in enumerate(lines):
            t = i / n
            self.engine.log(line, tuple(int(util.lerp(a[k], b[k], t)) for k in range(3)))

    def params(self, table):
        if not self.on:
            return
        groups = {}
        for name, (group, desc) in table.items():
            groups.setdefault(group, []).append((name, desc))
        log = self.engine.log
        log(f"[{TAG}] parameters of engine.sprite(name, texture, **params)", CYAN)
        for group, items in groups.items():
            log(f"  -- {group} --", AMBER)
            for name, desc in items:
                log(f"   {name:<14}{desc}", DIM)

    def unknown_param(self, who, name, known):
        near = util.close(name, known)
        lines = []
        if near:
            lines.append("did you mean: " + ", ".join(f"'{n}'" for n in near) + " ?")
        lines.append("the value was NOT used for anything, it is only stored in sprite.data")
        lines.append("engine.sprite_manager().help() prints all valid parameters")
        self.warn(("param", name), f"unknown parameter '{name}' for {who}", *lines)

    def bad_value(self, who, param, value, expected, example):
        self.warn(("val", who, param), f"bad value for '{param}' of {who}: {value!r}",
                  f"expected {expected}, for example {example}", "the default value is used instead")

    def texture_missing(self, who, name, engine):
        index = getattr(engine, "_asset_index", {})
        lines = []
        if not index:
            lines.append(f"the '{engine.assets_dir}' folder is empty or missing, put your images there")
        else:
            near = util.close(str(name).lower(), index.keys(), n=4, cutoff=0.4)
            if near:
                lines.append("similar assets: " + ", ".join(near))
            lines.append(f"{len(index)} asset names are indexed (subfolders included, extension optional)")
        lines.append("a pink/black checker texture is drawn in its place so you can still see the sprite")
        lines.append("supported formats: png, jpg, bmp, tga, gif, webp (anything Pillow can open)")
        self.error(("tex", name), f"texture '{name}' for {who} was not found", *lines)

    def no_such_name(self, kind, name, options):
        near = util.close(name, options)
        lines = []
        if near:
            lines.append("did you mean: " + ", ".join(f"'{n}'" for n in near) + " ?")
        shown = list(options)[:12]
        lines.append(f"existing {kind}s: " + (", ".join(shown) if shown else "none yet"))
        self.warn((kind, name), f"no {kind} named '{name}'", *lines)
