import math
from array import array

import moderngl

VERT = """#version 330
uniform vec2 u_screen;
uniform vec2 u_cam;
uniform vec2 u_rot;
uniform float u_zoom;
in vec2 i_pos;
in vec2 i_size;
in vec2 i_origin;
in float i_rot;
in vec4 i_uv;
in vec4 i_color;
out vec2 v_uv;
out vec4 v_color;
void main() {
    vec2 k = vec2(float(gl_VertexID & 1), float(gl_VertexID >> 1));
    vec2 local = (k - i_origin) * i_size;
    float c = cos(i_rot);
    float s = sin(i_rot);
    vec2 w = i_pos + vec2(c * local.x - s * local.y, s * local.x + c * local.y);
    vec2 d = w - u_cam;
    vec2 v = vec2(u_rot.x * d.x + u_rot.y * d.y, -u_rot.y * d.x + u_rot.x * d.y) * u_zoom;
    gl_Position = vec4(v / (u_screen * 0.5), 0.0, 1.0);
    v_uv = mix(i_uv.xy, i_uv.zw, k);
    v_color = i_color;
}"""

FRAG = """#version 330
uniform sampler2D u_tex;
in vec2 v_uv;
in vec4 v_color;
out vec4 f_color;
void main() {
    vec4 t = texture(u_tex, v_uv) * v_color;
    if (t.a <= 0.003) discard;
    f_color = t;
}"""

STRIDE = 15 * 4


class Renderer:
    def __init__(self, ctx):
        self.ctx = ctx
        self.prog = ctx.program(vertex_shader=VERT, fragment_shader=FRAG)
        self.cap = 1024 * STRIDE
        self.buf = ctx.buffer(reserve=self.cap)
        self.vao = ctx.vertex_array(
            self.prog, [(self.buf, "2f 2f 2f 1f 4f 4f/i", "i_pos", "i_size", "i_origin", "i_rot", "i_uv", "i_color")]
        )
        self.white = ctx.texture((1, 1), 4, b"\xff\xff\xff\xff")
        self.white.filter = (moderngl.NEAREST, moderngl.NEAREST)
        pink, black = bytes((255, 0, 255, 255)), bytes((0, 0, 0, 255))
        self.missing = ctx.texture((2, 2), 4, pink + black + black + pink)
        self.missing.filter = (moderngl.NEAREST, moderngl.NEAREST)
        self.prog["u_tex"].value = 0
        self.calls = 0

    def draw(self, items, view, size, camx, camy):
        if not items:
            return
        ctx = self.ctx
        prog = self.prog
        ctx.disable(moderngl.DEPTH_TEST | moderngl.CULL_FACE)
        ctx.enable(moderngl.BLEND)
        ctx.blend_func = (moderngl.SRC_ALPHA, moderngl.ONE_MINUS_SRC_ALPHA)
        prog["u_screen"].value = (float(size[0]), float(size[1]))
        prog["u_cam"].value = (float(view[0]), float(view[1]))
        prog["u_zoom"].value = float(view[2])
        prog["u_rot"].value = (math.cos(view[3]), math.sin(view[3]))
        run = None
        data = array("f")
        n = 0
        for s in items:
            tex = s.texture
            if tex is not run:
                if n:
                    self._flush(run, data, n)
                run = tex
                data = array("f")
                n = 0
            data.extend(s.row(camx, camy))
            n += 1
        if n:
            self._flush(run, data, n)
        ctx.disable(moderngl.BLEND)

    def _flush(self, tex, data, n):
        raw = data.tobytes()
        if len(raw) > self.cap:
            self.cap = max(len(raw), self.cap * 2)
            self.buf.orphan(self.cap)
        else:
            self.buf.orphan()
        self.buf.write(raw)
        tex.use(0)
        self.vao.render(moderngl.TRIANGLE_STRIP, vertices=4, instances=n)
        self.calls += 1

    def release(self):
        for obj in (self.vao, self.buf, self.prog, self.white, self.missing):
            try:
                obj.release()
            except Exception:
                pass
