import re

import glfw

_ALIAS = {
    "esc": "escape", "return": "enter", "del": "delete", "pgup": "page_up", "pgdn": "page_down",
    "pgdown": "page_down", "ins": "insert", "caps": "caps_lock", "lshift": "left_shift",
    "rshift": "right_shift", "lctrl": "left_control", "rctrl": "right_control", "lalt": "left_alt",
    "ralt": "right_alt", "ctrl": "control", "spacebar": "space",
}
_GROUP = {
    "shift": ("left_shift", "right_shift"),
    "control": ("left_control", "right_control"),
    "alt": ("left_alt", "right_alt"),
}
PRESETS = {
    "wasd": {"left": ["a"], "right": ["d"], "up": ["w"], "down": ["s"]},
    "arrows": {"left": ["left"], "right": ["right"], "up": ["up"], "down": ["down"]},
    "ijkl": {"left": ["j"], "right": ["l"], "up": ["i"], "down": ["k"]},
}
PRESETS["both"] = {k: PRESETS["wasd"][k] + PRESETS["arrows"][k] for k in PRESETS["wasd"]}
BUTTONS = {"left": 0, "right": 1, "middle": 2}


def _code(token):
    return getattr(glfw, "KEY_" + token.upper(), None)


def key_codes(name):
    if isinstance(name, int) and not isinstance(name, bool):
        return (name,)
    n = str(name).strip().lower().replace(" ", "_").replace("-", "_")
    n = _ALIAS.get(n, n)
    if n in _GROUP:
        return tuple(_code(x) for x in _GROUP[n])
    c = _code(n) if n else None
    return (c,) if c is not None else ()


def key_names():
    names = [n[4:].lower() for n in dir(glfw) if n.startswith("KEY_") and n != "KEY_LAST"]
    return names + list(_ALIAS) + list(_GROUP)


def button_code(value):
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value
    return BUTTONS.get(str(value).strip().lower())


class Input:
    def __init__(self):
        self.down_keys = set()
        self.pressed_keys = set()
        self.released_keys = set()
        self.buttons = set()
        self.buttons_pressed = set()
        self.buttons_released = set()
        self.scroll = 0.0

    def key_event(self, key, action):
        if action == glfw.PRESS:
            self.down_keys.add(key)
            self.pressed_keys.add(key)
        elif action == glfw.RELEASE:
            self.down_keys.discard(key)
            self.released_keys.add(key)

    def button_event(self, button, action):
        if action == glfw.PRESS:
            self.buttons.add(button)
            self.buttons_pressed.add(button)
        elif action == glfw.RELEASE:
            self.buttons.discard(button)
            self.buttons_released.add(button)

    def down(self, name):
        return any(c in self.down_keys for c in key_codes(name))

    def pressed(self, name):
        return any(c in self.pressed_keys for c in key_codes(name))

    def released(self, name):
        return any(c in self.released_keys for c in key_codes(name))

    def mouse_down(self, button=0):
        return button in self.buttons

    def mouse_pressed(self, button=0):
        return button in self.buttons_pressed

    def axis(self, negative, positive):
        return (1.0 if self.down(positive) else 0.0) - (1.0 if self.down(negative) else 0.0)

    def clear(self):
        self.down_keys.clear()
        self.buttons.clear()

    def end_frame(self):
        self.pressed_keys.clear()
        self.released_keys.clear()
        self.buttons_pressed.clear()
        self.buttons_released.clear()
        self.scroll = 0.0


class Controls:
    DIRS = ("left", "right", "up", "down")

    def __init__(self):
        self.names = {d: [] for d in self.DIRS}
        self.codes = {d: () for d in self.DIRS}
        self.click = False
        self.mouse = False
        self.horizontal = False
        self.vertical = False

    @classmethod
    def parse(cls, spec):
        c = cls()
        bad = []
        if spec is True:
            spec = "both"
        if isinstance(spec, dict):
            for k, v in spec.items():
                key = str(k).lower()
                if key in c.names:
                    for n in (v if isinstance(v, (list, tuple)) else [v]):
                        if key_codes(n):
                            c.names[key].append(n)
                        else:
                            bad.append(str(n))
                elif key in ("click", "mouse"):
                    setattr(c, key, bool(v))
                else:
                    bad.append(str(k))
        else:
            tokens = re.split(r"[+,\s]+", spec) if isinstance(spec, str) else [str(t) for t in spec]
            for t in tokens:
                t = t.strip().lower()
                if not t or t == "none":
                    continue
                if t in PRESETS:
                    for d, keys in PRESETS[t].items():
                        c.names[d].extend(keys)
                elif t in ("click", "mouse"):
                    setattr(c, t, True)
                else:
                    bad.append(t)
        for d in cls.DIRS:
            seen = []
            for n in c.names[d]:
                for code in key_codes(n):
                    if code not in seen:
                        seen.append(code)
            c.codes[d] = tuple(seen)
        c.horizontal = bool(c.codes["left"] or c.codes["right"])
        c.vertical = bool(c.codes["up"] or c.codes["down"])
        return c, bad

    @property
    def empty(self):
        return not (self.horizontal or self.vertical or self.click or self.mouse)

    def vector(self, inp):
        d = inp.down_keys
        x = (1.0 if any(k in d for k in self.codes["right"]) else 0.0) - (1.0 if any(k in d for k in self.codes["left"]) else 0.0)
        y = (1.0 if any(k in d for k in self.codes["up"]) else 0.0) - (1.0 if any(k in d for k in self.codes["down"]) else 0.0)
        if x and y:
            x *= 0.7071067811865476
            y *= 0.7071067811865476
        return x, y
