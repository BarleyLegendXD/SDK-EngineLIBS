import math


def _out(f):
    return lambda t: 1.0 - f(1.0 - t)


def _in_out(f):
    return lambda t: 0.5 * f(2.0 * t) if t < 0.5 else 1.0 - 0.5 * f(2.0 - 2.0 * t)


def _bounce_out(t):
    n1, d1 = 7.5625, 2.75
    if t < 1 / d1:
        return n1 * t * t
    if t < 2 / d1:
        t -= 1.5 / d1
        return n1 * t * t + 0.75
    if t < 2.5 / d1:
        t -= 2.25 / d1
        return n1 * t * t + 0.9375
    t -= 2.625 / d1
    return n1 * t * t + 0.984375


_IN = {
    "quad": lambda t: t * t,
    "cubic": lambda t: t ** 3,
    "quart": lambda t: t ** 4,
    "quint": lambda t: t ** 5,
    "sine": lambda t: 1.0 - math.cos(t * math.pi / 2.0),
    "expo": lambda t: 0.0 if t <= 0 else 2.0 ** (10.0 * t - 10.0),
    "circ": lambda t: 1.0 - math.sqrt(max(0.0, 1.0 - t * t)),
    "back": lambda t: t * t * (2.70158 * t - 1.70158),
    "bounce": lambda t: 1.0 - _bounce_out(1.0 - t),
    "elastic": lambda t: 0.0 if t <= 0 else 1.0 if t >= 1 else -(2.0 ** (10.0 * t - 10.0)) * math.sin((t * 10.0 - 10.75) * (2.0 * math.pi / 3.0)),
}

EASINGS = {"linear": lambda t: t}
for _name, _f in _IN.items():
    EASINGS["in_" + _name] = _f
    EASINGS["out_" + _name] = _out(_f)
    EASINGS["in_out_" + _name] = _in_out(_f)
EASINGS["smooth"] = EASINGS["in_out_cubic"]


def get_ease(ease):
    if callable(ease):
        return ease
    return EASINGS.get(str(ease).strip().lower())


def _snap(v):
    if isinstance(v, (list, tuple)):
        return tuple(float(x) for x in v)
    return float(v)


def _mix(a, b, e):
    if isinstance(a, tuple):
        return tuple(x + (y - x) * e for x, y in zip(a, b))
    return a + (b - a) * e


class Tween:
    def __init__(self, target, props, duration, ease, delay=0.0, on_done=None, repeat=0, yoyo=False):
        self.target = target
        self.end = {k: _snap(v) for k, v in props.items()}
        self.start = None
        self.duration = max(1e-6, float(duration))
        self.ease = ease
        self.delay = float(delay)
        self.on_done = on_done
        self.repeat = int(repeat)
        self.yoyo = bool(yoyo)
        self.t = 0.0
        self.done = False

    def drop(self, keys):
        for k in keys:
            self.end.pop(k, None)
            if self.start:
                self.start.pop(k, None)
        if not self.end:
            self.done = True

    def _apply(self, e):
        for k, b in self.end.items():
            setattr(self.target, k, _mix(self.start[k], b, e))

    def update(self, dt):
        if self.delay > 0.0:
            self.delay -= dt
            if self.delay > 0.0:
                return
            dt = -self.delay
            self.delay = 0.0
        if self.start is None:
            self.start = {k: _snap(getattr(self.target, k)) for k in self.end}
        self.t += dt
        p = self.t / self.duration
        if p < 1.0:
            self._apply(self.ease(p))
            return
        self._apply(1.0)
        if self.repeat != 0:
            if self.repeat > 0:
                self.repeat -= 1
            if self.yoyo:
                self.start, self.end = self.end, self.start
            self.t = 0.0
            return
        self.done = True


class TweenList:
    def __init__(self, safe=None):
        self.items = []
        self.safe = safe

    def add(self, tw):
        for old in self.items:
            if old.target is tw.target and not old.done:
                shared = [k for k in tw.end if k in old.end]
                if shared:
                    old.drop(shared)
        self.items.append(tw)
        return tw

    def clear(self, target=None):
        if target is None:
            self.items = []
        else:
            self.items = [t for t in self.items if t.target is not target]

    def busy(self, target, keys):
        return any(t.target is target and not t.done and any(k in t.end for k in keys) for t in self.items)

    def update(self, dt):
        if not self.items:
            return
        items, self.items = self.items, []
        for tw in items:
            if tw.done or getattr(tw.target, "alive", True) is False:
                continue
            tw.update(dt)
            if tw.done:
                if tw.on_done is not None:
                    if self.safe:
                        self.safe(tw.on_done, "tween", "done", tw.target)
                    else:
                        tw.on_done(tw.target)
            else:
                self.items.append(tw)


class Clip:
    def __init__(self, name, frames, fps, loop, pingpong, nxt, speed, on_end, events):
        self.name = name
        self.frames = list(frames)
        self.seq = list(frames) + (list(frames[-2:0:-1]) if pingpong and len(frames) > 2 else [])
        self.fps = fps
        self.loop = loop
        self.next = nxt
        self.speed = speed
        self.on_end = on_end
        self.events = events


def parse_frames(spec):
    if isinstance(spec, bool):
        raise ValueError("frames cannot be a bool")
    if isinstance(spec, int):
        return [spec]
    if isinstance(spec, str):
        out = []
        for part in spec.replace(" ", "").split(","):
            if not part:
                continue
            if "-" in part[1:]:
                a, b = part.split("-", 1)
                a, b = int(a), int(b)
                out.extend(range(a, b + 1) if a <= b else range(a, b - 1, -1))
            else:
                out.append(int(part))
        return out
    if isinstance(spec, (list, tuple, range)):
        return [int(i) for i in spec]
    raise ValueError(f"unsupported frames value {spec!r}")


def parse_clip(name, spec, default_fps, cols, rows):
    opts = {}
    if isinstance(spec, dict):
        opts = dict(spec)
        if "row" in opts:
            start = int(opts.get("start", 0))
            count = int(opts.get("count", cols - start))
            frames = [int(opts["row"]) * cols + start + i for i in range(count)]
        elif "col" in opts:
            start = int(opts.get("start", 0))
            count = int(opts.get("count", rows - start))
            frames = [(start + i) * cols + int(opts["col"]) for i in range(count)]
        elif "frames" in opts:
            frames = parse_frames(opts["frames"])
        else:
            raise ValueError("a dict clip needs 'frames', 'row' or 'col'")
    else:
        frames = parse_frames(spec)
    if not frames:
        raise ValueError("clip has no frames")
    return Clip(
        name, frames, float(opts.get("fps", default_fps)), bool(opts.get("loop", True)),
        bool(opts.get("pingpong", False)), opts.get("next"), float(opts.get("speed", 1.0)),
        opts.get("on_end"), dict(opts.get("events", {})),
    )


class Animator:
    def __init__(self, owner):
        self.owner = owner
        self.clips = {}
        self.clip = None
        self.t = 0.0
        self.idx = -1
        self.playing = False
        self.finished = False
        self.speed = 1.0
        self.fps = 0.0
        self.loop = True
        self.end_cb = None

    @property
    def name(self):
        return self.clip.name if self.clip else None

    def play(self, name, restart=False, speed=None, fps=None, loop=None, on_end=None):
        clip = self.clips.get(name)
        if clip is None:
            return False
        same = self.clip is clip and self.playing
        if same and not restart:
            if speed is not None:
                self.speed = float(speed)
            return True
        self.clip = clip
        self.t = 0.0
        self.idx = -1
        self.playing = True
        self.finished = False
        self.speed = 1.0 if speed is None else float(speed)
        self.fps = clip.fps if fps is None else float(fps)
        self.loop = clip.loop if loop is None else bool(loop)
        self.end_cb = on_end if on_end is not None else clip.on_end
        self.update(0.0)
        return True

    def update(self, dt):
        c = self.clip
        if c is None or not self.playing:
            return
        n = len(c.seq)
        self.t += dt * self.speed * c.speed
        pos = int(self.t * self.fps) if self.fps > 0 else 0
        ended = False
        if self.fps <= 0:
            idx = 0
        elif self.loop:
            idx = pos % n
        elif pos >= n:
            idx = n - 1
            ended = True
        else:
            idx = pos
        if idx != self.idx:
            self.idx = idx
            self.owner.set_frame(c.seq[idx])
            ev = c.events.get(idx)
            if ev is not None:
                self.owner.mgr.call(ev, self.owner.name, "anim_event", self.owner)
        if ended:
            self.playing = False
            self.finished = True
            if self.end_cb is not None:
                self.owner.mgr.call(self.end_cb, self.owner.name, "anim_end", self.owner)
            self.owner.fire("anim_end", c.name)
            if c.next and self.clip is c:
                self.play(c.next, restart=True)
