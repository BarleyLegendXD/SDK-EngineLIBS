H = """#version 330
uniform vec4 u_cam;
uniform vec2 u_size;
vec2 toWorld(vec2 uv){vec2 p=(uv-0.5)*u_size/u_cam.z;float c=cos(u_cam.w),s=sin(u_cam.w);return u_cam.xy+vec2(c*p.x-s*p.y,s*p.x+c*p.y);}
vec2 toUV(vec2 w){vec2 d=w-u_cam.xy;float c=cos(u_cam.w),s=sin(u_cam.w);return vec2(c*d.x+s*d.y,-s*d.x+c*d.y)*u_cam.z/u_size+0.5;}
float hash(vec2 p){p=fract(p*vec2(123.34,456.21));p+=dot(p,p+45.32);return fract(p.x*p.y);}
float vn(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.0-2.0*f);return mix(mix(hash(i),hash(i+vec2(1.0,0.0)),f.x),mix(hash(i+vec2(0.0,1.0)),hash(i+vec2(1.0)),f.x),f.y);}
float fbm(vec2 p){float a=0.5,s=0.0;for(int i=0;i<5;i++){s+=a*vn(p);p=p*2.03+17.1;a*=0.5;}return s;}
float ign(vec2 p){return fract(52.9829189*fract(dot(p,vec2(0.06711056,0.00583715))));}
float lum(vec3 c){return dot(c,vec3(0.2126,0.7152,0.0722));}
"""

VS = """#version 330
out vec2 uv;
void main(){vec2 k=vec2(gl_VertexID&1,gl_VertexID>>1);uv=k;gl_Position=vec4(k*2.0-1.0,0.0,1.0);}"""

VSR = """#version 330
uniform vec4 u_r;
out vec2 uv;
void main(){vec2 k=vec2(gl_VertexID&1,gl_VertexID>>1);uv=mix(u_r.xy,u_r.zw,k);gl_Position=vec4(uv*2.0-1.0,0.0,1.0);}"""

LIGHT = H + """
in vec2 uv;
out vec4 o;
uniform sampler2D u_scene;
uniform vec4 u_l,u_c,u_s,u_p;
uniform vec2 u_tex;
uniform float u_bump;
uniform int u_n,u_o;
uniform sampler2D u_ot;
float vis(vec2 a,vec2 b){
  vec2 d=b-a;
  d=mix(d,vec2(1e-4),lessThan(abs(d),vec2(1e-4)));
  vec2 inv=1.0/d;
  for(int i=0;i<u_n;i++){
    int q=u_o+i;
    vec4 r=texelFetch(u_ot,ivec2(q&1023,q>>10),0);
    if(a.x>r.x&&a.x<r.z&&a.y>r.y&&a.y<r.w)continue;
    vec2 t0=(r.xy-a)*inv,t1=(r.zw-a)*inv;
    vec2 mn=min(t0,t1),mx=max(t0,t1);
    float tn=max(mn.x,mn.y),tf=min(mx.x,mx.y);
    if(tn<tf&&tf>0.0&&tn<1.0)return 0.0;
  }
  return 1.0;
}
void main(){
  vec2 w=toWorld(uv);
  vec2 d=w-u_l.xy;
  float dist=length(d);
  if(dist>=u_l.z)discard;
  float x=dist/u_l.z;
  float att=pow(clamp(1.0-x*x*x*x,0.0,1.0),2.0)/(1.0+9.0*x*x);
  vec2 dn=d/max(dist,1e-3);
  float cone=smoothstep(u_s.z,u_s.w,dot(dn,u_s.xy));
  if(cone<=0.0)discard;
  float l1=lum(texture(u_scene,uv+vec2(u_tex.x,0.0)).rgb),l2=lum(texture(u_scene,uv-vec2(u_tex.x,0.0)).rgb);
  float l3=lum(texture(u_scene,uv+vec2(0.0,u_tex.y)).rgb),l4=lum(texture(u_scene,uv-vec2(0.0,u_tex.y)).rgb);
  vec2 g=vec2(l1-l2,l3-l4)*u_bump;g*=min(1.0,0.5/max(length(g),1e-4));vec3 n=normalize(vec3(-g,1.0));
  float c=cos(u_cam.w),s=sin(u_cam.w);
  vec2 sd=vec2(c*d.x+s*d.y,-s*d.x+c*d.y);
  vec3 L=normalize(vec3(-sd,u_l.w));
  float diff=clamp(dot(n,L)/max(L.z,0.15),0.0,2.5);
  vec3 H2=normalize(L+vec3(0.0,0.0,1.0));
  float sp=pow(max(dot(n,H2),0.0),24.0)*u_c.w*(0.25+lum(texture(u_scene,uv).rgb));
  float sh=1.0;
  if(u_n>0){
    int ns=int(u_p.y);
    float rot=ign(gl_FragCoord.xy)*6.2831853;
    float acc=0.0;
    for(int i=0;i<ns;i++){
      float r=sqrt((float(i)+0.5)/float(ns));
      float a=float(i)*2.39996323+rot;
      acc+=vis(w,u_l.xy+vec2(cos(a),sin(a))*r*u_p.x);
    }
    sh=acc/float(ns);
  }
  o=vec4(u_c.rgb*(att*cone*sh)*(diff+sp),1.0);
}"""

SHV = H + """
uniform vec2 u_off;
uniform float u_fade;
uniform int u_base;
in vec4 i_r;
in float i_h;
out vec2 v;
void main(){
  int id=gl_VertexID+u_base;
  int q=id/6;
  int vi=id-q*6;
  int k=vi==0?0:(vi==1?1:(vi==2?2:(vi==3?2:(vi==4?1:3))));
  vec2 c[4]=vec2[4](i_r.xy,vec2(i_r.z,i_r.y),i_r.zw,vec2(i_r.x,i_r.w));
  vec2 p;
  float t=0.0;
  vec2 o2=u_off*i_h;
  if(q==4){
    p=vec2(k==1||k==3?i_r.z:i_r.x,k>=2?i_r.w:i_r.y);
  }else{
    vec2 a=c[q],b=c[(q+1)%4];
    p=(k==0||k==2)?a:b;
    if(k>=2){p+=o2;t=1.0;}
  }
  vec2 d=p-u_cam.xy;
  float cs=cos(u_cam.w),sn=sin(u_cam.w);
  vec2 s=vec2(cs*d.x+sn*d.y,-sn*d.x+cs*d.y)*u_cam.z;
  gl_Position=vec4(s/(u_size*0.5),0.0,1.0);
  v=vec2(1.0-t*u_fade,t);
}"""

SHF = """#version 330
in vec2 v;
out vec4 o;
uniform float u_zero;
void main(){o=vec4(v*(1.0-u_zero),0.0,1.0);}"""

SUN = H + """
in vec2 uv;
out vec4 o;
uniform sampler2D u_scene,u_mask;
uniform vec3 u_col,u_ldir;
uniform vec2 u_tex;
uniform float u_bump,u_sh,u_blur,u_usem;
void main(){
  float sh=0.0;
  if(u_usem>0.5){
    float m=texture(u_mask,uv).g;
    vec2 k=vec2(1.0,u_size.x/u_size.y)*(2.0+u_blur*(0.3+m*1.7))/u_size.x;
    float rot=ign(gl_FragCoord.xy)*6.2831853;
    for(int i=0;i<12;i++){
      float a=float(i)*2.39996323+rot;
      float q=sqrt((float(i)+0.5)/12.0);
      sh+=texture(u_mask,uv+vec2(cos(a),sin(a))*q*k).r;
    }
    sh=sh/12.0*u_sh;
  }
  float l1=lum(texture(u_scene,uv+vec2(u_tex.x,0.0)).rgb),l2=lum(texture(u_scene,uv-vec2(u_tex.x,0.0)).rgb);
  float l3=lum(texture(u_scene,uv+vec2(0.0,u_tex.y)).rgb),l4=lum(texture(u_scene,uv-vec2(0.0,u_tex.y)).rgb);
  vec2 g=vec2(l1-l2,l3-l4)*u_bump;g*=min(1.0,0.5/max(length(g),1e-4));vec3 n=normalize(vec3(-g,1.0));
  float diff=clamp(dot(n,u_ldir)/max(u_ldir.z,0.15),0.0,2.5);
  o=vec4(u_col*diff*(1.0-sh),1.0);
}"""

COMP = H + """
in vec2 uv;
out vec4 o;
uniform sampler2D u_scene,u_lmap,u_emis;
uniform vec2 u_sl;
uniform float u_time,u_eg;
uniform vec3 u_fogc,u_wc;
uniform vec4 u_fog;
uniform vec2 u_wind;
uniform int u_nw;
uniform vec4 u_wr[40],u_wp[40];
vec3 lit(vec2 p){vec3 s=pow(texture(u_scene,p).rgb,vec3(2.2));float m=smoothstep(u_sl.y,u_sl.y+0.25,lum(s))*u_sl.x;return max(s*texture(u_lmap,p).rgb,s*m);}
void main(){
  vec2 w=toWorld(uv);
  vec3 lm=texture(u_lmap,uv).rgb;
  vec3 col=lit(uv);
  for(int i=0;i<u_nw;i++){
    vec4 r=u_wr[i],p=u_wp[i];
    if(w.x>r.x&&w.x<r.z&&w.y>r.y&&w.y<r.w){
      float dp=clamp((r.w-w.y)/max(p.z,1.0),0.0,1.0);
      float n1=fbm(vec2(w.x*0.03+u_time*p.w*0.4,w.y*0.12-u_time*p.w*0.25));
      float n2=fbm(vec2(w.x*0.05-u_time*p.w*0.3,w.y*0.09+u_time*p.w*0.2)+9.0);
      vec2 rip=vec2(n1-0.5,n2-0.5)*p.y*(0.4+dp);
      vec2 mu=toUV(vec2(w.x+rip.x,2.0*r.w-w.y+rip.y));
      float ok=step(0.0,mu.x)*step(mu.x,1.0)*step(0.0,mu.y)*step(mu.y,1.0);
      vec3 refl=mix(lm*vec3(0.25,0.35,0.5),lit(clamp(mu,0.001,0.999)),ok);
      vec3 under=lit(clamp(toUV(w+rip*0.6),0.001,0.999))*u_wc;
      float fr=p.x*mix(0.9,0.25,dp);
      col=mix(under,refl,fr);
      col+=pow(smoothstep(0.55,0.85,n1*0.6+n2*0.6),3.0)*lum(lm)*p.x*0.8;
      break;
    }
  }
  vec4 e=texture(u_emis,uv);
  col=col*(1.0-e.a)+pow(max(e.rgb,0.0),vec3(2.2))*u_eg;
  if(u_fog.x>0.0){
    vec2 q=w*0.004*u_fog.y;
    float n=fbm(q+u_wind*u_time*0.002)*0.65+fbm(q*2.7-u_wind*u_time*0.003+5.0)*0.35;
    float hf=mix(1.0,exp(-max(w.y-u_fog.w,0.0)*0.004),u_fog.z);
    float d=clamp(u_fog.x*(0.3+1.4*n)*hf,0.0,0.95);
    vec3 fc=pow(u_fogc,vec3(2.2))*(lm*0.85+0.03);
    col=mix(col,fc,d);
  }
  col=clamp(col,0.0,32.0);
  if(isnan(col.r+col.g+col.b))col=vec3(0.0);
  o=vec4(col,1.0);
}"""

BLUR = """#version 330
in vec2 uv;
out vec4 o;
uniform sampler2D u_src;
uniform vec2 u_px;
uniform float u_thr,u_w;
vec3 s(vec2 k){vec3 c=texture(u_src,uv+k*u_px).rgb;if(isnan(c.r+c.g+c.b))return vec3(0.0);return clamp(c,0.0,64.0);}
void main(){
  vec3 c=s(vec2(0.0))*4.0+(s(vec2(1.0,0.0))+s(vec2(-1.0,0.0))+s(vec2(0.0,1.0))+s(vec2(0.0,-1.0)))*2.0+s(vec2(1.0))+s(vec2(-1.0,1.0))+s(vec2(1.0,-1.0))+s(vec2(-1.0));
  c/=16.0;
  if(u_thr>0.0){
    float l=max(c.r,max(c.g,c.b));
    float kn=u_thr*0.5;
    float q=clamp(l-u_thr+kn,0.0,2.0*kn);
    q=q*q/(4.0*kn+1e-4);
    c*=max(q,l-u_thr)/max(l,1e-4);
  }
  o=vec4(c*u_w,1.0);
}"""

ADAPT = """#version 330
in vec2 uv;
out vec4 o;
uniform sampler2D u_hdr,u_prev;
uniform float u_a,u_key,u_lo,u_hi;
void main(){
  float l=dot(textureLod(u_hdr,vec2(0.5),12.0).rgb,vec3(0.2126,0.7152,0.0722));
  float p=texture(u_prev,vec2(0.5)).r;
  if(isnan(p)||isinf(p))p=1.0;
  if(isnan(l)||isinf(l))l=u_key;
  float t=clamp(u_key/(l+1e-3),u_lo,u_hi);
  o=vec4(clamp(mix(p,t,u_a),u_lo,u_hi),0.0,0.0,1.0);
}"""

FINAL = H + """
in vec2 uv;
out vec4 o;
uniform sampler2D u_hdr,u_b0,u_b1,u_b2,u_ad;
uniform vec3 u_tint;
uniform vec2 u_sun;
uniform float u_time,u_gt,u_gs,u_bloom,u_flare,u_streak,u_rays,u_ca,u_vig,u_grain,u_sat,u_con,u_exp,u_adapt;
float ih(uvec2 p,uint s){uint n=p.x*1597334673u^p.y*3812015801u^s*2654435761u;n=(n^(n>>16))*2246822519u;n^=n>>13;n*=3266489917u;n^=n>>16;return float(n)*(1.0/4294967296.0);}
vec3 aces(vec3 x){return clamp((x*(2.51*x+0.03))/(x*(2.43*x+0.59)+0.14),0.0,1.0);}
void main(){
  vec2 c=uv-0.5;
  vec2 ca=c*u_ca*dot(c,c)*4.0;
  vec3 h=vec3(textureLod(u_hdr,uv+ca,0.0).r,textureLod(u_hdr,uv,0.0).g,textureLod(u_hdr,uv-ca,0.0).b);
  vec3 b=texture(u_b0,uv).rgb*u_bloom;
  vec3 g=vec3(0.0);
  for(int i=1;i<5;i++){
    vec2 gu=0.5-c*float(i)*0.6;
    float f=1.0-smoothstep(0.0,0.5,length(gu-0.5));
    g+=texture(u_b2,gu).rgb*f*(0.5+0.5*cos(6.2832*(vec3(0.0,0.33,0.67)+float(i)*0.21)));
  }
  vec3 st=vec3(0.0);
  for(int i=-8;i<=8;i++)st+=texture(u_b1,uv+vec2(float(i)*0.014,0.0)).rgb*(1.0-abs(float(i))/9.0);
  st*=vec3(0.45,0.7,1.0)/9.0;
  vec3 gr=vec3(0.0);
  vec2 p=uv;
  vec2 dl=(u_sun-uv)*0.04;
  float dc=1.0;
  for(int i=0;i<24;i++){p+=dl;gr+=texture(u_b1,p).rgb*dc;dc*=0.94;}
  gr*=u_rays/24.0;
  float ex=mix(1.0,texture(u_ad,vec2(0.5)).r,u_adapt)*u_exp;
  vec3 col=(h+b+g*u_flare+st*u_streak+gr)*ex;
  if(isnan(col.r+col.g+col.b))col=vec3(0.0);
  col=clamp(col,0.0,64.0);
  col=pow(aces(col),vec3(1.0/2.2));
  float l=lum(col);
  col=mix(vec3(l),col,u_sat);
  col=(col-0.5)*u_con+0.5;
  col*=u_tint;
  col*=1.0-u_vig*smoothstep(0.3,1.0,length(c*vec2(u_size.x/u_size.y,1.0)*1.4));
  uvec2 gp=uvec2(gl_FragCoord.xy/max(u_gs,1.0));
  uint gt=uint(u_gt);
  float g1=ih(gp,gt),g2=ih(gp,gt+7919u),g3=ih(gp,gt+104729u);
  float gn=(g1+g2+g3)/3.0-0.5;
  float amp=u_grain*0.25*(0.5+2.0*l*(1.0-l));
  col+=vec3(gn)*amp+(vec3(g1,g2,g3)-0.5)*amp*0.2;
  col+=(ign(gl_FragCoord.xy)-0.5)/255.0;
  o=vec4(clamp(col,0.0,1.0),1.0);
}"""

BLIT = """#version 330
in vec2 uv;
out vec4 o;
uniform sampler2D u_src;
void main(){o=vec4(texture(u_src,uv).rgb,1.0);}"""
