NAME = "VRlight"
VERSION = "1.0.0"
ENGINE = ">=2.1.0"
PRIORITY = 10

SYSTEM = None

from . import system as _system


def _vrlight(engine):
    return SYSTEM


def _light(engine, x=0.0, y=0.0, **kw):
    return SYSTEM.light(x, y, **kw)


def _fx_light(engine, spec, x=0.0, y=0.0, light=None, **kw):
    return SYSTEM.fx_light(spec, x, y, light, **kw)


def init(engine):
    global SYSTEM
    SYSTEM = _system.VRLight(engine)
    engine.state["vrlight"] = SYSTEM
    engine.add_method("engine", "vrlight", _vrlight)
    engine.add_method("engine", "light", _light)
    engine.add_method("engine", "fx_light", _fx_light)
    engine.log(f"[VRlight] v{VERSION} ready, engine.vrlight() / engine.light(x, y, preset='torch')", (120, 230, 255))


def shutdown(engine):
    global SYSTEM
    if SYSTEM is not None:
        SYSTEM.shutdown()
    engine.state.pop("vrlight", None)
    SYSTEM = None
