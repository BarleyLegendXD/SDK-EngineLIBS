import fnmatch
import math
import random
import traceback

import moderngl
import numpy as np

from . import shaders as S

MISSING = object()
MAX_CASTERS = 20480
MAX_WATERS = 40

NAMES = {
    "white": (1.0, 1.0, 1.0), "red": (1.0, 0.15, 0.1), "orange": (1.0, 0.5, 0.15), "yellow": (1.0, 0.9, 0.3),
    "green": (0.3, 1.0, 0.3), "cyan": (0.3, 0.9, 1.0), "blue": (0.25, 0.4, 1.0), "purple": (0.65, 0.3, 1.0),
    "pink": (1.0, 0.4, 0.7), "warm": (1.0, 0.8, 0.55), "cold": (0.6, 0.75, 1.0), "moon": (0.5, 0.6, 1.0),
}

PRESETS = {
    "torch": dict(color=(1.0, 0.55, 0.2), radius=380, intensity=1.7, flicker=0.3, speed=9, soft=14),
    "candle": dict(color=(1.0, 0.65, 0.3), radius=200, intensity=1.1, flicker=0.35, speed=11, soft=5),
    "fire": dict(color=(1.0, 0.45, 0.12), radius=460, intensity=2.0, flicker=0.35, speed=8, soft=22),
    "lamp": dict(color=(1.0, 0.85, 0.6), radius=520, intensity=1.5, flicker=0.02, speed=3, soft=20),
    "lantern": dict(color=(1.0, 0.75, 0.4), radius=340, intensity=1.4, flicker=0.12, speed=5, soft=10),
    "neon": dict(color=(0.3, 0.6, 1.0), radius=420, intensity=1.6, flicker=0.08, speed=30, soft=16, spec=1.0),
    "flashlight": dict(color=(1.0, 0.95, 0.8), radius=760, intensity=2.2, cone=40, soft=3, spec=0.8),
    "headlight": dict(color=(1.0, 0.97, 0.85), radius=900, intensity=2.4, cone=55, soft=4),
    "ember": dict(color=(1.0, 0.35, 0.08), radius=140, intensity=0.9, flicker=0.5, speed=14, soft=3),
    "magic": dict(color=(0.55, 0.4, 1.0), radius=380, intensity=1.8, flicker=0.15, speed=6, soft=18),
    "moon": dict(color=(0.5, 0.6, 1.0), radius=1200, intensity=0.8, soft=40, shadow=True),
}

WEATHER = {
    "clear": dict(fog=0.0, fog_height=0.0, saturation=1.05, ambient=1.0, rays=0.5),
    "haze": dict(fog=0.22, fog_color=(0.9, 0.8, 0.65), fog_scale=0.7, saturation=0.95, rays=0.8),
    "mist": dict(fog=0.38, fog_color=(0.72, 0.78, 0.85), fog_scale=1.2, fog_height=0.6, saturation=0.9),
    "fog": dict(fog=0.7, fog_color=(0.65, 0.7, 0.76), fog_scale=1.0, fog_height=0.0, saturation=0.8, rays=0.3),
    "storm": dict(fog=0.3, fog_color=(0.4, 0.45, 0.52), fog_scale=1.6, saturation=0.75, ambient=0.6, rays=0.0),
    "smoke": dict(fog=0.55, fog_color=(0.25, 0.23, 0.22), fog_scale=1.4, saturation=0.7, rays=0.2),
}

AMB = np.array([
    (0, .045, .06, .13), (4.5, .05, .07, .15), (5.5, .22, .18, .26), (6.5, .55, .42, .40), (8, .62, .64, .70),
    (12, .66, .72, .82), (16, .62, .64, .70), (17.5, .62, .42, .36), (18.5, .34, .22, .28), (19.5, .09, .09, .19),
    (21, .05, .065, .14), (24, .045, .06, .13),
], "f8")

TINT = np.array([
    (0, .9, .95, 1.1), (5, .9, .95, 1.1), (6.5, 1.1, 1.0, .9), (8, 1.02, 1.0, .98), (16, 1.02, 1.0, .97),
    (17.5, 1.12, .98, .85), (19, 1.0, .95, 1.05), (21, .9, .95, 1.1), (24, .9, .95, 1.1),
], "f8")

DEFAULTS = dict(
    enabled=True, time=18.0, day_length=0.0, ambient=1.0, sun=1.0, moon=1.0,
    shadow=0.85, shadow_soft=8.0, shadow_len=1.0, shadow_fade=0.45, caster_h=0.9,
    fog=0.0, fog_color=(0.65, 0.7, 0.78), fog_scale=1.0, fog_height=0.0, fog_base=0.0, wind=(14.0, 3.0),
    bloom=0.35, threshold=1.1, flare=0.0, streak=0.0, rays=0.3, aberration=0.0015, vignette=0.28,
    grain=0.3, grain_size=1.0, grain_fps=24.0, saturation=1.05, contrast=1.05, exposure=1.0, adapt=0.6, adapt_speed=1.5,
    bump=1.2, quality=1.0, scale=0.5, tint=(1.0, 1.0, 1.0), emissive_gain=1.0,
    self_lit=0.55, self_lit_threshold=0.5,
    max_lights=480, fx_lights=0.8, fx_light_max=100, fx_alpha=True, occ_per_light=480, shadow_budget=1200,
)

LOOKS = {
    "clean": dict(bloom=0.2, threshold=1.3, flare=0.0, streak=0.0, rays=0.15, aberration=0.0, vignette=0.15, grain=0.0, saturation=1.0, contrast=1.0, grain_size=1.0),
    "soft": dict(bloom=0.35, threshold=1.1, flare=0.0, streak=0.0, rays=0.3, aberration=0.0015, vignette=0.28, grain=0.3, saturation=1.05, contrast=1.05, grain_size=1.0),
    "cinematic": dict(bloom=0.5, threshold=0.95, flare=0.2, streak=0.12, rays=0.5, aberration=0.003, vignette=0.4, grain=0.45, saturation=1.08, contrast=1.1, grain_size=1.0),
    "retro": dict(bloom=0.25, threshold=1.2, flare=0.0, streak=0.0, rays=0.0, aberration=0.0, vignette=0.2, grain=0.5, saturation=1.1, contrast=1.12, grain_size=2.0),
}


def col(v, default=(1.0, 1.0, 1.0)):
    if isinstance(v, str):
        v = v.strip().lower()
        if v in NAMES:
            return NAMES[v]
        if v.startswith("#"):
            h = v[1:]
            if len(h) == 3:
                h = "".join(c * 2 for c in h)
            try:
                return tuple(int(h[i:i + 2], 16) / 255.0 for i in (0, 2, 4))
            except ValueError:
                return default
        return default
    try:
        t = [float(c) for c in v][:3]
    except (TypeError, ValueError):
        return default
    if len(t) < 3:
        return default
    if max(t) > 1.0:
        t = [c / 255.0 for c in t]
    return tuple(t)


def smooth(a, b, x):
    t = min(1.0, max(0.0, (x - a) / (b - a)))
    return t * t * (3.0 - 2.0 * t)


def curve(table, t):
    return np.array([np.interp(t, table[:, 0], table[:, i]) for i in (1, 2, 3)])


class Light:
    D = dict(x=0.0, y=0.0, color=(1.0, 0.8, 0.55), intensity=1.0, radius=360.0, angle=0.0, cone=360.0, soft=8.0,
             height=0.35, shadow=True, flicker=0.0, speed=8.0, spec=0.5, offset=(0.0, 0.0), rotate=True,
             fade=30.0, life=None, enabled=True, target=None)

    def __init__(self, **kw):
        self.__dict__.update(Light.D)
        self.__dict__.update(PRESETS.get(kw.pop("preset", None), {}))
        self.__dict__.update(kw)
        self.color = col(self.color)
        self.alive = True
        self.k = 1.0
        self.seed = random.random() * 100.0
        self.rx, self.ry, self.ra = self.x, self.y, self.angle

    def remove(self):
        self.alive = False

    def set(self, **kw):
        if "color" in kw:
            kw["color"] = col(kw["color"])
        self.__dict__.update(kw)
        return self

    def tick(self, dt, t):
        tg = self.target
        self.k = 1.0
        if tg is not None:
            em = getattr(tg, "emitters", None)
            if em is not None:
                live = [e for e in em if e.alive]
                if not live:
                    self.alive = False
                    return
                px, py, ang = live[0].x, live[0].y, 0.0
                self.k = min(1.0, sum(e.n for e in em) / max(self.fade, 1.0))
            else:
                if not getattr(tg, "alive", True):
                    self.alive = False
                    return
                c = getattr(tg, "center", None) or getattr(tg, "pos", None) or (tg.x, tg.y)
                px, py = c[0], c[1]
                ang = math.radians(getattr(tg, "rotation", 0.0)) if self.rotate else 0.0
            ox, oy = self.offset
            ca, sa = math.cos(ang), math.sin(ang)
            self.rx, self.ry = px + ox * ca - oy * sa, py + ox * sa + oy * ca
            self.ra = self.angle + math.degrees(ang)
        else:
            self.rx, self.ry, self.ra = self.x, self.y, self.angle
        if self.flicker > 0.0:
            s, q = self.speed, self.seed
            n = (math.sin(t * s + q) + 0.6 * math.sin(t * s * 2.37 + q * 1.7) + 0.3 * math.sin(t * s * 5.11 + q * 0.3)) / 1.9
            self.k *= 1.0 - self.flicker * (0.5 + 0.5 * n)
        if self.life is not None:
            self.life -= dt
            if self.life <= 0.0:
                self.alive = False
            else:
                self.k *= min(1.0, self.life * 4.0)


def put(prog, **kw):
    for k, v in kw.items():
        n = "u_" + k
        if n in prog:
            prog[n].value = v


class VRLight:
    def __init__(self, engine):
        object.__setattr__(self, "p", dict(DEFAULTS))
        self.engine = engine
        self.ctx = engine.ctx
        self.lights = []
        self.casters = {}
        self.boxes = []
        self.waters = []
        self.tweens = []
        self.glows = []
        self.deferred = []
        self.t = {}
        self.f = {}
        self.size = (0, 0)
        self.ls = 0.0
        self.ad = 0
        self.active = False
        self.flash_v = 0.0
        self.flash_c = (1.0, 1.0, 1.0)
        self.flash_d = 4.0
        self.view = (0.0, 0.0, 1.0, 0.0)
        self.clear = (0.04, 0.04, 0.06, 1.0)
        self.wraps = []
        self.names = []
        self.rules = []
        self.seen = {}
        self.scan_t = 0.0
        self.fails = 0
        ctx = self.ctx
        self.pg = {}
        self.va = {}
        self.sbuf = ctx.buffer(reserve=MAX_CASTERS * 20)
        self.ot = None
        self.ot_rows = 0
        self.cur = None
        self.pend = None
        self.stable = 0
        for n, vs, fs, c in (
            ("light", S.VSR, S.LIGHT, None), ("sun", S.VS, S.SUN, None), ("comp", S.VS, S.COMP, None),
            ("blur", S.VS, S.BLUR, None), ("blit", S.VS, S.BLIT, None), ("adapt", S.VS, S.ADAPT, None), ("final", S.VS, S.FINAL, None),
            ("shadow", S.SHV, S.SHF, [(self.sbuf, "4f 1f/i", "i_r", "i_h")]),
        ):
            pr = ctx.program(vertex_shader=vs, fragment_shader=fs)
            self.pg[n] = pr
            self.va[n] = ctx.vertex_array(pr, c or [])
        self.hs = (("update", self._update, -70), ("draw", self._begin, 100), ("draw", self._end, 5))
        for n, fn, pr in self.hs:
            engine.on(n, fn, priority=pr)
        self.hook()

    def __getattr__(self, k):
        try:
            return self.__dict__["p"][k]
        except KeyError:
            raise AttributeError(k)

    def __setattr__(self, k, v):
        p = self.__dict__.get("p")
        if p is not None and k in p:
            p[k] = v
        else:
            object.__setattr__(self, k, v)

    def set(self, **kw):
        for k, v in kw.items():
            if k not in self.p:
                self.engine.log(f"[VRlight] unknown setting '{k}'", (255, 200, 80))
            else:
                self.p[k] = v
        return self

    def to(self, over=2.0, **kw):
        for k, v in kw.items():
            if k in self.p:
                self.tweens = [w for w in self.tweens if w[0] != k]
                self.tweens.append([k, self.p[k], v, 0.0, max(over, 1e-3)])
        return self

    def weather(self, name, over=3.0):
        w = WEATHER.get(name)
        if w is None:
            self.engine.log(f"[VRlight] unknown weather '{name}', options: {', '.join(WEATHER)}", (255, 200, 80))
            return self
        if over <= 0.0:
            self.p.update(w)
            return self
        return self.to(over, **w)

    def look(self, name, over=0.0):
        w = LOOKS.get(name)
        if w is None:
            self.engine.log(f"[VRlight] unknown look '{name}', options: {', '.join(LOOKS)}", (255, 200, 80))
            return self
        if over <= 0.0:
            self.p.update(w)
            return self
        return self.to(over, **w)

    def rule(self, pattern, light=None, shadow=None, emissive=None):
        self.rules.append((pattern, light, shadow, emissive))
        self.seen = {}
        return self

    def auto(self, cycle=None, time=None, look=None, weather=None, lights=None, shadows=None, fx=None):
        if time is not None:
            self.p["time"] = float(time)
        if cycle is not None:
            self.p["day_length"] = float(cycle)
        if look:
            self.look(look)
        if weather:
            self.weather(weather, 0.0)
        if fx is not None:
            self.p["fx_lights"] = float(fx)
        for pat, v in (lights or {}).items():
            self.rule(pat, light=v)
        for pat in ([shadows] if isinstance(shadows, str) else (shadows or [])):
            self.rule(pat, shadow=True)
        return self

    def _scan(self):
        sm = self.engine.state.get("sprites")
        if sm is None or not self.rules:
            return
        self.seen = {k: v for k, v in self.seen.items() if v.alive}
        for sp in list(sm.sprites.values()):
            if not sp.alive or id(sp) in self.seen:
                continue
            self.seen[id(sp)] = sp
            keys = [sp.name, sp.kind] + list(sp.tags)
            for pat, light, shadow, emi in self.rules:
                if not any(fnmatch.fnmatch(str(k), pat) for k in keys):
                    continue
                if light is not None and getattr(sp, "light", None) is None:
                    self._p_light(sp, light)
                if shadow:
                    self.cast(sp, None if shadow is True else float(shadow))
                if emi is not None:
                    sp.emissive = bool(emi)

    def light(self, x=0.0, y=0.0, **kw):
        lt = Light(x=x, y=y, **kw)
        self.lights.append(lt)
        return lt

    def flash(self, strength=1.0, color="white", decay=4.0):
        self.flash_v, self.flash_c, self.flash_d = strength, col(color), decay
        return self

    def box(self, x0, y0, x1, y1, height=None):
        b = (min(x0, x1), min(y0, y1), max(x0, x1), max(y0, y1), height or 0.0)
        self.boxes.append(b)
        return b

    def cast(self, sprite, height=None):
        self.casters[id(sprite)] = (sprite, height)
        return sprite

    def uncast(self, sprite):
        self.casters.pop(id(sprite), None)

    def water(self, x0, y0, x1, y1, reflect=0.8, wave=14.0, depth=160.0, speed=1.0, tint=(0.6, 0.8, 0.9)):
        w = (min(x0, x1), min(y0, y1), max(x0, x1), max(y0, y1), reflect, wave, depth, speed, col(tint))
        self.waters.append(w)
        return w

    def clear_all(self):
        self.lights.clear()
        self.glows.clear()
        self.boxes.clear()
        self.waters.clear()
        self.casters.clear()
        self.tweens.clear()
        self.flash_v = 0.0

    def fx_light(self, spec, x=0.0, y=0.0, light=None, **kw):
        ps = self.engine.state.get("particles")
        if ps is None:
            return None
        fx = ps.fx(spec, x, y, **kw)
        if fx is not None and light is not False:
            lk = {"preset": light} if isinstance(light, str) else dict(light or {"preset": "fire"})
            self.light(x=x, y=y, target=fx, **lk)
        return fx

    def _wrap(self, obj, name, build):
        prev = obj.__dict__.get(name, MISSING)
        fn = build(getattr(obj, name))
        setattr(obj, name, fn)
        self.wraps.append((obj, name, prev, fn))

    def hook(self):
        st = self.engine.state
        sm = st.get("sprites")
        ps = st.get("particles")
        if sm is not None:
            def sprites(orig):
                def draw(items, view, size, camx, camy):
                    if not self.active:
                        return orig(items, view, size, camx, camy)
                    if items and all(getattr(s, "fixed", False) for s in items):
                        self.deferred.append(lambda: orig(items, view, size, camx, camy))
                        return
                    lit = [s for s in items if not getattr(s, "emissive", False)]
                    em = [s for s in items if getattr(s, "emissive", False)]
                    orig(lit, view, size, camx, camy)
                    if em:
                        self.f["emis"].use()
                        orig(em, view, size, camx, camy)
                        self.f["scene"].use()
                return draw

            self._wrap(sm.renderer, "draw", sprites)
            for k, desc, fn in (
                ("light", "dynamic light: 'torch' or dict(color, radius, intensity, cone, flicker)", self._p_light),
                ("shadow", "True or height, sprite casts shadows", self._p_shadow),
                ("emissive", "True, sprite ignores lighting and glows", self._p_emissive),
            ):
                sm.register_param(k, "VRlight", desc, fn)
                self.names.append(k)
        if ps is not None:
            def passes(od):
                def dp(items, fixed):
                    if not self.active:
                        return od(items, fixed)
                    if fixed:
                        self.deferred.append(lambda: od(items, fixed))
                        return 0
                    return od(items, fixed)
                return dp

            def particles(odr):
                def pdraw(batches, view, size):
                    if not self.active:
                        return odr(batches, view, size)
                    flags = [b[0] in ("add", "screen") or (self.fx_alpha and self._bright(b[2])) for b in batches]
                    lit = [b for b, f in zip(batches, flags) if not f]
                    em = [b for b, f in zip(batches, flags) if f]
                    if lit:
                        odr(lit, view, size)
                    if em:
                        for b in em:
                            self._glow(b[2])
                        self.f["emis"].use()
                        odr(em, view, size)
                        self.f["scene"].use()
                return pdraw

            self._wrap(ps, "_draw_pass", passes)
            self._wrap(ps.renderer, "draw", particles)

    def unhook(self):
        for obj, name, prev, fn in reversed(self.wraps):
            if obj.__dict__.get(name) is fn:
                if prev is MISSING:
                    delattr(obj, name)
                else:
                    setattr(obj, name, prev)
        self.wraps.clear()
        sm = self.engine.state.get("sprites")
        if sm is not None:
            for k in self.names:
                sm.unregister_param(k)
        self.names.clear()

    def _p_light(self, sp, v):
        if isinstance(v, dict):
            kw = dict(v)
        elif isinstance(v, str) and v in PRESETS:
            kw = {"preset": v}
        else:
            kw = {"color": v}
        kw.setdefault("target", sp)
        sp.light = self.light(**kw)

    def _p_shadow(self, sp, v):
        if v:
            self.cast(sp, None if v is True else float(v))

    def _p_emissive(self, sp, v):
        sp.emissive = bool(v)

    def _bright(self, arr):
        try:
            if arr.ndim != 2 or arr.shape[1] != 13 or len(arr) == 0:
                return False
            a = arr[:, 12]
            ws = float(a.sum())
            if ws <= 0.0:
                return False
            c = (arr[:, 9:12] * a[:, None]).sum(0) / ws
            m = float(c.max())
            return m >= 0.7 and (m - float(c.min())) / m > 0.35
        except Exception:
            return False

    def _glow(self, arr):
        try:
            if arr.ndim != 2 or arr.shape[1] != 13 or len(arr) == 0 or self.fx_lights <= 0:
                return
            a = arr[:, 12] * np.maximum(arr[:, 2], arr[:, 3]) ** 2
            ws = float(a.sum())
            if ws < 1.0:
                return
            pos = (arr[:, 0:2] * a[:, None]).sum(0) / ws
            c = (arr[:, 9:12] * a[:, None]).sum(0) / ws
            sp = math.sqrt(float((((arr[:, 0:2] - pos) ** 2).sum(1) * a).sum() / ws))
            inten = min(2.5, math.sqrt(ws) / 90.0) * self.fx_lights
            m = float(c.max())
            if inten < 0.02 or m <= 0.0:
                return
            self.glows.append((float(pos[0]), float(pos[1]), tuple((c / m).tolist()), inten, min(700.0, 60.0 + sp * 2.5 + math.sqrt(ws) * 0.9)))
        except Exception:
            pass

    def _cam(self):
        st = self.engine.state
        sm = st.get("sprites")
        if sm is not None and sm.camera is not None:
            return sm.camera.view()
        ps = st.get("particles")
        if ps is not None:
            return ps.view_state()
        return self.view

    def _update(self, st):
        dt, t = st["dt"], st["time"]
        if self.day_length > 0.0:
            self.p["time"] = (self.p["time"] + dt * 24.0 / self.day_length) % 24.0
        for w in list(self.tweens):
            w[3] += dt
            k = min(1.0, w[3] / w[4])
            a, b = w[1], w[2]
            if isinstance(a, (tuple, list)):
                self.p[w[0]] = tuple(x + (y - x) * k for x, y in zip(a, b))
            else:
                self.p[w[0]] = a + (b - a) * k
            if k >= 1.0:
                self.tweens.remove(w)
        for lt in self.lights:
            lt.tick(dt, t)
        self.lights = [lt for lt in self.lights if lt.alive]
        self.flash_v *= math.exp(-self.flash_d * dt)
        self.scan_t -= dt
        if self.scan_t <= 0.0:
            self.scan_t = 0.25
            self._scan()

    def _free(self):
        for d in (self.f, self.t):
            for o in d.values():
                try:
                    o.release()
                except Exception:
                    pass
            d.clear()

    def _alloc(self, w, h):
        self._free()
        ctx = self.ctx
        ls = self.p["scale"]

        def add(n, tw, th, mip=False, f1=False):
            tx = ctx.texture((max(1, tw), max(1, th)), 4) if f1 else ctx.texture((max(1, tw), max(1, th)), 4, dtype="f2")
            tx.filter = (moderngl.LINEAR_MIPMAP_LINEAR if mip else moderngl.LINEAR, moderngl.LINEAR)
            tx.repeat_x = tx.repeat_y = False
            self.t[n] = tx
            self.f[n] = ctx.framebuffer([tx])

        lw, lh = int(w * ls), int(h * ls)
        add("scene", w, h, f1=True)
        add("emis", w, h)
        add("hdr", w, h, mip=True)
        add("lmap", lw, lh)
        add("mask", lw, lh)
        bw, bh = w, h
        for i in range(5):
            bw, bh = max(2, bw // 2), max(2, bh // 2)
            add(f"b{i}", bw, bh)
        for i in range(2):
            add(f"a{i}", 1, 1)
            self.t[f"a{i}"].write(np.array([1, 0, 0, 1], "f2").tobytes())
        self.size = (w, h)
        self.ls = ls

    def _upload(self, a):
        n = len(a)
        rows = (n + 1023) // 1024
        if self.ot is None or rows > self.ot_rows:
            if self.ot is not None:
                self.ot.release()
            self.ot_rows = max(rows, 16, int(self.ot_rows * 1.5))
            self.ot = self.ctx.texture((1024, self.ot_rows), 4, dtype="f4")
            self.ot.filter = (moderngl.NEAREST, moderngl.NEAREST)
            self.ot.repeat_x = self.ot.repeat_y = False
        pad = np.zeros((rows * 1024, 4), "f4")
        pad[:n] = a
        self.ot.write(pad.tobytes(), viewport=(0, 0, 1024, rows))

    def _begin(self, st):
        w, h = self.engine.screen_size
        if not self.p["enabled"] or w <= 0 or h <= 0:
            self.active = False
            return
        want = (w, h, self.p["scale"])
        if want != self.cur:
            if want != self.pend:
                self.pend = want
                self.stable = 0
            self.stable += 1
            if self.cur is not None and self.stable < 4:
                self.active = False
                return
            self._alloc(w, h)
            self.cur = want
        self.active = True
        self.deferred = []
        self.glows = []
        self.clear = tuple(c / 255.0 for c in self.engine.cfg_color("clear_color", (10, 10, 15))) + (1.0,)
        self.f["emis"].clear(0.0, 0.0, 0.0, 0.0)
        self.f["scene"].use()
        self.f["scene"].clear(*self.clear)

    def _sky(self):
        p = self.p
        t = p["time"] % 24.0
        amb = curve(AMB, t) * p["ambient"]
        tint = curve(TINT, t) * np.array(p["tint"])
        el = math.sin(2 * math.pi * (t - 6.0) / 24.0)
        tm = (t + 12.0) % 24.0
        em = math.sin(2 * math.pi * (tm - 6.0) / 24.0) * 0.85
        si = smooth(0.0, 0.15, el) * p["sun"]
        mi = smooth(0.0, 0.15, em) * (1.0 - smooth(0.0, 0.15, el)) * p["moon"]
        out = []
        for tt, e, i, sun in ((t, el, si, True), (tm, em, mi, False)):
            ax = math.cos(math.pi * (tt - 6.0) / 12.0)
            if sun:
                lo, hi = np.array((1.0, 0.5, 0.22)), np.array((1.0, 0.93, 0.82))
                c = (lo + (hi - lo) * smooth(0.02, 0.5, e)) * i
            else:
                c = np.array((0.42, 0.55, 0.95)) * 0.35 * i
            n = math.hypot(ax, 0.35)
            lh = min(5.0, max(0.25, math.sqrt(max(0.0, 1.0 - e * e)) / max(e, 0.05))) * p["shadow_len"]
            out.append(dict(i=i, c=c, e=e, sd=(-ax / n, -0.35 / n), lv=(ax, 0.35, max(e, 0.1) * 1.2), lh=lh, ax=ax, sun=sun))
        return amb, tint, out

    def _occ(self):
        rows = []
        ch = self.p["caster_h"]
        for k, (sp, h) in list(self.casters.items()):
            if not sp.alive:
                del self.casters[k]
                continue
            if not sp.visible:
                continue
            x0, y0, x1, y1 = sp.rect()
            rows.append((x0, y0, x1, y1, h or max(x1 - x0, y1 - y0) * ch))
        for b in self.boxes:
            rows.append((b[0], b[1], b[2], b[3], b[4] or max(b[2] - b[0], b[3] - b[1]) * ch))
        return np.array(rows, "f4").reshape(-1, 5)[:MAX_CASTERS]

    def _end(self, st):
        if not self.active:
            return
        self.active = False
        ctx = self.ctx
        try:
            self._pipe(st)
        except Exception as e:
            self.fails += 1
            if self.fails <= 3:
                self.engine.log(f"[VRlight] render error: {e}", (255, 80, 80))
                traceback.print_exc()
            try:
                ctx.blend_equation = moderngl.FUNC_ADD
                ctx.disable(moderngl.BLEND)
                ctx.screen.use()
                self.t["scene"].use(0)
                put(self.pg["blit"], src=0)
                self.va["blit"].render(moderngl.TRIANGLE_STRIP, vertices=4)
            except Exception:
                pass
        finally:
            ctx.blend_equation = moderngl.FUNC_ADD
            ctx.disable(moderngl.BLEND)
            ctx.screen.use()
            for fn in self.deferred:
                try:
                    fn()
                except Exception as e:
                    self.engine.log(f"[VRlight] UI draw error: {e}", (255, 80, 80))
            self.deferred = []

    def _pipe(self, st):
        ctx, p, f, t, pg, va = self.ctx, self.p, self.f, self.t, self.pg, self.va
        W, H = self.size
        sz = (float(W), float(H))
        cam = tuple(float(v) for v in self._cam())
        time = st["time"]
        amb, tint, bodies = self._sky()
        amb = amb + np.array(self.flash_c) * self.flash_v
        key = max(bodies, key=lambda b: b["i"])
        occ = self._occ()
        crot, srot = math.cos(cam[3]), math.sin(cam[3])
        ctx.disable(moderngl.DEPTH_TEST | moderngl.CULL_FACE)

        use_mask = key["i"] > 0.003 and len(occ) > 0 and p["shadow"] > 0.0
        mk = f["mask"]
        mk.use()
        mk.clear(0.0, 0.0, 0.0, 1.0)
        if use_mask:
            self.sbuf.write(occ.astype("f4").tobytes())
            pr = pg["shadow"]
            put(pr, cam=cam, size=sz, off=(key["sd"][0] * key["lh"], key["sd"][1] * key["lh"]), fade=p["shadow_fade"])
            ctx.enable(moderngl.BLEND)
            ctx.blend_equation = moderngl.MAX
            ctx.blend_func = (moderngl.ONE, moderngl.ONE)
            put(pr, base=0, zero=0.0)
            va["shadow"].render(moderngl.TRIANGLES, vertices=24, instances=len(occ))
            ctx.blend_equation = moderngl.FUNC_ADD
            ctx.disable(moderngl.BLEND)
            put(pr, base=24, zero=1.0)
            va["shadow"].render(moderngl.TRIANGLES, vertices=6, instances=len(occ))

        lm = f["lmap"]
        lm.use()
        lm.clear(float(amb[0]), float(amb[1]), float(amb[2]), 1.0)
        ctx.enable(moderngl.BLEND)
        ctx.blend_func = (moderngl.ONE, moderngl.ONE)
        t["scene"].use(0)
        t["mask"].use(1)
        ps = pg["sun"]
        put(ps, scene=0, mask=1, cam=cam, size=sz, tex=(1.0 / W, 1.0 / H), bump=p["bump"], sh=p["shadow"], blur=p["shadow_soft"])
        for b in bodies:
            if b["i"] <= 0.003:
                continue
            lx, ly, lz = b["lv"]
            v = (crot * lx + srot * ly, -srot * lx + crot * ly, lz)
            nn = math.sqrt(v[0] ** 2 + v[1] ** 2 + v[2] ** 2)
            put(ps, col=tuple(float(c) for c in b["c"]), ldir=(v[0] / nn, v[1] / nn, v[2] / nn), usem=1.0 if (b is key and use_mask) else 0.0)
            va["sun"].render(moderngl.TRIANGLE_STRIP, vertices=4)

        R = math.hypot(W, H) / (2.0 * cam[2])
        pool = []
        for l in self.lights:
            if l.enabled and math.hypot(l.rx - cam[0], l.ry - cam[1]) < l.radius + R:
                pool.append((l.rx, l.ry, l.color, l.intensity * l.k, l.radius, l.ra, l.cone, l.soft, l.height, l.shadow, l.spec))
        for a in sorted(self.glows, key=lambda a: -a[3])[:int(p["fx_light_max"])]:
            if math.hypot(a[0] - cam[0], a[1] - cam[1]) < a[4] + R:
                pool.append((a[0], a[1], a[2], a[3], a[4], 0.0, 360.0, 6.0, 0.35, False, 0.3))
        pool.sort(key=lambda q: -(q[3] * q[4]) / (1.0 + math.hypot(q[0] - cam[0], q[1] - cam[1])))
        pr = pg["light"]
        put(pr, scene=0, ot=2, cam=cam, size=sz, tex=(1.0 / W, 1.0 / H), bump=p["bump"])
        ns0 = int(min(24, max(4, 4 + 10 * p["quality"])))
        cap = int(p["occ_per_light"])
        jobs = []
        chunks = []
        used = 0
        for x, y, c, i, r, a, cone, soft, hh, shd, spec in pool[:int(p["max_lights"])]:
            z = cam[2]
            dx, dy = x - cam[0], y - cam[1]
            ux = (crot * dx + srot * dy) * z / W + 0.5
            uy = (-srot * dx + crot * dy) * z / H + 0.5
            rx, ry = r * z / W, r * z / H
            x0, y0, x1, y1 = max(0.0, ux - rx), max(0.0, uy - ry), min(1.0, ux + rx), min(1.0, uy + ry)
            if x1 <= x0 or y1 <= y0:
                continue
            k = 0
            off = used
            if shd and p["shadow"] > 0.0 and len(occ):
                m = (occ[:, 0] < x + r) & (occ[:, 2] > x - r) & (occ[:, 1] < y + r) & (occ[:, 3] > y - r)
                m &= ~((occ[:, 0] < x) & (x < occ[:, 2]) & (occ[:, 1] < y) & (y < occ[:, 3]))
                sel = occ[m]
                if len(sel) > cap:
                    cx = (sel[:, 0] + sel[:, 2]) * 0.5 - x
                    cy = (sel[:, 1] + sel[:, 3]) * 0.5 - y
                    sel = sel[np.argsort(cx * cx + cy * cy)[:cap]]
                k = len(sel)
                if k:
                    chunks.append(sel[:, :4])
                    used += k
            rad = math.radians(a)
            if cone >= 360.0:
                s4 = (1.0, 0.0, -1.5, -1.2)
            else:
                hc = math.radians(cone * 0.5)
                s4 = (math.cos(rad), math.sin(rad), math.cos(hc), math.cos(hc * 0.65))
            ns = int(min(ns0, max(4, p["shadow_budget"] // max(k, 1))))
            jobs.append(dict(r=(x0, y0, x1, y1), l=(x, y, r, hh * r), c=(c[0] * i, c[1] * i, c[2] * i, spec), s=s4, p=(soft, float(ns), 0.0, 0.0), n=k, o=off))
        if used:
            self._upload(np.concatenate(chunks))
        if self.ot is not None:
            self.ot.use(2)
        for j in jobs:
            put(pr, **j)
            va["light"].render(moderngl.TRIANGLE_STRIP, vertices=4)

        hd = f["hdr"]
        hd.use()
        ctx.disable(moderngl.BLEND)
        t["scene"].use(0)
        t["lmap"].use(1)
        t["emis"].use(2)
        pc = pg["comp"]
        wr = np.zeros((MAX_WATERS, 4), "f4")
        wp = np.zeros((MAX_WATERS, 4), "f4")
        wc = (0.6, 0.8, 0.9)
        ws = self.waters[:MAX_WATERS]
        for i, w in enumerate(ws):
            wr[i] = w[:4]
            wp[i] = w[4:8]
            wc = w[8]
        put(pc, scene=0, lmap=1, emis=2, sl=(p["self_lit"], p["self_lit_threshold"]), cam=cam, size=sz, time=float(time), eg=p["emissive_gain"], fogc=col(p["fog_color"]), wc=wc,
            fog=(p["fog"], p["fog_scale"], p["fog_height"], p["fog_base"]), wind=tuple(p["wind"]), nw=len(ws))
        if ws:
            pc["u_wr"].write(wr.tobytes())
            pc["u_wp"].write(wp.tobytes())
        va["comp"].render(moderngl.TRIANGLE_STRIP, vertices=4)
        t["hdr"].build_mipmaps()

        pb = pg["blur"]
        src = t["hdr"]
        for i in range(5):
            f[f"b{i}"].use()
            src.use(0)
            put(pb, src=0, px=(1.0 / src.size[0], 1.0 / src.size[1]), thr=p["threshold"] if i == 0 else 0.0, w=1.0)
            va["blur"].render(moderngl.TRIANGLE_STRIP, vertices=4)
            src = t[f"b{i}"]
        ctx.enable(moderngl.BLEND)
        ctx.blend_func = (moderngl.ONE, moderngl.ONE)
        for i in range(3, -1, -1):
            f[f"b{i}"].use()
            src = t[f"b{i + 1}"]
            src.use(0)
            put(pb, px=(1.0 / src.size[0], 1.0 / src.size[1]), thr=0.0, w=0.6)
            va["blur"].render(moderngl.TRIANGLE_STRIP, vertices=4)
        ctx.disable(moderngl.BLEND)

        a = self.ad
        f[f"a{1 - a}"].use()
        t["hdr"].use(0)
        t[f"a{a}"].use(1)
        put(pg["adapt"], hdr=0, prev=1, a=1.0 - math.exp(-st["dt"] * p["adapt_speed"]), key=0.45, lo=0.7, hi=2.0)
        va["adapt"].render(moderngl.TRIANGLE_STRIP, vertices=4)
        self.ad = 1 - a

        ctx.screen.use()
        ctx.screen.viewport = (0, 0, W, H)
        t["hdr"].use(0)
        t["b0"].use(1)
        t["b1"].use(2)
        t["b2"].use(3)
        t[f"a{self.ad}"].use(4)
        sun_k = max((b for b in bodies if b["sun"]), key=lambda b: b["i"])
        moon_k = max((b for b in bodies if not b["sun"]), key=lambda b: b["i"])
        rays = p["rays"] * (sun_k["i"] * (1.0 - max(sun_k["e"], 0.0)) ** 2 + 0.3 * moon_k["i"]) * (0.5 + p["fog"])
        sb = sun_k if sun_k["i"] >= moon_k["i"] else moon_k
        put(pg["final"], hdr=0, b0=1, b1=2, b2=3, ad=4, size=sz, time=float(time), bloom=p["bloom"], flare=p["flare"], streak=p["streak"],
            rays=rays, ca=p["aberration"], vig=p["vignette"], grain=p["grain"], gs=p["grain_size"], gt=float(math.floor(time * p["grain_fps"])), sat=p["saturation"], con=p["contrast"], exp=p["exposure"],
            adapt=p["adapt"], tint=tuple(float(x) for x in tint), sun=(0.5 + sb["ax"] * 0.6, 0.55 + 0.4 * max(sb["e"], 0.0)))
        va["final"].render(moderngl.TRIANGLE_STRIP, vertices=4)

    def shutdown(self):
        self.active = False
        for n, fn, _ in self.hs:
            self.engine.off(n, fn)
        self.unhook()
        self._free()
        for d in (self.va, self.pg):
            for o in d.values():
                try:
                    o.release()
                except Exception:
                    pass
        for o in (self.sbuf, self.ot):
            try:
                o.release()
            except Exception:
                pass
