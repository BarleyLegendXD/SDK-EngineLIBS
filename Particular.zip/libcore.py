NAME = "Particular"
VERSION = "1.0.0"
ENGINE = ">=2.1.0"
PRIORITY = 50

SYSTEM = None

from . import system as _system


def _fx(engine, spec, x=0.0, y=0.0, **kw):
    return SYSTEM.fx(spec, x, y, **kw)


def _particles(engine):
    return SYSTEM


def _sprite_fx(sprite, spec, offset=None, **kw):
    return SYSTEM.attach(sprite, spec, offset, **kw)


def init(engine):
    global SYSTEM
    SYSTEM = _system.ParticleSystem(engine)
    SYSTEM.sprite_fx = _sprite_fx
    engine.state["particles"] = SYSTEM
    engine.add_method("engine", "fx", _fx)
    engine.add_method("engine", "particles", _particles)
    SYSTEM.hints.banner(VERSION)
    SYSTEM.bind_sprite_manager()


def shutdown(engine):
    global SYSTEM
    if SYSTEM is not None:
        SYSTEM.shutdown()
    engine.state.pop("particles", None)
    SYSTEM = None
