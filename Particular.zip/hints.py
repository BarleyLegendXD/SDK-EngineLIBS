import colorsys
import textwrap

from . import config as C

TAG = "Particular"
CYAN = (120, 230, 255)
AMBER = (255, 205, 70)
RED = (255, 95, 95)
GREEN = (120, 255, 160)
DIM = (185, 185, 165)


class Hints:
    def __init__(self, engine):
        self.engine = engine
        self.seen = set()

    @property
    def on(self):
        return bool(self.engine.cfg.get("debug", True))

    def say(self, key, color, head, lines=()):
        if not self.on or key in self.seen:
            return False
        self.seen.add(key)
        log = self.engine.log
        log(f"[{TAG}] {head}", color)
        for line in lines:
            wrapped = textwrap.wrap(str(line), 66) or [""]
            log("   > " + wrapped[0], DIM)
            for extra in wrapped[1:]:
                log("     " + extra, DIM)
        return True

    def warn(self, key, head, *lines):
        return self.say(key, AMBER, "WARN: " + head, lines)

    def error(self, key, head, *lines):
        return self.say(key, RED, "ERROR: " + head, lines)

    def tip(self, key, head, *lines):
        return self.say(key, CYAN, "TIP: " + head, lines)

    def banner(self, version):
        if not self.on:
            return
        e = self.engine
        name = "Particular"
        text = name + " v" + version
        if getattr(e, "LOG_CHAR_COLORS", False):
            n = len(name)
            colors = [tuple(int(c * 255) for c in colorsys.hsv_to_rgb(0.02 + 0.9 * i / n, 0.6, 1.0)) for i in range(n)]
            colors += [(150, 150, 150)] * (len(text) - n)
            e.log(text, colors)
        else:
            e.log(text, (255, 190, 120))
        e.log("hints ON | engine.particles().help() lists every option", (150, 150, 150))

    def unknown_option(self, who, name):
        near = C.close(name, C.DEFAULTS)
        lines = []
        if near:
            lines.append("did you mean: " + ", ".join(f"'{n}'" for n in near) + " ?")
        lines.append("the option was ignored")
        lines.append("engine.particles().help() prints every option with a short description")
        self.warn(("opt", name), f"unknown option '{name}' for {who}", *lines)

    def bad_value(self, who, key, value, expected, example):
        self.warn(("val", who, key), f"bad value for '{key}' of {who}: {value!r}",
                  f"expected {expected}, for example {example}", "the default value is used instead")

    def bad_choice(self, who, key, value, options):
        near = C.close(value, options)
        self.warn(("choice", who, key), f"'{key}' of {who} cannot be {value!r}",
                  ("did you mean: " + ", ".join(near)) if near else "valid: " + ", ".join(str(o) for o in options),
                  f"'{options[0]}' is used instead")

    def preset_missing(self, name, names):
        near = C.close(name, names, n=4)
        self.error(("preset", name), f"no preset named '{name}'",
                   ("did you mean: " + ", ".join(near)) if near else "engine.particles().list() shows all presets",
                   "or pass your own dict: engine.fx({'rate': 40, 'color': 'cyan', 'blend': 'add'}, x, y)")

    def help_options(self):
        if not self.on:
            return
        groups = {}
        for name, (group, desc) in C.DOCS.items():
            groups.setdefault(group, []).append((name, desc))
        log = self.engine.log
        log(f"[{TAG}] options of an emitter (preset dict keys or keyword arguments)", CYAN)
        for group, items in groups.items():
            log(f"  -- {group} --", AMBER)
            for name, desc in items:
                log(f"   {name:<17}{desc}", DIM)
        log("  -- modifiers (work on any preset) --", AMBER)
        for name, desc in C.MODIFIERS.items():
            log(f"   {name:<17}{desc}", DIM)
        log("  -- angles: 0 = right, 90 = up, -90 = down; y points up --", DIM)
