import math

import moderngl
import numpy as np

from . import atlas as A

VERT = """#version 330
uniform vec2 u_screen;
uniform vec2 u_cam;
uniform vec2 u_rot;
uniform float u_zoom;
in vec2 i_pos;
in vec2 i_size;
in float i_rot;
in vec4 i_uv;
in vec4 i_color;
out vec2 v_uv;
out vec4 v_color;
void main() {
    vec2 k = vec2(float(gl_VertexID & 1), float(gl_VertexID >> 1));
    vec2 local = (k - 0.5) * i_size;
    float c = cos(i_rot);
    float s = sin(i_rot);
    vec2 w = i_pos + vec2(c * local.x - s * local.y, s * local.x + c * local.y);
    vec2 d = w - u_cam;
    vec2 v = vec2(u_rot.x * d.x + u_rot.y * d.y, -u_rot.y * d.x + u_rot.x * d.y) * u_zoom;
    gl_Position = vec4(v / (u_screen * 0.5), 0.0, 1.0);
    v_uv = mix(i_uv.xy, i_uv.zw, k);
    v_color = i_color;
}"""

FRAG = """#version 330
uniform sampler2D u_tex;
uniform int u_mode;
in vec2 v_uv;
in vec4 v_color;
out vec4 f_color;
void main() {
    vec4 t = texture(u_tex, v_uv) * v_color;
    if (t.a <= 0.002) discard;
    if (u_mode == 1) f_color = vec4(t.rgb * t.a, t.a);
    else if (u_mode == 2) f_color = vec4(mix(vec3(1.0), t.rgb, t.a), 1.0);
    else f_color = t;
}"""

BLEND = {
    "alpha": ((moderngl.SRC_ALPHA, moderngl.ONE_MINUS_SRC_ALPHA), 0),
    "add": ((moderngl.SRC_ALPHA, moderngl.ONE), 0),
    "screen": ((moderngl.ONE, moderngl.ONE_MINUS_SRC_COLOR), 1),
    "multiply": ((moderngl.DST_COLOR, moderngl.ZERO), 2),
}

STRIDE = 13 * 4


class Renderer:
    def __init__(self, ctx):
        self.ctx = ctx
        self.prog = ctx.program(vertex_shader=VERT, fragment_shader=FRAG)
        self.cap = 4096 * STRIDE
        self.buf = ctx.buffer(reserve=self.cap)
        self.vao = ctx.vertex_array(self.prog, [(self.buf, "2f 2f 1f 4f 4f/i", "i_pos", "i_size", "i_rot", "i_uv", "i_color")])
        img, self.uv = A.build()
        self.atlas = ctx.texture((img.shape[1], img.shape[0]), 4, img.tobytes())
        self.atlas.filter = (moderngl.LINEAR, moderngl.LINEAR)
        self.prog["u_tex"].value = 0
        self.calls = 0
        self.drawn = 0

    def draw(self, batches, view, size):
        self.calls = 0
        self.drawn = 0
        if not batches:
            return
        ctx, prog = self.ctx, self.prog
        ctx.disable(moderngl.DEPTH_TEST | moderngl.CULL_FACE)
        ctx.enable(moderngl.BLEND)
        prog["u_screen"].value = (float(size[0]), float(size[1]))
        prog["u_cam"].value = (float(view[0]), float(view[1]))
        prog["u_zoom"].value = float(view[2])
        prog["u_rot"].value = (math.cos(view[3]), math.sin(view[3]))
        i = 0
        total = len(batches)
        while i < total:
            blend, tex, arr = batches[i]
            j = i + 1
            parts = [arr]
            while j < total and batches[j][0] == blend and batches[j][1] is tex:
                parts.append(batches[j][2])
                j += 1
            data = parts[0] if len(parts) == 1 else np.concatenate(parts)
            self._flush(blend, tex, data)
            i = j
        ctx.disable(moderngl.BLEND)

    def _flush(self, blend, tex, data):
        n = len(data)
        need = n * STRIDE
        if need > self.cap:
            self.cap = max(need, self.cap * 2)
            self.buf.orphan(self.cap)
        else:
            self.buf.orphan()
        self.buf.write(np.ascontiguousarray(data, np.float32))
        func, mode = BLEND[blend]
        self.ctx.blend_func = func
        self.prog["u_mode"].value = mode
        tex.use(0)
        self.vao.render(moderngl.TRIANGLE_STRIP, vertices=4, instances=n)
        self.calls += 1
        self.drawn += n

    def release(self):
        for obj in (self.vao, self.buf, self.prog, self.atlas):
            try:
                obj.release()
            except Exception:
                pass
