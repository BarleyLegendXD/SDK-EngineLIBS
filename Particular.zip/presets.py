REGISTRY = {}


def add(name, cat, doc, spec, oneshot=False):
    REGISTRY[name] = {"cat": cat, "doc": doc, "oneshot": oneshot, "spec": spec}


FIRE = ((255, 250, 190), (255, 170, 40), (190, 50, 10), (50, 10, 0))
BLUE_FIRE = ((225, 248, 255), (90, 170, 255), (30, 60, 210), (6, 10, 70))
GREEN_FIRE = ((235, 255, 200), (110, 255, 90), (20, 160, 60), (4, 50, 20))
PURPLE_FIRE = ((255, 225, 255), (200, 100, 255), (110, 30, 190), (30, 8, 70))
SPARK_COL = ((255, 255, 215), (255, 175, 50), (210, 70, 10))
BOOM = ((255, 250, 215), (255, 155, 45), (115, 28, 4), (28, 10, 6))
RAINBOW = ((255, 90, 90), (255, 200, 60), (120, 235, 120), (90, 210, 255), (200, 120, 255), (255, 130, 200))
GOLD = ((255, 235, 120), (255, 190, 40), (255, 140, 20))

add("fire", "fire", "a campfire flame", {
    "rate": 90, "life": (0.5, 1.0), "shape": "circle", "radius": (11, 3), "angle": 90, "spread": 24,
    "speed": (55, 120), "accel": (0, 70), "drag": 0.7, "turbulence": 150, "turb_scale": 0.045,
    "size": (22, 40), "size_curve": (0.5, 1.0, 0.0), "color": FIRE, "alpha_curve": (0, 0.8, 0.65, 0),
    "sprite": "soft", "blend": "add", "intensity": 1.1,
})
add("torch", "fire", "a small wall torch flame", {"base": "fire", "rate": 55, "radius": (4, 2), "size": (13, 24), "speed": (25, 65), "turbulence": 90, "accel": (0, 45)})
add("candle", "fire", "a tiny candle flame", {"base": "fire", "rate": 22, "radius": (1.5, 1), "size": (8, 13), "speed": (8, 28), "spread": 10, "life": (0.3, 0.6), "turbulence": 40, "accel": (0, 30)})
add("blue_fire", "fire", "cold blue flame", {"base": "fire", "color": BLUE_FIRE})
add("green_fire", "fire", "toxic green flame", {"base": "fire", "color": GREEN_FIRE})
add("purple_fire", "fire", "witch purple flame", {"base": "fire", "color": PURPLE_FIRE})
add("embers", "fire", "glowing sparks drifting upward", {
    "rate": 16, "life": (1.6, 3.2), "shape": "rect", "width": 140, "height": 8, "angle": 90, "spread": 50,
    "speed": (15, 50), "accel": (6, 32), "turbulence": 80, "turb_scale": 0.03, "size": (2, 4.5),
    "color": ((255, 240, 170), (255, 150, 40), (190, 50, 10)), "alpha_curve": (0, 1, 0.8, 0),
    "sprite": "soft", "blend": "add", "intensity": 1.3,
})
add("campfire", "fire", "flames + embers + smoke", [
    {"base": "fire", "rate": 110, "radius": (22, 5), "size": (18, 34)},
    {"base": "embers", "rate": 10, "width": 60},
    {"base": "smoke", "rate": 6, "offset": (0, 60), "color": ((90, 90, 90), (40, 40, 40)), "alpha_curve": (0, 0.35, 0)},
])
add("bonfire", "fire", "a big roaring fire", [
    {"base": "fire", "rate": 220, "radius": (38, 8), "size": (30, 56), "speed": (60, 150), "accel": (0, 90)},
    {"base": "embers", "rate": 36, "width": 120, "speed": (30, 90)},
    {"base": "smoke", "rate": 12, "offset": (0, 120), "size": (50, 90)},
])
add("flamethrower", "fire", "a jet of fire, aim it with angle=", {
    "rate": 230, "life": (0.35, 0.7), "angle": 0, "spread": 7, "speed": (320, 460), "drag": 1.4,
    "turbulence": 120, "turb_scale": 0.03, "size": (12, 28), "size_curve": (0.3, 1.0, 1.6), "color": FIRE,
    "alpha_curve": (0, 1, 0.8, 0), "sprite": "soft", "blend": "add",
})
add("fireball", "fire", "a moving fireball, attach it to a sprite", [
    {"rate": 70, "life": (0.18, 0.3), "size": (46, 58), "speed": 0, "sprite": "glow", "blend": "add",
     "color": ((255, 255, 225), (255, 175, 60), (160, 40, 0)), "alpha_curve": (0.9, 0.6, 0), "intensity": 1.2},
    {"base": "fire", "rate": 40, "rate_distance": 0.9, "life": (0.3, 0.6), "size": (22, 36), "speed": (10, 50), "spread": 360, "radius": 6, "accel": (0, 25)},
])
add("lava_sparks", "fire", "hot sparks popping out of lava", {
    "rate": 14, "life": (0.8, 1.6), "shape": "rect", "width": 200, "height": 4, "angle": 90, "spread": 40,
    "speed": (80, 190), "gravity": 260, "size": (3, 5), "color": ((255, 235, 150), (255, 110, 20)),
    "alpha_curve": (1, 1, 0), "blend": "add", "intensity": 1.3,
})

add("smoke", "smoke", "rising grey smoke", {
    "rate": 14, "life": (1.6, 3.0), "shape": "circle", "radius": 7, "angle": 90, "spread": 35, "speed": (18, 40),
    "accel": (0, 16), "drag": 0.35, "turbulence": 40, "turb_scale": 0.02, "size": (26, 44), "size_curve": (0.5, 1.5),
    "color": ((125, 125, 125), (50, 50, 50)), "alpha_curve": (0, 0.5, 0), "sprite": "smoke", "rotation": (0, 360), "spin": (-25, 25),
})
add("black_smoke", "smoke", "thick black smoke", {"base": "smoke", "rate": 22, "size": (34, 62), "color": ((45, 45, 45), (12, 12, 12)), "alpha_curve": (0, 0.75, 0)})
add("steam", "smoke", "white steam", {
    "base": "smoke", "rate": 30, "life": (0.8, 1.5), "speed": (35, 80), "accel": (0, 40), "spread": 20,
    "size": (16, 30), "size_curve": (0.4, 1.6), "color": (240, 240, 245), "alpha_curve": (0, 0.35, 0),
})
add("chimney", "smoke", "smoke drifting sideways in the wind", {"base": "smoke", "wind": (45, 0), "wind_drag": 0.4, "rate": 10})
add("fog", "smoke", "slow wide ground fog", {
    "rate": 4, "life": (6, 10), "shape": "rect", "width": 700, "height": 120, "angle": 0, "spread": 40,
    "speed": (6, 16), "size": (180, 300), "color": (190, 200, 215), "alpha_curve": (0, 0.06, 0.06, 0),
    "sprite": "smoke", "rotation": (0, 360), "spin": (-4, 4), "prewarm": 6,
})
add("mist", "smoke", "light mist covering the whole screen", {
    "base": "fog", "fit_camera": True, "follow_camera": True, "height": 0, "rate": 3, "layer": 40,
    "shape": "rect", "color": (210, 225, 240), "alpha_curve": (0, 0.035, 0.035, 0),
})
add("dust_puff", "smoke", "a puff of dust, jump landing", {
    "burst": 16, "life": (0.35, 0.8), "shape": "circle", "radius": 4, "angle": 90, "spread": 170, "speed": (30, 130),
    "drag": 3.2, "accel": (0, 10), "size": (14, 26), "size_curve": (0.5, 1.4), "color": ((185, 165, 135), (150, 135, 110)),
    "alpha_curve": (0, 0.55, 0), "sprite": "smoke", "rotation": (0, 360), "spin": (-80, 80),
}, True)
add("smoke_puff", "smoke", "a grey smoke puff", {"base": "dust_puff", "color": ((140, 140, 140), (80, 80, 80)), "speed": (20, 90), "burst": 12}, True)
add("poof", "smoke", "a cartoon poof of white smoke and stars", [
    {"base": "dust_puff", "color": ((255, 255, 255), (220, 225, 235)), "burst": 14, "alpha_curve": (0, 0.9, 0), "spread": 360, "size": (22, 38)},
    {"burst": 8, "life": (0.4, 0.7), "speed": (80, 190), "drag": 2.5, "size": (8, 14), "sprite": "star", "color": ((255, 255, 200), (255, 230, 120)),
     "alpha_curve": (1, 1, 0), "blend": "add", "spin": (-300, 300)},
], True)
add("sandstorm", "smoke", "blowing sand across the screen", {
    "rate": 260, "life": (1.2, 2.0), "follow_camera": True, "fit_camera": True, "shape": "rect", "height": 0,
    "angle": 180, "spread": 14, "speed": (420, 760), "size": (4, 9), "aspect": 3, "align": True, "sprite": "square",
    "color": (225, 190, 130), "opacity": 0.55, "alpha_curve": (0, 1, 1, 0), "prewarm": 2, "layer": 50,
})

add("flash", "explosion", "a quick white flash", {
    "burst": 1, "life": (0.12, 0.2), "size": (210, 210), "size_curve": (0.4, 1.0), "speed": 0, "sprite": "glow",
    "color": ((255, 255, 240), (255, 200, 120)), "alpha_curve": (1, 0), "blend": "add", "intensity": 1.3,
}, True)
add("shockwave", "explosion", "an expanding ring", {
    "burst": 1, "life": 0.5, "size": 30, "size_curve": (0.2, 7.0), "speed": 0, "sprite": "ring",
    "color": (255, 230, 180), "alpha_curve": (0.9, 0), "blend": "add",
}, True)
add("sparks", "explosion", "flying sparks with gravity", {
    "burst": 28, "life": (0.3, 0.9), "speed": (140, 420), "spread": 360, "gravity": 500, "drag": 1.2,
    "size": (9, 16), "size_curve": (1, 0.5), "aspect": 3.5, "align": True, "sprite": "spark", "color": SPARK_COL,
    "alpha_curve": (1, 1, 0), "blend": "add", "intensity": 1.2,
}, True)
add("debris", "explosion", "chunks of rock flying around", {
    "burst": 18, "life": (0.8, 1.6), "angle": 90, "spread": 180, "speed": (120, 420), "gravity": 700,
    "spin": (-500, 500), "rotation": (0, 360), "size": (4, 9), "sprite": "square", "palette": ((150, 125, 95), (110, 95, 80), (80, 70, 60)),
    "alpha_curve": (1, 1, 0.9, 0),
}, True)
add("explosion", "explosion", "fireball + smoke + sparks + shockwave", [
    {"base": "smoke", "rate": 0, "burst": 14, "life": (0.9, 1.9), "speed": (20, 140), "drag": 2.0, "size": (30, 56),
     "shape": "point", "spread": 360, "color": ((90, 85, 80), (35, 35, 35)), "alpha_curve": (0, 0.6, 0)},
    {"base": "flash", "size": (150, 150)},
    {"burst": 36, "life": (0.3, 0.7), "speed": (30, 270), "drag": 3.2, "size": (28, 54), "size_curve": (0.4, 1.0, 0.3),
     "color": BOOM, "alpha_curve": (1, 0.85, 0), "sprite": "soft", "blend": "add"},
    {"base": "sparks", "burst": 34},
    {"base": "shockwave", "size": 26},
], True)
add("small_explosion", "explosion", "a little pop", {"base": "explosion", "_mods": {"scale": 0.5, "amount": 0.55}}, True)
add("big_explosion", "explosion", "a huge blast", [
    {"base": "explosion", "_mods": {"scale": 2.0, "amount": 1.8}},
    {"base": "debris", "burst": 30, "speed": (200, 600)},
], True)
add("firecracker", "explosion", "a crackling pop with sparks", [
    {"base": "flash", "size": (70, 70)},
    {"base": "sparks", "burst": 40, "speed": (100, 330), "life": (0.2, 0.6)},
    {"base": "smoke_puff", "burst": 5},
], True)
add("blast", "explosion", "a bright energy blast", [
    {"base": "flash", "size": (260, 260), "color": ((255, 255, 255), (190, 230, 255))},
    {"base": "shockwave", "size": 40, "color": (190, 230, 255)},
    {"burst": 40, "life": (0.3, 0.6), "speed": (160, 460), "drag": 3.5, "size": (7, 13), "aspect": 3, "align": True, "sprite": "spark",
     "color": ((255, 255, 255), (130, 200, 255)), "alpha_curve": (1, 1, 0), "blend": "add"},
], True)

add("hit", "impact", "a hit flash with sparks", [
    {"burst": 1, "life": 0.22, "size": 90, "size_curve": (0.4, 1.2), "speed": 0, "sprite": "star",
     "color": (255, 245, 210), "alpha_curve": (1, 0), "blend": "add", "intensity": 1.3},
    {"base": "sparks", "burst": 14, "speed": (110, 340), "life": (0.25, 0.55), "gravity": 200, "size": (12, 20)},
], True)
add("slash", "impact", "an arc of streaks, set angle= to aim it", {
    "burst": 16, "life": (0.18, 0.34), "shape": "circle", "radius": 38, "edge": True, "arc": (-65, 65), "outward": 1,
    "speed": (260, 420), "drag": 4.0, "size": (28, 46), "aspect": 6, "align": True, "sprite": "spark",
    "color": ((255, 255, 255), (150, 220, 255)), "alpha_curve": (1, 1, 0), "blend": "add", "spread": 0, "intensity": 1.3,
}, True)
add("bullet_impact", "impact", "a spark and dust where a bullet hits", [
    {"base": "sparks", "burst": 8, "spread": 90, "angle": 90, "speed": (100, 300), "life": (0.15, 0.4)},
    {"base": "dust_puff", "burst": 5, "size": (8, 16), "speed": (10, 60)},
], True)
add("ricochet", "impact", "sparks bouncing off metal", {"base": "sparks", "burst": 12, "angle": 90, "spread": 70, "speed": (160, 420), "gravity": 800}, True)
add("ground_slam", "impact", "a shockwave of dust and rocks", [
    {"base": "dust_puff", "burst": 38, "spread": 178, "speed": (120, 360), "size": (22, 40), "life": (0.5, 1.0)},
    {"base": "debris", "burst": 12, "speed": (100, 320)},
    {"burst": 1, "life": 0.45, "size": 40, "aspect": 4, "size_curve": (0.2, 9.0), "speed": 0, "sprite": "ring",
     "color": (230, 215, 190), "alpha_curve": (0.7, 0), "blend": "add"},
], True)

add("magic", "magic", "sparkling arcane energy", {
    "rate": 45, "life": (0.6, 1.3), "shape": "circle", "radius": 14, "edge": True, "outward": 1, "spread": 0,
    "speed": (8, 30), "accel": (0, 26), "turbulence": 60, "turb_scale": 0.03, "size": (7, 14), "size_curve": (1, 0.3),
    "color": ((190, 130, 255), (60, 170, 255)), "alpha_curve": (0, 1, 0), "sprite": "soft", "blend": "add", "intensity": 1.4,
})
add("sparkle", "magic", "twinkling stars", {
    "rate": 14, "life": (0.6, 1.2), "shape": "rect", "width": 80, "height": 80, "speed": (0, 6), "size": (9, 17),
    "size_curve": (0, 1, 0), "color": ((255, 255, 225), (255, 230, 130)), "alpha_curve": (0, 1, 0), "sprite": "star",
    "blend": "add", "spin": (-90, 90), "intensity": 1.2,
})
add("magic_aura", "magic", "an aura rising around something", {
    "rate": 34, "life": (0.8, 1.5), "shape": "circle", "radius": 34, "edge": True, "angle": 90, "spread": 20, "speed": (22, 60),
    "size": (7, 13), "size_curve": (1, 0.2), "color": ((255, 150, 255), (130, 100, 255)), "alpha_curve": (0, 1, 0),
    "sprite": "soft", "blend": "add", "turbulence": 30, "intensity": 1.4,
})
add("heal", "magic", "green crosses floating up", {
    "rate": 14, "life": (0.9, 1.4), "shape": "rect", "width": 50, "height": 8, "angle": 90, "spread": 12, "speed": (45, 90),
    "size": (10, 17), "color": ((170, 255, 190), (60, 230, 110)), "alpha_curve": (0, 1, 0), "sprite": "cross", "blend": "add",
})
add("mana", "magic", "blue orbs spiralling up", {
    "rate": 22, "life": (0.9, 1.5), "shape": "circle", "radius": 24, "edge": True, "tangent": 140, "accel": (0, 45),
    "speed": (0, 10), "size": (8, 15), "size_curve": (1, 0.3), "color": ((110, 210, 255), (60, 110, 255)),
    "alpha_curve": (0, 1, 0), "sprite": "soft", "blend": "add", "intensity": 1.4,
})
add("arcane_circle", "magic", "particles orbiting in a ring", {
    "rate": 70, "life": (0.7, 1.0), "shape": "circle", "radius": 52, "edge": True, "speed": 0, "tangent": 300,
    "size": (7, 13), "size_curve": (1, 0.3), "color": ((255, 140, 255), (150, 90, 255)), "alpha_curve": (0, 1, 0),
    "sprite": "soft", "blend": "add", "intensity": 1.4,
})
add("portal", "magic", "a swirling portal", [
    {"rate": 80, "life": (0.8, 1.3), "shape": "circle", "radius": 62, "edge": True, "outward": -1, "speed": (30, 70),
     "tangent": 260, "drag": 1.2, "size": (7, 13), "size_curve": (1, 0.4), "color": ((255, 190, 255), (130, 90, 255), (70, 170, 255)),
     "alpha_curve": (0, 1, 0), "sprite": "soft", "blend": "add", "intensity": 1.3},
    {"rate": 2.5, "life": 1.2, "size": 150, "size_curve": (0.6, 1.0), "speed": 0, "sprite": "ring",
     "color": (150, 110, 255), "alpha_curve": (0, 0.3, 0), "blend": "add"},
])
add("teleport", "magic", "particles collapsing into a flash", [
    {"burst": 56, "life": (0.3, 0.45), "shape": "circle", "radius": 80, "edge": True, "outward": -1, "speed": (170, 260),
     "size": (8, 13), "color": ((255, 255, 255), (130, 190, 255)), "alpha_curve": (0, 1, 1, 0), "sprite": "soft", "blend": "add", "intensity": 1.6},
    {"bursts": ((0.3, 1),), "life": 0.2, "size": 120, "size_curve": (1.2, 0.2), "speed": 0, "sprite": "glow", "color": (200, 230, 255),
     "alpha_curve": (1, 0), "blend": "add"},
    {"bursts": ((0.3, 14),), "life": (0.4, 0.7), "angle": 90, "spread": 60, "speed": (60, 180), "gravity": -80, "size": (8, 14),
     "sprite": "star", "color": (255, 255, 255), "alpha_curve": (1, 1, 0), "blend": "add"},
], True)
add("charge", "magic", "energy converging on a point", {
    "rate": 60, "life": (0.5, 0.8), "shape": "circle", "radius": 80, "edge": True, "outward": -1, "speed": (90, 140),
    "size": (7, 13), "size_curve": (1, 0.2), "color": ((255, 200, 90), (255, 240, 190)), "alpha_curve": (0, 1, 1),
    "sprite": "soft", "blend": "add", "intensity": 1.4,
})
add("shield", "magic", "a shimmering energy shield", {
    "rate": 46, "life": (0.5, 0.9), "shape": "circle", "radius": 56, "edge": True, "speed": (0, 4), "tangent": 90,
    "size": (9, 16), "size_curve": (1, 0.3), "color": ((110, 240, 255), (50, 170, 255)), "alpha_curve": (0, 1, 0),
    "sprite": "soft", "blend": "add", "intensity": 1.4,
})
add("curse", "magic", "dark purple fumes", [
    {"base": "smoke", "rate": 20, "size": (24, 44), "color": ((130, 40, 170), (30, 8, 50)), "alpha_curve": (0, 0.65, 0)},
    {"rate": 10, "life": (0.8, 1.4), "shape": "circle", "radius": 18, "angle": 90, "spread": 40, "speed": (25, 70),
     "size": (4, 8), "color": ((255, 90, 200), (140, 20, 120)), "alpha_curve": (0, 1, 0), "sprite": "soft", "blend": "add"},
])
add("holy", "magic", "golden rays and sparkles", [
    {"rate": 5, "life": (1.4, 2.2), "size": (34, 60), "aspect": 0.16, "speed": 0, "rotation": (-18, 18), "sprite": "ray",
     "color": (255, 240, 170), "alpha_curve": (0, 0.4, 0), "blend": "add", "shape": "rect", "width": 70, "height": 4, "angle": 90},
    {"base": "sparkle", "rate": 18, "color": ((255, 250, 200), (255, 210, 90)), "angle": 90, "speed": (10, 40)},
])
add("frost", "magic", "icy shimmer", {
    "rate": 26, "life": (1.0, 1.8), "shape": "rect", "width": 90, "height": 50, "speed": (5, 25), "gravity": 12,
    "turbulence": 30, "size": (5, 11), "size_curve": (0, 1, 0), "color": ((235, 252, 255), (120, 200, 255)),
    "alpha_curve": (0, 1, 0), "sprite": "star", "blend": "add", "spin": (-60, 60),
})
add("ice_shards", "magic", "ice shattering", [
    {"burst": 14, "life": (0.7, 1.2), "angle": 90, "spread": 150, "speed": (120, 320), "gravity": 520, "size": (11, 19),
     "aspect": 0.45, "align": True, "sprite": "spark", "color": ((235, 252, 255), (140, 210, 255)), "alpha_curve": (1, 1, 0),
     "spin": (-200, 200), "blend": "add"},
    {"base": "frost", "rate": 0, "burst": 12, "life": (0.5, 0.9), "speed": (20, 90), "spread": 360},
], True)
add("poison", "magic", "green toxic bubbles", [
    {"rate": 14, "life": (1.0, 1.7), "shape": "rect", "width": 50, "height": 4, "angle": 90, "spread": 25, "speed": (25, 52),
     "size": (8, 18), "size_curve": (0.4, 1.0), "color": (140, 255, 110), "alpha_curve": (0, 0.8, 0), "sprite": "ring", "blend": "add"},
    {"base": "smoke", "rate": 8, "color": ((80, 160, 60), (30, 70, 25)), "alpha_curve": (0, 0.45, 0)},
])

add("electric", "electric", "crackling electricity", {
    "rate": 80, "life": (0.08, 0.22), "shape": "circle", "radius": 14, "speed": (30, 160), "turbulence": 800, "turb_scale": 0.1,
    "size": (16, 28), "aspect": 3, "align": True, "sprite": "spark", "color": ((255, 255, 255), (130, 200, 255)),
    "alpha_curve": (1, 1, 0), "blend": "add", "intensity": 1.5,
})
add("spark_shower", "electric", "welding sparks", {
    "rate": 70, "life": (0.4, 1.0), "angle": 90, "spread": 70, "speed": (120, 320), "gravity": 700, "drag": 0.3,
    "size": (7, 12), "aspect": 3, "align": True, "sprite": "spark", "color": ((255, 250, 205), (255, 170, 60)),
    "alpha_curve": (1, 1, 0), "blend": "add", "intensity": 1.3,
})
add("energy_ball", "electric", "a glowing energy orb", [
    {"rate": 40, "life": (0.25, 0.4), "size": (48, 60), "speed": 0, "sprite": "glow", "color": ((200, 235, 255), (90, 170, 255)),
     "alpha_curve": (0.8, 0.4, 0), "blend": "add", "intensity": 0.9},
    {"base": "electric", "rate": 50, "radius": 18},
])
add("plasma", "electric", "orbiting plasma", [
    {"rate": 36, "life": (0.5, 0.8), "shape": "circle", "radius": 26, "edge": True, "speed": 0, "tangent": 380, "size": (5, 9),
     "color": ((255, 190, 255), (110, 140, 255)), "alpha_curve": (0, 1, 0), "sprite": "soft", "blend": "add", "intensity": 1.4},
    {"rate": 20, "life": (0.3, 0.5), "size": (50, 60), "speed": 0, "sprite": "glow", "color": (170, 150, 255), "alpha_curve": (0.7, 0.3, 0), "blend": "add"},
])
add("laser_hit", "electric", "sparks where a laser burns", [
    {"base": "spark_shower", "rate": 40, "spread": 100, "gravity": 400, "color": ((255, 200, 200), (255, 70, 60))},
    {"rate": 25, "life": (0.1, 0.2), "size": (22, 30), "speed": 0, "sprite": "glow", "color": (255, 120, 100), "alpha_curve": (1, 0), "blend": "add"},
])

add("snow", "weather", "falling snow over the whole view", {
    "rate": 60, "life": (8, 13), "follow_camera": "top", "fit_camera": True, "shape": "line", "angle": -90, "spread": 20,
    "speed": (30, 80), "wind": (25, 0), "wind_drag": 0.5, "turbulence": 25, "turb_scale": 0.01, "turb_speed": 0.8,
    "size": (2.5, 6), "sprite": "circle", "color": (255, 255, 255), "alpha_curve": (0, 1, 1, 0), "prewarm": 9, "layer": 50,
})
add("blizzard", "weather", "a violent snow storm", {
    "base": "snow", "rate": 380, "life": (3, 5), "speed": (220, 360), "angle": -100, "wind": (-420, 0), "wind_drag": 1.2,
    "turbulence": 90, "size": (2, 5), "prewarm": 4, "opacity": 0.9,
})
add("rain", "weather", "rain streaks over the whole view", {
    "rate": 360, "life": (0.9, 1.2), "follow_camera": "top", "fit_camera": True, "shape": "line", "angle": -98, "spread": 3,
    "speed": (700, 900), "size": (16, 24), "aspect": 9, "align": True, "sprite": "square", "color": (175, 195, 255),
    "opacity": 0.5, "alpha_curve": (1, 1, 0), "prewarm": 1.2, "layer": 50,
})
add("drizzle", "weather", "light rain", {"base": "rain", "rate": 110, "speed": (500, 650), "size": (10, 16), "opacity": 0.35})
add("storm_rain", "weather", "heavy wind-driven rain", {"base": "rain", "rate": 760, "angle": -112, "speed": (800, 1100), "wind": (-300, 0), "opacity": 0.6})
add("leaves", "weather", "autumn leaves blowing by", {
    "rate": 6, "life": (9, 14), "follow_camera": "top", "fit_camera": True, "shape": "line", "angle": -90, "spread": 40,
    "speed": (30, 80), "wind": (60, 0), "wind_drag": 0.4, "turbulence": 90, "turb_scale": 0.01, "size": (9, 15), "aspect": 1.7,
    "sprite": "drop", "palette": ((200, 90, 30), (230, 160, 40), (150, 60, 20), (110, 140, 40)), "spin": (-180, 180),
    "rotation": (0, 360), "alpha_curve": (0, 1, 1, 0), "prewarm": 10, "layer": 50,
})
add("petals", "weather", "cherry blossom petals", {
    "base": "leaves", "palette": ((255, 190, 210), (255, 220, 230), (250, 160, 190)), "rate": 9, "size": (7, 12), "wind": (80, 0),
})
add("fireflies", "weather", "slow glowing fireflies", {
    "rate": 5, "life": (4, 8), "follow_camera": True, "fit_camera": True, "shape": "rect", "height": 0, "speed": (4, 14),
    "turbulence": 28, "turb_scale": 0.02, "size": (7, 12), "color": ((200, 255, 120), (255, 240, 120)),
    "alpha_curve": (0, 1, 0.3, 1, 0), "sprite": "glow", "blend": "add", "prewarm": 6, "layer": 20, "intensity": 1.3,
})
add("bubbles", "weather", "rising bubbles", {
    "rate": 10, "life": (3, 6), "follow_camera": "bottom", "fit_camera": True, "shape": "line", "angle": 90, "spread": 15,
    "speed": (25, 65), "turbulence": 20, "size": (6, 18), "sprite": "ring", "color": (190, 240, 255), "opacity": 0.7,
    "alpha_curve": (0, 1, 1, 0), "prewarm": 5, "layer": 20, "blend": "add",
})
add("stars_twinkle", "weather", "a twinkling star field behind everything", {
    "rate": 8, "life": (1.5, 3.0), "follow_camera": True, "fit_camera": True, "shape": "rect", "height": 0, "speed": 0,
    "size": (4, 11), "sprite": "star", "color": ((255, 255, 255), (190, 210, 255)), "alpha_curve": (0, 1, 0), "blend": "add",
    "prewarm": 3, "layer": -100,
})
add("water_splash", "weather", "a splash of water drops", [
    {"burst": 26, "life": (0.5, 1.0), "angle": 90, "spread": 80, "speed": (140, 380), "gravity": 900, "size": (4, 9),
     "aspect": 0.7, "align": True, "sprite": "drop", "color": ((215, 240, 255), (90, 160, 255)), "alpha_curve": (1, 1, 0), "blend": "add"},
    {"burst": 1, "life": 0.5, "size": 20, "aspect": 3, "size_curve": (0.3, 4), "speed": 0, "sprite": "ring", "color": (190, 225, 255),
     "alpha_curve": (0.8, 0), "blend": "add"},
], True)
add("ripple", "weather", "a ring spreading on water", {
    "burst": 1, "life": 0.9, "size": 16, "aspect": 3, "size_curve": (0.3, 6), "speed": 0, "sprite": "ring",
    "color": (200, 230, 255), "alpha_curve": (0.9, 0), "blend": "add",
}, True)
add("waterfall_mist", "weather", "mist at the bottom of a waterfall", {
    "base": "smoke", "rate": 24, "shape": "rect", "width": 90, "height": 8, "spread": 90, "speed": (15, 45),
    "size": (30, 55), "color": (235, 245, 255), "alpha_curve": (0, 0.28, 0), "life": (0.9, 1.6),
})

add("coin_burst", "pickup", "gold stars popping out", [
    {"burst": 14, "life": (0.5, 0.95), "angle": 90, "spread": 140, "speed": (90, 280), "gravity": 420, "drag": 0.6,
     "size": (9, 16), "sprite": "star", "palette": GOLD, "alpha_curve": (1, 1, 0), "spin": (-360, 360), "blend": "add", "intensity": 1.2},
    {"base": "sparkle", "rate": 0, "burst": 8, "life": (0.4, 0.8), "speed": (30, 110), "spread": 360, "color": ((255, 245, 180), (255, 200, 60))},
], True)
add("pickup", "pickup", "sparkles rising from a collected item", [
    {"burst": 12, "life": (0.6, 1.0), "angle": 90, "spread": 100, "speed": (50, 150), "accel": (0, 60), "drag": 1.4,
     "size": (7, 14), "size_curve": (1, 0.3), "sprite": "star", "color": ((255, 255, 255), (170, 230, 255)), "alpha_curve": (1, 1, 0),
     "blend": "add", "spin": (-200, 200)},
    {"burst": 1, "life": 0.3, "size": 80, "size_curve": (0.3, 1.2), "speed": 0, "sprite": "ring", "color": (190, 235, 255),
     "alpha_curve": (0.8, 0), "blend": "add"},
], True)
add("levelup", "pickup", "rings and stars rising", [
    {"bursts": ((0, 1), (0.2, 1)), "life": 0.7, "size": 40, "size_curve": (0.3, 4.5), "speed": 0, "sprite": "ring",
     "color": (255, 230, 120), "alpha_curve": (1, 0), "blend": "add"},
    {"bursts": ((0, 16), (0.15, 14)), "life": (0.8, 1.3), "shape": "circle", "radius": 30, "edge": True, "angle": 90, "spread": 30,
     "speed": (100, 220), "drag": 1.3, "size": (9, 17), "size_curve": (1, 0.4), "sprite": "star", "color": ((255, 255, 210), (255, 200, 60)),
     "alpha_curve": (1, 1, 0), "blend": "add", "intensity": 1.2},
], True)
add("confetti", "pickup", "a burst of colorful confetti", {
    "burst": 90, "life": (1.8, 2.8), "angle": 90, "spread": 120, "speed": (200, 520), "gravity": 420, "drag": 1.1,
    "turbulence": 60, "turb_scale": 0.02, "size": (6, 11), "aspect": 1.6, "sprite": "square", "palette": RAINBOW,
    "spin": (-540, 540), "rotation": (0, 360), "alpha_curve": (1, 1, 0.9, 0), "color_var": 0.15,
}, True)
add("glitter", "pickup", "fine sparkling dust", {
    "burst": 36, "life": (0.6, 1.4), "spread": 360, "speed": (20, 160), "drag": 1.6, "gravity": 60, "size": (3, 7),
    "sprite": "star", "palette": ((255, 255, 255), (255, 220, 150), (190, 230, 255), (255, 190, 240)),
    "alpha_curve": (1, 1, 0), "blend": "add", "spin": (-300, 300),
}, True)
add("hearts", "pickup", "pink hearts floating up", {
    "burst": 9, "life": (0.9, 1.5), "angle": 90, "spread": 70, "speed": (40, 110), "drag": 0.5, "turbulence": 40,
    "size": (12, 22), "size_curve": (0.3, 1, 0.9), "sprite": "heart", "palette": ((255, 100, 140), (255, 150, 180), (255, 70, 110)),
    "alpha_curve": (0, 1, 1, 0), "rotation": (-20, 20),
}, True)
add("stars_burst", "pickup", "a burst of stars", {
    "burst": 18, "life": (0.5, 1.0), "spread": 360, "speed": (80, 300), "drag": 2.2, "size": (10, 20), "size_curve": (1, 0.3),
    "sprite": "star", "color": ((255, 255, 220), (255, 210, 90)), "alpha_curve": (1, 1, 0), "blend": "add", "spin": (-300, 300),
}, True)
add("bubble_pop", "pickup", "a bubble bursting", [
    {"burst": 1, "life": 0.25, "size": 24, "size_curve": (1, 1.6), "speed": 0, "sprite": "ring", "color": (210, 240, 255),
     "alpha_curve": (0.9, 0), "blend": "add"},
    {"burst": 9, "life": (0.2, 0.4), "spread": 360, "speed": (40, 110), "drag": 3, "size": (3, 6), "color": (220, 245, 255),
     "alpha_curve": (1, 0), "blend": "add"},
], True)
add("firework_burst", "pickup", "one firework shell, pass color=", {
    "burst": 70, "life": (1.0, 1.8), "speed": (80, 240), "drag": 1.7, "gravity": 150, "size": (6, 10), "size_curve": (1, 0.5),
    "color": ((255, 245, 200), (255, 180, 60), (190, 60, 10)), "alpha_curve": (1, 1, 0), "sprite": "soft", "blend": "add", "intensity": 1.2,
}, True)
add("fireworks", "pickup", "rockets that explode in colorful bursts", {
    "rate": 1.2, "life": (0.9, 1.2), "shape": "line", "length": 420, "angle": 90, "spread": 14, "speed": (430, 560), "gravity": 220,
    "size": (6, 8), "color": (255, 245, 200), "alpha_curve": (1, 1, 1), "sprite": "soft", "blend": "add", "intensity": 1.4,
    "palette": ((255, 50, 60), (255, 190, 30), (50, 215, 255), (100, 255, 80), (210, 70, 255)),
    "trail": {"rate": 0, "life": (0.3, 0.6), "speed": (0, 25), "size": (3, 5), "size_curve": (1, 0), "color": (255, 220, 150),
              "alpha_curve": (1, 0), "sprite": "soft", "blend": "add", "gravity": 80, "spread": 360},
    "trail_rate": 150,
    "on_death": {"life": (1.1, 1.9), "speed": (70, 250), "drag": 1.6, "gravity": 140, "size": (6, 10), "size_curve": (1, 0.5),
                 "palette": ((255, 50, 60), (255, 190, 30), (50, 215, 255), (100, 255, 80), (210, 70, 255)), "inherit_color": True,
                 "alpha_curve": (1, 1, 0), "sprite": "soft", "blend": "add", "intensity": 1.15,
                 "trail": {"life": (0.3, 0.6), "speed": (0, 20), "size": (2, 3.5), "alpha_curve": (0.8, 0), "blend": "add", "sprite": "soft",
                           "palette": ((255, 50, 60), (255, 190, 30), (50, 215, 255), (100, 255, 80), (210, 70, 255)), "inherit_color": True},
                 "trail_rate": 5},
    "on_death_count": 70, "on_death_inherit": 0.2,
})

add("trail", "movement", "a glowing trail behind a moving thing", {
    "rate": 80, "life": (0.25, 0.45), "speed": (0, 8), "size": (8, 12), "size_curve": (1, 0), "color": ((255, 255, 255), (120, 180, 255)),
    "alpha_curve": (0.9, 0), "sprite": "soft", "blend": "add",
})
add("dash", "movement", "afterimage streak when dashing", {
    "rate": 140, "rate_distance": 0.6, "life": (0.2, 0.32), "speed": 0, "size": (26, 38), "size_curve": (1, 0.2),
    "color": ((200, 240, 255), (90, 170, 255)), "alpha_curve": (0.7, 0), "sprite": "soft", "blend": "add",
})
add("comet", "movement", "a bright head with a long tail", [
    {"rate": 60, "life": (0.12, 0.2), "size": (32, 40), "speed": 0, "sprite": "glow", "color": (255, 255, 255), "alpha_curve": (1, 0.6, 0), "blend": "add"},
    {"rate": 160, "rate_distance": 1.0, "life": (0.6, 1.1), "size": (10, 18), "size_curve": (1, 0), "speed": (0, 20), "spread": 360,
     "color": ((255, 255, 240), (150, 190, 255), (60, 80, 200)), "alpha_curve": (0.9, 0.5, 0), "sprite": "soft", "blend": "add"},
])
add("jet_exhaust", "movement", "blue thruster flame, points opposite to the sprite", {
    "rate": 150, "life": (0.15, 0.35), "angle": -90, "spread": 10, "speed": (220, 340), "size": (10, 18), "size_curve": (1, 0.2),
    "color": BLUE_FIRE, "alpha_curve": (0.9, 0.7, 0), "sprite": "soft", "blend": "add", "rotate_with": True, "inherit": 0.5,
})
add("rocket_exhaust", "movement", "orange flame and a smoke trail", [
    {"base": "jet_exhaust", "color": FIRE, "size": (12, 22), "life": (0.12, 0.3)},
    {"base": "smoke", "rate": 36, "angle": -90, "spread": 20, "speed": (30, 80), "size": (18, 34), "life": (0.8, 1.6),
     "color": ((150, 150, 150), (60, 60, 60)), "alpha_curve": (0, 0.45, 0), "rotate_with": True},
])
add("footsteps", "movement", "tiny dust at the feet", {"base": "dust_puff", "burst": 4, "size": (7, 12), "speed": (10, 45), "life": (0.25, 0.5), "spread": 140}, True)
add("wake", "movement", "water rings behind a swimmer", {
    "rate": 5, "rate_distance": 0.05, "life": 1.0, "size": 14, "aspect": 2.4, "size_curve": (0.3, 4.5), "speed": 0, "sprite": "ring",
    "color": (205, 232, 255), "alpha_curve": (0.7, 0), "blend": "add",
})
add("speed_lines", "movement", "anime speed lines on the screen edges", {
    "rate": 90, "life": (0.15, 0.3), "fixed": True, "shape": "rect", "edge": True, "fit_camera": True, "outward": -1, "speed": (700, 1100),
    "spread": 0, "size": (120, 260), "aspect": 24, "align": True, "sprite": "square", "color": (255, 255, 255), "opacity": 0.4,
    "alpha_curve": (0, 1, 0), "layer": 10,
})

add("dust", "ambient", "floating dust motes in the air", {
    "rate": 10, "life": (4, 8), "follow_camera": True, "fit_camera": True, "shape": "rect", "height": 0, "speed": (2, 12),
    "turbulence": 12, "turb_scale": 0.005, "size": (1.5, 3.5), "color": (230, 220, 200), "opacity": 0.6, "alpha_curve": (0, 1, 0),
    "prewarm": 5, "layer": 50,
})
add("embers_ambient", "ambient", "embers rising across the whole screen", {
    "rate": 24, "life": (3, 6), "follow_camera": "bottom", "fit_camera": True, "shape": "line", "angle": 90, "spread": 40,
    "speed": (25, 70), "accel": (10, 20), "turbulence": 70, "turb_scale": 0.012, "size": (2, 4.5),
    "color": ((255, 240, 170), (255, 140, 40), (160, 40, 10)), "alpha_curve": (0, 1, 0.8, 0), "sprite": "soft", "blend": "add",
    "prewarm": 6, "layer": 30, "intensity": 1.3,
})
add("god_rays", "ambient", "soft light shafts from above", {
    "rate": 0.9, "life": (6, 9), "follow_camera": "top", "fit_camera": True, "shape": "line", "speed": 0, "size": (90, 170),
    "aspect": 0.14, "rotation": (-24, -16), "sprite": "ray", "color": (255, 240, 190), "alpha_curve": (0, 0.09, 0.09, 0),
    "blend": "add", "prewarm": 8, "layer": -20,
})
add("nebula", "ambient", "slow colorful space clouds", {
    "rate": 1.2, "life": (10, 16), "follow_camera": True, "fit_camera": True, "shape": "rect", "height": 0, "speed": (2, 6),
    "size": (500, 800), "color": ((130, 70, 220), (50, 90, 220)), "alpha_curve": (0, 0.035, 0.035, 0), "sprite": "smoke",
    "rotation": (0, 360), "spin": (-3, 3), "blend": "add", "prewarm": 12, "layer": -90,
})
add("pollen", "ambient", "drifting golden pollen", {
    "base": "dust", "color": (255, 235, 150), "size": (2, 4.5), "opacity": 0.8, "blend": "add", "rate": 8, "wind": (14, 0), "wind_drag": 0.3,
})
