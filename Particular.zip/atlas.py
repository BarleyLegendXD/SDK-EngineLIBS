import numpy as np

CELL = 64
COLS = 4
ORDER = ("circle", "soft", "glow", "square", "ring", "star", "spark", "smoke", "flare", "drop", "cross", "hex", "heart", "ray")


def _smooth(v):
    return np.clip(v, 0.0, 1.0)


def _mask(kind):
    n = CELL
    yy, xx = np.mgrid[0:n, 0:n]
    nx = (xx + 0.5) / n * 2.0 - 1.0
    ny = (yy + 0.5) / n * 2.0 - 1.0
    d = np.sqrt(nx * nx + ny * ny)
    px = 2.0 / n
    if kind == "circle":
        return _smooth((1.0 - d) / (px * 1.5))
    if kind == "soft":
        m = _smooth(1.0 - d)
        return m ** 1.5
    if kind == "glow":
        return _smooth(np.exp(-(d * 2.4) ** 2) * _smooth((1.0 - d) * 4.0))
    if kind == "square":
        return _smooth((1.0 - np.maximum(abs(nx), abs(ny))) / (px * 1.5))
    if kind == "ring":
        return _smooth((0.075 - abs(d - 0.82)) / (px * 1.5))
    if kind == "star":
        s = np.sqrt(abs(nx)) + np.sqrt(abs(ny))
        return _smooth((1.0 - s) * 3.0)
    if kind == "spark":
        s = abs(nx) + abs(ny) * 3.2
        return _smooth((1.0 - s) * 2.5) * _smooth(1.0 - abs(nx) * 0.3)
    if kind == "smoke":
        n1 = np.sin(nx * 5.1 + 1.3) * np.sin(ny * 4.7 + 0.4)
        n2 = np.sin((nx + ny) * 7.9 + 2.1) * np.sin((nx - ny) * 6.3)
        cloud = 0.62 + 0.22 * n1 + 0.16 * n2
        return _smooth((cloud - d * 0.78) * 1.9) * _smooth((1.0 - d) * 2.5)
    if kind == "flare":
        core = np.exp(-(d * 5.0) ** 2)
        h = np.exp(-(abs(ny) * 14.0) ** 2) * _smooth(1.0 - abs(nx))
        v = np.exp(-(abs(nx) * 14.0) ** 2) * _smooth(1.0 - abs(ny)) * 0.7
        return _smooth(np.maximum(core, np.maximum(h, v)))
    if kind == "drop":
        t = (ny + 1.0) / 2.0
        hw = 0.62 * np.sin(np.pi * np.clip(t, 0, 1) ** 0.65) ** 0.85
        return _smooth((hw - abs(nx)) / (px * 1.5))
    if kind == "cross":
        arm = np.minimum(_smooth((0.2 - abs(nx)) / (px * 1.5)), _smooth((0.95 - abs(ny)) / (px * 1.5)))
        arm2 = np.minimum(_smooth((0.2 - abs(ny)) / (px * 1.5)), _smooth((0.95 - abs(nx)) / (px * 1.5)))
        return np.maximum(arm, arm2)
    if kind == "hex":
        h = np.maximum(abs(ny), abs(nx) * 0.866 + abs(ny) * 0.5)
        return _smooth((0.92 - h) / (px * 1.5))
    if kind == "heart":
        x = nx * 1.25
        y = ny * 1.25 + 0.1
        f = (x * x + y * y - 1.0) ** 3 - x * x * y ** 3
        return _smooth(0.5 - f * 6.0)
    if kind == "ray":
        return _smooth(np.exp(-(nx * 5.0) ** 2) * _smooth(1.0 - abs(ny)) ** 0.6)
    return np.ones((n, n))


def build():
    rows = (len(ORDER) + COLS - 1) // COLS
    w, h = COLS * CELL, rows * CELL
    img = np.zeros((h, w, 4), np.uint8)
    img[..., :3] = 255
    uv = {}
    inset = 0.75
    for i, name in enumerate(ORDER):
        c, r = i % COLS, i // COLS
        m = np.clip(_mask(name), 0.0, 1.0)
        img[r * CELL:(r + 1) * CELL, c * CELL:(c + 1) * CELL, 3] = (m * 255.0 + 0.5).astype(np.uint8)
        uv[name] = ((c * CELL + inset) / w, (r * CELL + inset) / h, ((c + 1) * CELL - inset) / w, ((r + 1) * CELL - inset) / h)
    return img, uv
