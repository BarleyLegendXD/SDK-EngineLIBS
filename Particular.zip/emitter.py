import math

import numpy as np

from . import config as C

X, Y, VX, VY, AGE, LIFE, ROT, SPIN, SEED, SZ, R0, R1, R2 = range(13)
NC = 13
STEP = 1.0 / 30.0
TAU = 2.0 * math.pi


def _num(v, key):
    if isinstance(v, bool) or not isinstance(v, (int, float)):
        raise ValueError(key)
    return float(v)


class Emitter:
    def __init__(self, system, cfg, x=0.0, y=0.0, name="fx", owner=None, depth=0):
        self.sys = system
        self.engine = system.engine
        self.name = name
        self.owner = owner
        self.depth = depth
        self.mods = {}
        self.x = float(x)
        self.y = float(y)
        self.target = None
        self.visible = True
        self.layer = 0
        self.fixed = False
        self.paused = False
        self.emitting = True
        self.child_death = None
        self.child_trail = None
        self.n = 0
        self.cap = 64
        self.d = np.zeros((NC, self.cap), np.float32)
        self.time = 0.0
        self.cfg = dict(C.DEFAULTS)
        self._alive = True
        self._rep = 0
        self._acc = 0.0
        self._dacc = 0.0
        self._tacc = 0.0
        self._bi = 0
        self._delay = 0.0
        self._clock = 0.0
        self._started = False
        self._o = (self.x, self.y)
        self._inst = None
        self.apply(cfg)
        self._delay = float(self.cfg["delay"])

    @property
    def alive(self):
        return self._alive

    @alive.setter
    def alive(self, value):
        if self._alive and not value:
            self._alive = False
            self.n = 0
            self._sync()

    @property
    def count(self):
        return self.n

    @property
    def pos(self):
        return (self.x, self.y)

    def _sync(self):
        self.sys.total += self.n - self._rep
        self._rep = self.n

    def apply(self, cfg):
        h = self.sys.hints
        for k, v in cfg.items():
            if k.startswith("_"):
                continue
            if k not in C.DEFAULTS:
                h.unknown_option(f"emitter '{self.name}'", k)
                continue
            self.cfg[k] = v
        self._build()

    def _conv(self, key, kind):
        v = self.cfg[key]
        try:
            if kind == "num":
                return _num(v, key)
            if kind == "range":
                return C.as_range(v, key)
            if kind == "vec":
                return C.as_vec(v, key)
        except (ValueError, TypeError):
            examples = {"num": f"{key}=10", "range": f"{key}=(10, 20)", "vec": f"{key}=(0, 30)"}
            expected = {"num": "a number", "range": "a number or (min, max)", "vec": "(x, y)"}
            self.sys.hints.bad_value(f"emitter '{self.name}'", key, v, expected[kind], examples[kind])
            self.cfg[key] = C.DEFAULTS[key]
            return self._conv(key, kind)

    def _build(self):
        c = self.cfg
        h = self.sys.hints
        who = f"emitter '{self.name}'"
        for key, allowed in (("shape", C.SHAPES), ("sprite", C.SPRITES), ("space", C.SPACES), ("blend", C.BLENDS),
                             ("anim", C.ANIMS), ("offscreen", C.OFFSCREEN)):
            if c[key] not in allowed:
                h.bad_choice(who, key, c[key], allowed)
                c[key] = allowed[0]
        self.local = c["space"] == "local"
        self.layer = int(c["layer"])
        self.fixed = bool(c["fixed"])
        self.life = self._conv("life", "range")
        if self.life[1] <= 0:
            h.warn(("life", self.name), f"{who} has life={c['life']!r}", "particles must live longer than 0 seconds, using (0.5, 1.0)")
            c["life"] = (0.5, 1.0)
            self.life = (0.5, 1.0)
        self.size = self._conv("size", "range")
        self.speed = self._conv("speed", "range")
        self.angle = self._conv("angle", "range")
        self.rot = self._conv("rotation", "range")
        self.spin = self._conv("spin", "range")
        self.accel = self._conv("accel", "vec")
        self.wind = self._conv("wind", "vec")
        self.offset = self._conv("offset", "vec")
        self.arc = self._conv("arc", "vec")
        self.radius = self._conv("radius", "vec")
        self.inner = self._conv("inner", "num")
        self.gravity = self._conv("gravity", "num")
        self.drag = self._conv("drag", "num")
        self.stretch = self._conv("stretch", "num")
        self.align = bool(c["align"]) or self.stretch > 0
        self.rate = self._conv("rate", "num")
        self.spread = self._conv("spread", "num")
        outward = c["outward"]
        self.outward = 1 if outward is True else (-1 if outward < 0 else (1 if outward else 0))
        S = C.LUT
        try:
            rgba = C.gradient(c["color"], S)
        except (ValueError, TypeError) as e:
            h.bad_value(who, "color", c["color"], "a color or a list of colors", "color=['yellow', 'orange', (80, 10, 0)]")
            c["color"] = (255, 255, 255)
            rgba = C.gradient(c["color"], S)
        inten = float(c["intensity"])
        alpha = C.curve(c["alpha_curve"], S) * float(c["opacity"])
        sizec = np.maximum(C.curve(c["size_curve"], S), 0.0)
        self.lut = np.empty((S, 5), np.float32)
        self.lut[:, :3] = rgba[:, :3] * inten
        self.lut[:, 3] = np.clip(rgba[:, 3] * alpha, 0.0, 1.0)
        self.lut[:, 4] = sizec
        self.lut2 = None
        if c["color2"] is not None:
            try:
                self.lut2 = C.gradient(c["color2"], S)[:, :3] * inten
            except (ValueError, TypeError):
                h.bad_value(who, "color2", c["color2"], "a color or a list of colors", "color2='cyan'")
        self.pal = None
        if c["palette"]:
            try:
                self.pal = np.array([C.to_rgba(p)[:3] for p in c["palette"]], np.float32) * inten
            except (ValueError, TypeError):
                h.bad_value(who, "palette", c["palette"], "a list of colors", "palette=['red', 'gold', 'cyan']")
        self.cvar = float(c["color_var"])
        self.tex = None
        self.uv = None
        self.cols = self.rows = self.frames = 1
        smooth = bool(c["smooth"])
        tx = c["texture"]
        asp = c["aspect"]
        if tx:
            tex = self.sys.load_texture(tx, smooth)
            if tex is None:
                h.error(("tex", tx), f"texture '{tx}' for {who} was not found",
                        "the built-in shape is used instead", "put the image into assets/ (subfolders are searched), extension is optional")
            else:
                self.tex = tex
                self.uv = (0.0, 0.0, 1.0, 1.0)
                sh = c["sheet"]
                if sh is not None:
                    ok = isinstance(sh, (list, tuple)) and len(sh) == 2 and all(isinstance(i, int) and i > 0 for i in sh)
                    if ok:
                        self.cols, self.rows = sh
                        self.frames = self.cols * self.rows
                    else:
                        h.bad_value(who, "sheet", sh, "(columns, rows)", "sheet=(4, 4)")
                if not asp:
                    asp = (tex.size[0] / self.cols) / (tex.size[1] / self.rows)
        if self.tex is None:
            self.tex = self.sys.renderer.atlas
            self.uv = self.sys.renderer.uv[c["sprite"]]
        self.asp = max(0.05, float(asp)) if asp else 1.0
        self.fps = float(c["anim_fps"])
        sc_max = float(self.lut[:, 4].max())
        self._margin = self.size[1] * sc_max * max(1.0, 1.0 / self.asp) * 1.6 + 6.0 + self.stretch * (self.speed[1] + 120.0)
        att = []
        for a in c["attractors"]:
            if isinstance(a, dict):
                att.append(a)
            else:
                t = tuple(a)
                att.append({"pos": (t[0], t[1]), "strength": t[2] if len(t) > 2 else 100.0, "radius": t[3] if len(t) > 3 else 0.0})
        self._att = att
        cols = []
        for col in c["colliders"]:
            kind = col[0]
            if kind == "rect" and len(col) == 5:
                x0, y0, x1, y1 = (float(v) for v in col[1:])
                cols.append(("rect", min(x0, x1), min(y0, y1), max(x0, x1), max(y0, y1)))
            elif kind == "circle" and len(col) == 4:
                cols.append(("circle", float(col[1]), float(col[2]), float(col[3])))
            else:
                h.bad_value(who, "colliders", col, "('rect', x0, y0, x1, y1) or ('circle', x, y, r)", "colliders=[('rect', -50, 0, 50, 20)]")
        self._cols = cols
        sched = [(float(t), int(k)) for t, k in c["bursts"]]
        if c["burst"] > 0:
            sched.append((0.0, int(c["burst"])))
        sched.sort(key=lambda s: s[0])
        self._sched = sched
        self._bi = min(self._bi, len(sched))
        pts = []
        for p in c["points"]:
            pts.append((float(p[0]), float(p[1])))
        self._pts = np.array(pts, np.float32) if pts else None
        if c["shape"] == "points" and self._pts is None:
            h.warn(("points", self.name), f"{who} uses shape='points' without any points", "pass points=[(0, 0), (20, 10), ...]")
        if self.rate <= 0 and not sched and self.owner is None and not c["rate_distance"]:
            h.tip(("norate", self.name), f"{who} has rate=0 and no bursts, it will never emit by itself",
                  "call emitter.emit(20) when you want particles, or set rate= / burst=")
        if self.local and (self._cols or c["floor"] is not None or c["collide_sprites"]):
            h.tip(("localcol", self.name), f"{who} uses collisions with space='local'", "collisions only work in world space, they are ignored")

    def set(self, **kw):
        self.apply(kw)
        self.sys.make_children(self)
        return self

    def move(self, x, y):
        self.x, self.y = float(x), float(y)
        return self

    def teleport(self, x, y):
        self.x, self.y = float(x), float(y)
        self._o = self._origin()
        return self

    def follow(self, obj, offset=None, rotate=None):
        if obj is not None and not (hasattr(obj, "center") or hasattr(obj, "x") or hasattr(obj, "pos")):
            self.sys.hints.warn(("follow", self.name), f"emitter '{self.name}'.follow() got {obj!r}",
                                "it needs an object with .center, .pos or .x/.y, like a sprite")
            return self
        self.target = obj
        if offset is not None:
            self.cfg["offset"] = (float(offset[0]), float(offset[1]))
            self.offset = self.cfg["offset"]
        if rotate is not None:
            self.cfg["rotate_with"] = bool(rotate)
        return self

    def play(self):
        self.emitting = True
        self.time = 0.0
        self._bi = 0
        self._acc = 0.0
        return self

    def stop(self):
        self.emitting = False
        return self

    def pause(self):
        self.paused = True
        return self

    def resume(self):
        self.paused = False
        return self

    def emit(self, count=1):
        self._spawn(self._count(count), 1.0, 0.0, self._o, self._o)
        return self

    def clear(self):
        self.n = 0
        self._sync()
        return self

    def destroy(self):
        self.alive = False
        return self

    def _count(self, k):
        return int(k * self.sys.quality + self.sys.rng.random())

    def _r(self, rg, k):
        if rg[0] == rg[1]:
            return np.full(k, rg[0], np.float32)
        return self.sys.rng.uniform(rg[0], rg[1], k).astype(np.float32)

    def _rot_deg(self):
        t = self.target
        if t is not None and self.cfg["rotate_with"]:
            return float(getattr(t, "rotation", getattr(t, "angle", 0.0)))
        return 0.0

    def _origin(self):
        ox, oy = self.offset
        a = self._rot_deg()
        if a:
            r = math.radians(a)
            cs, sn = math.cos(r), math.sin(r)
            ox, oy = ox * cs - oy * sn, ox * sn + oy * cs
        return (self.x + ox, self.y + oy)

    def _follow(self):
        t = self.target
        if t is not None:
            if not getattr(t, "alive", True):
                self.target = None
                if self.cfg["stop_with_target"]:
                    self.emitting = False
            else:
                c = getattr(t, "center", None)
                if c is None:
                    c = getattr(t, "pos", None)
                if c is None:
                    c = (t.x, t.y)
                self.x, self.y = float(c[0]), float(c[1])
                return
        fc = self.cfg["follow_camera"]
        if fc and not self.fixed:
            vx, vy, hw, hh = self.sys.view_box()
            cy = vy + hh if fc == "top" else (vy - hh if fc == "bottom" else vy)
            self.x, self.y = vx, cy

    def update(self, dt):
        if not self._alive or self.paused:
            return
        if self.owner is not None:
            if not self.owner.alive and self.n == 0:
                self.alive = False
                return
        dt *= self.cfg["time_scale"]
        if dt <= 0:
            return
        self._follow()
        if self._delay > 0:
            self._delay -= dt
            self._o = self._origin()
            if self._delay > 0:
                return
            dt = -self._delay
            self._delay = 0.0
            if dt <= 0:
                return
        if self.cfg["offscreen"] == "pause" and self.n == 0 and not self.sys.near_view(self._o, 600.0, self.fixed):
            self._o = self._origin()
            return
        if not self._started:
            self._started = True
            self._o = self._origin()
            pw = min(float(self.cfg["prewarm"]), 12.0)
            while pw > 1e-6:
                s = min(STEP, pw)
                self._advance(s, self._o)
                pw -= s
        self._advance(dt, self._origin())
        if self.cfg["auto_remove"] and not self.emitting and self.n == 0 and self.owner is None and not self._kids_busy():
            self.alive = False

    def _kids_busy(self):
        for lst in (self.child_death, self.child_trail):
            if lst:
                for k in lst:
                    if k.n or k._kids_busy():
                        return True
        return False

    def _advance(self, dt, o1):
        o0 = self._o
        parts = int(dt / STEP) + 1
        sdt = dt / parts
        for i in range(parts):
            a = (o0[0] + (o1[0] - o0[0]) * i / parts, o0[1] + (o1[1] - o0[1]) * i / parts)
            b = (o0[0] + (o1[0] - o0[0]) * (i + 1) / parts, o0[1] + (o1[1] - o0[1]) * (i + 1) / parts)
            self._physics(sdt, b)
            self._emit(sdt, a, b)
        self._o = o1
        self._sync()

    def _physics(self, dt, ob):
        self._clock += dt
        n = self.n
        if n == 0:
            return
        c = self.cfg
        a = self.d[:, :n]
        x, y, vx, vy = a[X], a[Y], a[VX], a[VY]
        local = self.local
        cx, cy = (0.0, 0.0) if local else ob
        ax = self.accel[0]
        ay = self.accel[1] - self.gravity
        if ax:
            vx += ax * dt
        if ay:
            vy += ay * dt
        radial, tangent = float(c["radial"]), float(c["tangent"])
        if radial or tangent:
            dx = x - cx
            dy = y - cy
            r = np.hypot(dx, dy) + 1e-3
            rad, tan = radial * dt, tangent * dt
            vx += dx / r * rad - dy / r * tan
            vy += dy / r * rad + dx / r * tan
        turb = float(c["turbulence"])
        if turb:
            s = float(c["turb_scale"])
            tt = self._clock * float(c["turb_speed"])
            ph = a[SEED]
            k = turb * dt
            vx += np.sin(y * s + tt + ph) * k
            vy += np.cos(x * s - tt * 1.3 + ph * 1.7) * k
        for at in self._att:
            tgt = at.get("target")
            p = at.get("pos")
            if tgt is not None:
                if not getattr(tgt, "alive", True):
                    continue
                p = getattr(tgt, "center", None)
                if p is None:
                    p = (tgt.x, tgt.y)
            if p is None:
                continue
            px = float(p[0]) - (ob[0] if local else 0.0)
            py = float(p[1]) - (ob[1] if local else 0.0)
            dx = px - x
            dy = py - y
            dist = np.hypot(dx, dy) + 1e-3
            st = float(at.get("strength", 100.0))
            rad = float(at.get("radius", 0.0))
            f = st * dt / dist if rad <= 0 else st * dt * np.clip(1.0 - dist / rad, 0.0, 1.0) / dist
            vx += dx * f
            vy += dy * f
        wx, wy = self.wind
        if wx or wy:
            w = 1.0 - math.exp(-float(c["wind_drag"]) * dt)
            if wx:
                vx += (wx - vx) * w
            if wy:
                vy += (wy - vy) * w
        if self.drag > 0:
            f = math.exp(-self.drag * dt)
            vx *= f
            vy *= f
        ms = float(c["max_speed"])
        if ms > 0:
            k = np.minimum(1.0, ms / (np.hypot(vx, vy) + 1e-6))
            vx *= k
            vy *= k
        x += vx * dt
        y += vy * dt
        a[ROT] += a[SPIN] * dt
        a[AGE] += dt
        if not local:
            self._collide(a, x, y, vx, vy)
        if self.child_trail is not None and self.cfg["trail_rate"] > 0:
            self._trail(dt, x, y, vx, vy, a)
        keep = a[AGE] < a[LIFE]
        if not keep.all():
            if self.child_death is not None:
                dead = ~keep
                cnt = max(1, int(self.cfg["on_death_count"]))
                inh = float(self.cfg["on_death_inherit"])
                for kid in self.child_death:
                    kid.spawn_at(x[dead], y[dead], vx[dead], vy[dead], cnt, inh, a[R0][dead] if kid.cfg["inherit_color"] else None)
            k = int(np.count_nonzero(keep))
            self.d[:, :k] = a[:, keep]
            self.n = k

    def _collide(self, a, x, y, vx, vy):
        c = self.cfg
        bn = float(c["bounce"])
        kill = bool(c["kill_on_hit"])
        fl = c["floor"]
        if fl is not None:
            fl = float(fl)
            hit = y < fl
            if hit.any():
                if kill:
                    a[AGE][hit] = a[LIFE][hit]
                else:
                    y[hit] = fl + (fl - y[hit]) * bn
                    vy[hit] *= -bn
                    vx[hit] *= 1.0 - float(c["floor_friction"])
        rects = list(self._cols)
        if c["collide_sprites"]:
            rects += [("rect",) + r for r in self.sys.solid_rects()]
        for col in rects:
            if col[0] == "rect":
                _, x0, y0, x1, y1 = col
                inside = (x > x0) & (x < x1) & (y > y0) & (y < y1)
                if not inside.any():
                    continue
                idx = np.flatnonzero(inside)
                if kill:
                    a[AGE][idx] = a[LIFE][idx]
                    continue
                px, py = x[idx], y[idx]
                dl, dr, db, du = px - x0, x1 - px, py - y0, y1 - py
                m = np.minimum(np.minimum(dl, dr), np.minimum(db, du))
                left = dl == m
                right = (dr == m) & ~left
                bottom = (db == m) & ~left & ~right
                top = ~(left | right | bottom)
                nx, ny = x[idx], y[idx]
                nvx, nvy = vx[idx], vy[idx]
                nx[left] = x0
                nx[right] = x1
                ny[bottom] = y0
                ny[top] = y1
                nvx[left | right] *= -bn
                nvy[bottom | top] *= -bn
                x[idx], y[idx], vx[idx], vy[idx] = nx, ny, nvx, nvy
            else:
                _, ccx, ccy, rr = col
                dx, dy = x - ccx, y - ccy
                dist = np.hypot(dx, dy)
                inside = dist < rr
                if not inside.any():
                    continue
                idx = np.flatnonzero(inside)
                if kill:
                    a[AGE][idx] = a[LIFE][idx]
                    continue
                d = dist[idx] + 1e-6
                nx_, ny_ = dx[idx] / d, dy[idx] / d
                x[idx] = ccx + nx_ * rr
                y[idx] = ccy + ny_ * rr
                vn = vx[idx] * nx_ + vy[idx] * ny_
                refl = np.where(vn < 0, (1.0 + bn) * vn, 0.0)
                vx[idx] -= refl * nx_
                vy[idx] -= refl * ny_

    def _trail(self, dt, x, y, vx, vy, a):
        p = float(self.cfg["trail_rate"]) * dt * self.sys.quality
        whole = int(p)
        frac = p - whole
        cnt = np.full(len(x), whole, np.int32)
        if frac > 0:
            cnt += (self.sys.rng.random(len(x)) < frac).astype(np.int32)
        idx = np.repeat(np.arange(len(x)), cnt)
        if len(idx) == 0:
            return
        for kid in self.child_trail:
            kid.spawn_at(x[idx], y[idx], vx[idx], vy[idx], 1, 0.0, a[R0][idx] if kid.cfg["inherit_color"] else None)

    def spawn_at(self, px, py, pvx, pvy, each, inherit, r0=None):
        k = len(px) * each
        if k == 0:
            return
        if each > 1:
            px, py, pvx, pvy = (np.repeat(v, each) for v in (px, py, pvx, pvy))
            if r0 is not None:
                r0 = np.repeat(r0, each)
        k = self._count(k) if self.sys.quality < 1.0 else k
        if k <= 0:
            return
        k = min(k, len(px))
        self._spawn(k, 1.0, 0.0, None, None, pts=(px[:k], py[:k], pvx[:k] * inherit, pvy[:k] * inherit, None if r0 is None else r0[:k]))

    def _emit(self, dt, oa, ob):
        if not self.emitting:
            return
        c = self.cfg
        dur = float(c["duration"])
        q = self.sys.quality
        rate = self.rate * q
        segs = []
        t = self.time
        rem = dt
        guard = 0
        while rem > 1e-9 and guard < 16:
            guard += 1
            if dur > 0:
                span = max(dur - t, 0.0)
                if span <= rem:
                    segs.append((t, dur, span))
                    rem -= span
                    if c["loop"]:
                        t = 0.0
                        self._bi = 0
                        continue
                    self.emitting = False
                    t = dur
                    rem = 0.0
                    break
            segs.append((t, t + rem, rem))
            t += rem
            rem = 0.0
        self.time = t
        sched = self._sched
        off = 0.0
        for a, b, span in segs:
            while self._bi < len(sched) and sched[self._bi][0] <= b:
                tb, cnt = sched[self._bi]
                self._bi += 1
                self._spawn(self._count(cnt), min(1.0, (off + max(tb - a, 0.0)) / dt), dt, oa, ob)
            if rate > 0 and span > 0:
                self._acc += rate * span
                k = int(self._acc)
                self._acc -= k
                if k:
                    self._spawn(k, (off + self.sys.rng.random(k) * span) / dt, dt, oa, ob)
            off += span
        rd = float(c["rate_distance"])
        if rd > 0 and not self.local:
            dist = math.hypot(ob[0] - oa[0], ob[1] - oa[1])
            self._dacc += dist * rd * q
            k = int(self._dacc)
            self._dacc -= k
            if k:
                self._spawn(k, (np.arange(k) + self.sys.rng.random(k)) / k, dt, oa, ob)
        if sched and dur <= 0 and self.rate <= 0 and self._bi >= len(sched) and rd <= 0:
            self.emitting = False

    def _view_size(self):
        return self.sys.view_extent(self.fixed)

    def _shape(self, k):
        c = self.cfg
        rng = self.sys.rng
        sh = c["shape"]
        fit = c["fit_camera"]
        if sh == "circle":
            rx, ry = self.radius
            r_out = 1.0
            r_in = min(self.inner / max(max(rx, ry), 1e-6), 1.0)
            if c["edge"]:
                r = np.ones(k, np.float32)
            else:
                r = np.sqrt(r_in * r_in + rng.random(k) * (r_out * r_out - r_in * r_in))
            a0, a1 = self.arc
            th = np.radians(a0 + rng.random(k) * (a1 - a0))
            return r * np.cos(th) * rx, r * np.sin(th) * ry
        if sh == "rect":
            if fit:
                w, h = self._view_size()
                w *= 1.3
            else:
                w, h = float(c["width"]), float(c["height"])
            if not c["edge"]:
                return (rng.random(k) - 0.5) * w, (rng.random(k) - 0.5) * h
            per = 2 * (w + h)
            if per <= 0:
                z = np.zeros(k, np.float32)
                return z, z.copy()
            p = rng.random(k) * per
            sx = np.empty(k, np.float32)
            sy = np.empty(k, np.float32)
            m = p < w
            sx[m], sy[m] = p[m] - w / 2, -h / 2
            m = (p >= w) & (p < w + h)
            sx[m], sy[m] = w / 2, p[m] - w - h / 2
            m = (p >= w + h) & (p < 2 * w + h)
            sx[m], sy[m] = w / 2 - (p[m] - w - h), h / 2
            m = p >= 2 * w + h
            sx[m], sy[m] = -w / 2, h / 2 - (p[m] - 2 * w - h)
            return sx, sy
        if sh == "line":
            length = self._view_size()[0] * 1.3 if fit else float(c["length"])
            return (rng.random(k) - 0.5) * length, np.zeros(k, np.float32)
        if sh == "points" and self._pts is not None:
            i = rng.integers(0, len(self._pts), k)
            return self._pts[i, 0], self._pts[i, 1]
        z = np.zeros(k, np.float32)
        return z, z.copy()

    def _spawn(self, k, frac, dt, oa, ob, pts=None):
        sysm = self.sys
        k = int(min(k, sysm.max_total - sysm.total))
        mx = int(self.cfg["max"])
        if mx:
            k = min(k, mx - self.n)
        if k <= 0:
            return
        self._ensure(self.n + k)
        rng = sysm.rng
        c = self.cfg
        f = np.full(k, frac, np.float32) if np.isscalar(frac) else np.asarray(frac, np.float32)[:k]
        sx, sy = self._shape(k)
        base = self._rot_deg()
        sa = math.radians(float(c["shape_angle"]) + base)
        if sa:
            cs, sn = math.cos(sa), math.sin(sa)
            sx, sy = sx * cs - sy * sn, sx * sn + sy * cs
        th = 0.0
        if self.outward:
            th = np.where((sx == 0) & (sy == 0), rng.random(k) * TAU, np.arctan2(sy, sx))
            if self.outward < 0:
                th = th + math.pi
        ang = np.radians(self._r(self.angle, k) + base) + th + np.radians((rng.random(k) - 0.5) * self.spread)
        spd = self._r(self.speed, k)
        vx = np.cos(ang) * spd
        vy = np.sin(ang) * spd
        r0 = None
        if pts is not None:
            px = pts[0][:k] + sx
            py = pts[1][:k] + sy
            vx = vx + pts[2][:k]
            vy = vy + pts[3][:k]
            r0 = pts[4]
        elif self.local:
            px, py = sx, sy
        else:
            px = oa[0] + (ob[0] - oa[0]) * f + sx
            py = oa[1] + (ob[1] - oa[1]) * f + sy
            inh = float(c["inherit"])
            if inh and dt > 0:
                vx = vx + (ob[0] - oa[0]) / dt * inh
                vy = vy + (ob[1] - oa[1]) / dt * inh
        life = np.maximum(self._r(self.life, k), 1e-3)
        age = np.minimum((1.0 - f) * dt, life * 0.99)
        px = px + vx * age
        py = py + vy * age
        i0 = self.n
        i1 = i0 + k
        d = self.d
        d[X, i0:i1] = px
        d[Y, i0:i1] = py
        d[VX, i0:i1] = vx
        d[VY, i0:i1] = vy
        d[AGE, i0:i1] = age
        d[LIFE, i0:i1] = life
        d[ROT, i0:i1] = np.radians(self._r(self.rot, k))
        d[SPIN, i0:i1] = np.radians(self._r(self.spin, k))
        d[SEED, i0:i1] = rng.random(k) * TAU
        d[SZ, i0:i1] = self._r(self.size, k)
        d[R0, i0:i1] = rng.random(k) if r0 is None else np.asarray(r0, np.float32)[:k]
        d[R1, i0:i1] = rng.random(k)
        d[R2, i0:i1] = rng.random(k)
        self.n = i1
        self._sync()

    def _ensure(self, need):
        if need <= self.cap:
            return
        new = max(self.cap * 2, need + 16)
        nd = np.zeros((NC, new), np.float32)
        nd[:, :self.n] = self.d[:, :self.n]
        self.d = nd
        self.cap = new
        self._inst = None

    def prepare(self, vr):
        n = self.n
        if n == 0 or not self.visible:
            return None
        a = self.d[:, :n]
        ox, oy = self._o if self.local else (0.0, 0.0)
        x, y = a[X], a[Y]
        m = self._margin
        if x.max() + ox + m < vr[0] or x.min() + ox - m > vr[2] or y.max() + oy + m < vr[1] or y.min() + oy - m > vr[3]:
            return None
        if self._inst is None or len(self._inst) < n:
            self._inst = np.empty((self.cap, 13), np.float32)
        out = self._inst[:n]
        t = a[AGE] / a[LIFE]
        u = np.minimum((t * C.LUT).astype(np.int32), C.LUT - 1)
        L = self.lut[u]
        rgb = L[:, :3]
        if self.lut2 is not None:
            rgb = rgb + (self.lut2[u] - rgb) * a[R0][:, None]
        if self.pal is not None:
            rgb = rgb * self.pal[(a[R0] * len(self.pal)).astype(np.int32) % len(self.pal)]
        if self.cvar:
            rgb = rgb * (1.0 + (a[R1] - 0.5) * 2.0 * self.cvar)[:, None]
        out[:, 9:12] = rgb
        out[:, 12] = L[:, 3]
        sz = a[SZ] * L[:, 4]
        vx, vy = a[VX], a[VY]
        w = sz
        rot = a[ROT]
        if self.align:
            if self.stretch:
                w = sz + np.hypot(vx, vy) * self.stretch
            rot = rot + np.arctan2(vy, vx)
        out[:, 0] = x + ox
        out[:, 1] = y + oy
        out[:, 2] = w
        out[:, 3] = sz / self.asp
        out[:, 4] = rot
        if self.frames > 1 and self.cfg["anim"] != "none":
            fr = self.frames
            mode = self.cfg["anim"]
            if mode == "life":
                f = np.minimum((t * fr).astype(np.int32), fr - 1)
            elif mode == "loop":
                f = (a[AGE] * self.fps + a[R2] * fr).astype(np.int32) % fr
            else:
                f = (a[R2] * fr).astype(np.int32) % fr
            cw = 1.0 / self.cols
            ch = 1.0 / self.rows
            fx = (f % self.cols).astype(np.float32)
            fy = (f // self.cols).astype(np.float32)
            out[:, 5] = fx * cw
            out[:, 7] = (fx + 1.0) * cw
            top = 1.0 - fy * ch
            out[:, 8] = top
            out[:, 6] = top - ch
        else:
            out[:, 5:9] = self.uv
        return (self.cfg["blend"], self.tex, out)
