import math
import sys

import numpy as np

from . import config as C
from . import presets as P
from .emitter import Emitter
from .hints import Hints
from .render import Renderer


class View:
    def __init__(self):
        self.x = 0.0
        self.y = 0.0
        self.zoom = 1.0
        self.rotation = 0.0

    def look_at(self, x, y):
        self.x, self.y = float(x), float(y)
        return self

    def set(self, x=None, y=None, zoom=None, rotation=None):
        if x is not None:
            self.x = float(x)
        if y is not None:
            self.y = float(y)
        if zoom is not None:
            self.zoom = float(zoom)
        if rotation is not None:
            self.rotation = float(rotation)
        return self


class FX:
    def __init__(self, emitters):
        self.emitters = list(emitters)

    @property
    def alive(self):
        return any(e.alive for e in self.emitters)

    @property
    def count(self):
        return sum(e.n for e in self.emitters)

    @property
    def visible(self):
        return any(e.visible for e in self.emitters)

    @visible.setter
    def visible(self, value):
        for e in self.emitters:
            e.visible = bool(value)

    def _each(self, name, *args, **kwargs):
        for e in self.emitters:
            if e.owner is None:
                getattr(e, name)(*args, **kwargs)
        return self

    def set(self, **kw):
        return self._each("set", **kw)

    def move(self, x, y):
        return self._each("move", x, y)

    def teleport(self, x, y):
        return self._each("teleport", x, y)

    def follow(self, obj, offset=None, rotate=None):
        return self._each("follow", obj, offset, rotate)

    def play(self):
        return self._each("play")

    def stop(self):
        return self._each("stop")

    def pause(self):
        return self._each("pause")

    def resume(self):
        return self._each("resume")

    def emit(self, count=1):
        return self._each("emit", count)

    def clear(self):
        return self._each("clear")

    def destroy(self):
        return self._each("destroy")


class ParticleSystem:
    def __init__(self, engine):
        self.engine = engine
        self.hints = Hints(engine)
        self.renderer = Renderer(engine.ctx)
        self.rng = np.random.default_rng()
        self.emitters = []
        self.total = 0
        self.max_total = max(64, int(engine.cfg.get("max_particles", 50000)))
        self.quality = max(0.0, float(engine.cfg.get("particle_quality", 1.0)))
        self.registry = dict(P.REGISTRY)
        self.view = View()
        self.use_sm_camera = True
        self.time_scale = 1.0
        self.paused = False
        self.frame = 0
        self.stats = (0, 0)
        self._watch = []
        self._rects = None
        self._sm_bound = False
        self._sm_ref = None
        self.sprite_fx = None
        e = engine
        e.on("update", self._on_update, priority=-60)
        e.on("draw", self._draw_below, priority=60)
        e.on("draw", self._draw_above, priority=40)

    def shutdown(self):
        sm = self._sm()
        if sm is not None and hasattr(sm, "unregister_param"):
            sm.unregister_param("fx")
        self.emitters.clear()
        self.renderer.release()

    def seed(self, value):
        self.rng = np.random.default_rng(value)
        return self

    def _sm(self):
        lib = self.engine.get_lib("SpriteManager")
        return getattr(lib, "MANAGER", None) if lib else None

    def bind_sprite_manager(self):
        sm = self._sm()
        if sm is None or self._sm_bound:
            return
        self._sm_bound = True
        mod = sys.modules.get("SpriteManager.sprite")
        if mod is not None and self.sprite_fx is not None:
            try:
                self.engine.add_method(mod.Sprite, "fx", self.sprite_fx, owner="Particular")
            except AttributeError:
                pass
        if hasattr(sm, "register_param"):
            sm.register_param("fx", "effects", "particle preset(s) attached to it", self._param_fx)
        self.hints.tip("sm", "SpriteManager detected",
                       "particles now use its camera, sprite.fx('fire') and engine.sprite(..., fx='fire') are available",
                       "emitters follow sprites and stop when the sprite is destroyed")

    def _param_fx(self, sprite, value):
        items = value if isinstance(value, (list, tuple)) and not (len(value) == 2 and isinstance(value[1], dict)) else [value]
        for it in items:
            if isinstance(it, dict):
                spec = it.get("preset", it.get("spec"))
                kw = {k: v for k, v in it.items() if k not in ("preset", "spec")}
                self.attach(sprite, spec, **kw)
            else:
                self.attach(sprite, it)

    def view_state(self, fixed=False):
        if fixed:
            return (0.0, 0.0, 1.0, 0.0)
        if self.use_sm_camera:
            sm = self._sm()
            if sm is not None and sm.camera is not None:
                c = sm.camera
                return (c.vx, c.vy, c.vzoom, c.vrot)
        v = self.view
        return (v.x, v.y, v.zoom, math.radians(v.rotation))

    def view_extent(self, fixed=False):
        w, h = self.engine.screen_size
        if fixed:
            return (float(w), float(h))
        vx, vy, z, r = self.view_state()
        z = z if z else 1.0
        hw, hh = w / z, h / z
        if r:
            c, s = abs(math.cos(r)), abs(math.sin(r))
            hw, hh = hw * c + hh * s, hw * s + hh * c
        return (hw, hh)

    def view_box(self):
        vx, vy, z, r = self.view_state()
        hw, hh = self.view_extent()
        return (vx, vy, hw / 2.0, hh / 2.0)

    def view_rect(self, fixed=False):
        if fixed:
            w, h = self.engine.screen_size
            return (-w / 2.0, -h / 2.0, w / 2.0, h / 2.0)
        vx, vy, hw, hh = self.view_box()
        return (vx - hw, vy - hh, vx + hw, vy + hh)

    def near_view(self, pos, margin, fixed=False):
        r = self.view_rect(fixed)
        return r[0] - margin <= pos[0] <= r[2] + margin and r[1] - margin <= pos[1] <= r[3] + margin

    def solid_rects(self):
        if self._rects is None:
            sm = self._sm()
            self._rects = [s.rect() for s in sm.solids if s.alive] if sm is not None else []
        return self._rects

    def load_texture(self, name, smooth=True):
        try:
            return self.engine.texture(name, smooth=smooth)
        except RuntimeError:
            self.hints.error("thread", "particles with a texture must be created in the main thread")
            return None

    @property
    def count(self):
        return self.total

    def register(self, name, spec, cat="custom", doc="", oneshot=False):
        self.registry[name] = {"cat": cat, "doc": doc, "oneshot": oneshot, "spec": spec}
        return self

    def categories(self):
        out = {}
        for name, e in self.registry.items():
            out.setdefault(e["cat"], []).append(name)
        return out

    def list(self, category=None, show=True):
        cats = self.categories()
        if category is not None:
            if category not in cats:
                near = C.close(category, cats)
                self.hints.warn(("cat", category), f"no category '{category}'",
                                ("did you mean: " + ", ".join(near)) if near else "categories: " + ", ".join(cats))
                return []
            cats = {category: cats[category]}
        names = [n for v in cats.values() for n in v]
        if show and self.hints.on:
            log = self.engine.log
            for cat, items in cats.items():
                log(f"[Particular] {cat}: " + ", ".join(items), (255, 205, 120))
        return names

    def help(self):
        self.hints.help_options()
        self.hints.tip("help2", "quick reference",
                       "engine.fx('fire', x, y)  loops until .stop();  engine.fx('explosion', x, y)  plays once",
                       "engine.fx('fire', x, y, scale=2, hue=0.5, amount=0.5)  tweaks any preset",
                       "sprite.fx('torch')  attaches to a sprite;  engine.particles().list()  shows presets")

    def _resolve(self, spec, depth=0):
        if depth > 8:
            return [], False
        if isinstance(spec, str):
            entry = self.registry.get(spec)
            if entry is None:
                self.hints.preset_missing(spec, self.registry)
                return [], False
            cfgs, os_ = self._resolve(entry["spec"], depth + 1)
            return cfgs, entry["oneshot"] or os_
        if isinstance(spec, (list, tuple)):
            out, os_ = [], False
            for s in spec:
                c, o = self._resolve(s, depth + 1)
                out += c
                os_ = os_ or o
            return out, os_
        if isinstance(spec, dict):
            spec = dict(spec)
            base = spec.pop("base", None)
            os_ = bool(spec.pop("_oneshot", False))
            mods = spec.pop("_mods", None)
            if base is None:
                return [spec], os_
            bases, bos = self._resolve(base, depth + 1)
            if mods:
                bases = [C.modify(b, mods) for b in bases]
            return [{**b, **spec} for b in bases], os_ or bos
        self.hints.bad_value("fx", "preset", spec, "a preset name, a dict or a list of them", "engine.fx('fire', 0, 0)")
        return [], False

    @staticmethod
    def _to_oneshot(cfg):
        c = dict(cfg)
        if not c.get("burst") and not c.get("bursts"):
            life = c.get("life", C.DEFAULTS["life"])
            lm = sum(life) / 2 if isinstance(life, (tuple, list)) else float(life)
            c["burst"] = max(1, int(float(c.get("rate", C.DEFAULTS["rate"])) * lm))
        c["rate"] = 0
        c["rate_distance"] = 0
        c["loop"] = False
        c["duration"] = 0.0
        return c

    @staticmethod
    def _total(c):
        return int(c.get("burst", 0)) + sum(int(n) for _, n in c.get("bursts", ()))

    def _make(self, spec, x, y, kw, oneshot=None, count=None):
        mods = {k: kw.pop(k) for k in list(kw) if k in C.MODIFIERS}
        name = kw.pop("name", None)
        on_finish = kw.pop("on_finish", None)
        target = kw.pop("follow", None)
        if target is None:
            target = kw.pop("target", None)
        visible = kw.pop("visible", True)
        cfgs, os_ = self._resolve(spec)
        if not cfgs:
            return None
        if oneshot is None:
            oneshot = os_
        if oneshot:
            cfgs = [self._to_oneshot(c) for c in cfgs]
            if count is not None:
                first = self._total(cfgs[0])
                ratio = count / first if first > 0 else 1.0
                if first <= 0:
                    cfgs[0]["burst"] = int(count)
                    ratio = 1.0
                mods["amount"] = mods.get("amount", 1.0) * ratio
        label = name or (spec if isinstance(spec, str) else "fx")
        made = []
        for cfg in cfgs:
            cfg = C.modify(cfg, mods)
            cfg.update(kw)
            if oneshot:
                cfg["rate"] = 0
            em = Emitter(self, cfg, x, y, label)
            em.mods = mods
            em.visible = bool(visible)
            self.emitters.append(em)
            self.make_children(em)
            made.append(em)
        if target is not None:
            for em in made:
                em.follow(target)
        out = made[0] if len(made) == 1 else FX(made)
        if on_finish is not None:
            self._watch.append((out, on_finish))
        return out

    def make_children(self, em):
        c = em.cfg
        for key, attr in (("on_death", "child_death"), ("trail", "child_trail")):
            spec = c.get(key)
            if spec is None or getattr(em, attr) is not None or em.depth >= 3:
                continue
            cfgs, _ = self._resolve(spec)
            kids = []
            for cfg in cfgs:
                cc = C.modify(cfg, em.mods)
                cc.update(rate=0, burst=0, bursts=(), duration=0.0, loop=False, auto_remove=False, space="world",
                          prewarm=0.0, follow_camera=None, delay=0.0, rate_distance=0.0)
                k = Emitter(self, cc, em.x, em.y, f"{em.name}.{key}", owner=em, depth=em.depth + 1)
                k.emitting = False
                k.mods = em.mods
                self.emitters.append(k)
                self.make_children(k)
                kids.append(k)
            setattr(em, attr, kids)

    def fx(self, spec, x=0.0, y=0.0, **kw):
        return self._make(spec, x, y, kw)

    def burst(self, spec, x=0.0, y=0.0, count=None, **kw):
        return self._make(spec, x, y, kw, True, count)

    def loop(self, spec, x=0.0, y=0.0, **kw):
        return self._make(spec, x, y, kw, False)

    def attach(self, target, spec, offset=None, **kw):
        c = getattr(target, "center", None)
        if c is None:
            c = getattr(target, "pos", None)
        if c is None:
            c = (getattr(target, "x", 0.0), getattr(target, "y", 0.0))
        if offset is not None:
            kw["offset"] = offset
        out = self._make(spec, c[0], c[1], kw)
        if out is not None:
            out.follow(target)
        return out

    def play(self, spec, x=0.0, y=0.0, **kw):
        return self._make(spec, x, y, kw)

    def stop(self):
        for e in self.emitters:
            if e.owner is None:
                e.stop()
        return self

    def clear(self):
        for e in list(self.emitters):
            e.destroy()
        self.emitters = []
        return self

    def pause(self):
        self.paused = True
        return self

    def resume(self):
        self.paused = False
        return self

    def __getattr__(self, name):
        if name.startswith("_") or name == "registry":
            raise AttributeError(name)
        reg = self.__dict__.get("registry")
        if reg is not None and name in reg:
            return lambda x=0.0, y=0.0, **kw: self._make(name, x, y, kw)
        raise AttributeError(f"'ParticleSystem' has no attribute or preset '{name}'")

    def _on_update(self, state):
        self.frame += 1
        if not self._sm_bound:
            self.bind_sprite_manager()
        dt = min(state["dt"], 0.1) * self.time_scale
        if self.paused:
            dt = 0.0
        self._rects = None
        for e in list(self.emitters):
            e.update(dt)
        self.emitters = [e for e in self.emitters if e.alive]
        self.total = sum(e.n for e in self.emitters)
        if self._watch:
            rest = []
            for obj, fn in self._watch:
                if obj.alive:
                    rest.append((obj, fn))
                else:
                    self._call(fn)
            self._watch = rest
        if self.frame == 150 and self.emitters and self.stats[0] == 0 and self.hints.on:
            vx, vy, z, r = self.view_state()
            e0 = self.emitters[0]
            self.hints.warn("invisible", f"{len(self.emitters)} emitters exist but no particles were drawn",
                            f"view center is ({vx:.0f}, {vy:.0f}) zoom {z:.2f}; emitter '{e0.name}' is at ({e0.x:.0f}, {e0.y:.0f})",
                            "y points UP and (0, 0) is the screen center unless a camera moves it",
                            "check rate / burst, blend='add' on a white background, or layer")

    def _call(self, fn):
        try:
            fn()
        except Exception as exc:
            self.engine.log(f"[Particular] ERROR in on_finish: {type(exc).__name__}: {exc}", (255, 85, 85))

    def _gather(self, items, fixed):
        vr = self.view_rect(fixed)
        batches = []
        for e in items:
            b = e.prepare(vr)
            if b is not None:
                batches.append(b)
        return batches

    def _draw_pass(self, items, fixed):
        if not items:
            return 0
        items.sort(key=lambda e: e.layer)
        size = self.engine.screen_size
        batches = self._gather(items, fixed)
        self.renderer.draw(batches, self.view_state(fixed), size)
        return self.renderer.drawn

    def _draw_below(self, state):
        if self.engine.screen_size[0] <= 0:
            return
        items = [e for e in self.emitters if e.n and e.visible and not e.fixed and e.layer < 0]
        self._below = self._draw_pass(items, False)

    def _draw_above(self, state):
        if self.engine.screen_size[0] <= 0:
            return
        items = [e for e in self.emitters if e.n and e.visible and not e.fixed and e.layer >= 0]
        a = self._draw_pass(items, False)
        fixed = [e for e in self.emitters if e.n and e.visible and e.fixed]
        b = self._draw_pass(fixed, True)
        self.stats = (getattr(self, "_below", 0) + a + b, self.renderer.calls)
