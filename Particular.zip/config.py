import colorsys
import difflib
import math

import numpy as np

LUT = 64
BLENDS = ("alpha", "add", "screen", "multiply")
SHAPES = ("point", "circle", "rect", "line", "points")
SPACES = ("world", "local")
SPRITES = ("circle", "soft", "glow", "square", "ring", "star", "spark", "smoke", "flare", "drop", "cross", "hex", "heart", "ray")
ANIMS = ("none", "life", "loop", "random")
OFFSCREEN = ("run", "pause")

DEFAULTS = {
    "rate": 30.0, "burst": 0, "bursts": (), "duration": 0.0, "loop": True, "delay": 0.0, "prewarm": 0.0,
    "max": 0, "time_scale": 1.0, "auto_remove": True, "stop_with_target": True, "rate_distance": 0.0,
    "life": (0.5, 1.0),
    "shape": "point", "radius": 0.0, "inner": 0.0, "width": 0.0, "height": 0.0, "length": 0.0, "edge": False,
    "arc": (0.0, 360.0), "shape_angle": 0.0, "points": (),
    "offset": (0.0, 0.0), "space": "world", "follow_camera": None, "fit_camera": False, "rotate_with": False,
    "fixed": False,
    "angle": 0.0, "spread": 360.0, "outward": 0, "speed": (50.0, 100.0), "inherit": 0.0,
    "gravity": 0.0, "accel": (0.0, 0.0), "drag": 0.0, "wind": (0.0, 0.0), "wind_drag": 1.0,
    "radial": 0.0, "tangent": 0.0, "turbulence": 0.0, "turb_scale": 0.01, "turb_speed": 1.0,
    "attractors": (), "max_speed": 0.0,
    "floor": None, "bounce": 0.4, "floor_friction": 0.2, "colliders": (), "collide_sprites": False,
    "kill_on_hit": False,
    "size": (4.0, 6.0), "size_curve": (1.0, 1.0), "aspect": None, "stretch": 0.0,
    "color": (255, 255, 255), "color2": None, "palette": None, "color_var": 0.0, "intensity": 1.0,
    "alpha_curve": (1.0, 0.0), "opacity": 1.0,
    "sprite": "circle", "texture": None, "sheet": None, "anim": "none", "anim_fps": 12.0, "smooth": True,
    "blend": "alpha", "rotation": 0.0, "spin": 0.0, "align": False,
    "layer": 0, "offscreen": "run",
    "on_death": None, "on_death_count": 1, "on_death_inherit": 0.5, "trail": None, "trail_rate": 0.0,
    "inherit_color": False,
}

DOCS = {
    "rate": ("emission", "particles per second"),
    "burst": ("emission", "particles released at t=0"),
    "bursts": ("emission", "[(time, count), ...] schedule"),
    "duration": ("emission", "seconds of emission, 0 = forever"),
    "loop": ("emission", "restart after duration"),
    "delay": ("emission", "wait before starting"),
    "prewarm": ("emission", "simulate N seconds at start"),
    "max": ("emission", "particle cap of this emitter"),
    "time_scale": ("emission", "slow motion / fast forward"),
    "rate_distance": ("emission", "particles per pixel moved"),
    "auto_remove": ("emission", "delete emitter when finished"),
    "stop_with_target": ("emission", "stop when followed sprite dies"),
    "life": ("lifetime", "seconds, number or (min, max)"),
    "shape": ("spawn", "point circle rect line points"),
    "radius": ("spawn", "circle radius, number or (rx, ry)"),
    "inner": ("spawn", "hollow center of the circle"),
    "width": ("spawn", "rect width"),
    "height": ("spawn", "rect height"),
    "length": ("spawn", "line length"),
    "edge": ("spawn", "spawn on the outline only"),
    "arc": ("spawn", "(from, to) degrees of the circle"),
    "shape_angle": ("spawn", "rotate the spawn shape"),
    "points": ("spawn", "[(x, y), ...] for shape='points'"),
    "offset": ("spawn", "(x, y) from the emitter"),
    "space": ("spawn", "'world' or 'local' (moves with emitter)"),
    "follow_camera": ("spawn", "True/'top'/'bottom': stick to view"),
    "fit_camera": ("spawn", "rect/line covers the whole view"),
    "rotate_with": ("spawn", "turn with the followed sprite"),
    "fixed": ("spawn", "screen space (HUD effects)"),
    "angle": ("motion", "direction in degrees, 90 = up"),
    "spread": ("motion", "cone width in degrees, 360 = all"),
    "outward": ("motion", "1 away from center, -1 toward it"),
    "speed": ("motion", "start speed, number or (min, max)"),
    "inherit": ("motion", "share of emitter velocity"),
    "gravity": ("forces", "pull down, pixels/s^2"),
    "accel": ("forces", "(ax, ay) constant push"),
    "drag": ("forces", "air resistance"),
    "wind": ("forces", "(wx, wy) target air speed"),
    "wind_drag": ("forces", "how fast wind takes over"),
    "radial": ("forces", "push away from center (negative pulls)"),
    "tangent": ("forces", "swirl around the center"),
    "turbulence": ("forces", "noise strength"),
    "turb_scale": ("forces", "noise size, smaller = bigger swirls"),
    "turb_speed": ("forces", "noise animation speed"),
    "attractors": ("forces", "[(x, y, strength, radius)] or dicts"),
    "max_speed": ("forces", "speed limit"),
    "floor": ("collision", "y of an invisible ground"),
    "bounce": ("collision", "bounciness 0..1"),
    "floor_friction": ("collision", "slow down on contact"),
    "colliders": ("collision", "[('rect',x0,y0,x1,y1), ('circle',x,y,r)]"),
    "collide_sprites": ("collision", "bounce off SpriteManager solids"),
    "kill_on_hit": ("collision", "particles die when they hit"),
    "size": ("look", "pixels, number or (min, max)"),
    "size_curve": ("look", "size multiplier over life"),
    "aspect": ("look", "width / height of a particle"),
    "stretch": ("look", "stretch along speed"),
    "color": ("look", "gradient over life"),
    "color2": ("look", "second gradient mixed per particle"),
    "palette": ("look", "random fixed color per particle"),
    "color_var": ("look", "brightness jitter 0..1"),
    "intensity": ("look", "brightness boost (glow)"),
    "alpha_curve": ("look", "opacity over life"),
    "opacity": ("look", "overall opacity"),
    "sprite": ("look", "built-in particle shape"),
    "texture": ("look", "asset name instead of a shape"),
    "sheet": ("look", "(cols, rows) frames of the texture"),
    "anim": ("look", "none, life, loop, random frames"),
    "anim_fps": ("look", "frames per second for loop"),
    "smooth": ("look", "False = crisp pixel filtering"),
    "blend": ("look", "alpha add screen multiply"),
    "rotation": ("look", "start angle, degrees"),
    "spin": ("look", "degrees per second"),
    "align": ("look", "face the direction of travel"),
    "layer": ("look", "draw order, below 0 = under sprites"),
    "offscreen": ("look", "'pause' freezes it when far away"),
    "on_death": ("sub-effects", "preset spawned where a particle dies"),
    "on_death_count": ("sub-effects", "children per dead particle"),
    "on_death_inherit": ("sub-effects", "share of parent velocity"),
    "trail": ("sub-effects", "preset dropped behind particles"),
    "trail_rate": ("sub-effects", "trail spawns per particle per sec"),
    "inherit_color": ("sub-effects", "child takes parent palette pick"),
}

MODIFIERS = {
    "scale": "size, speed, radius, forces x N",
    "amount": "particle count x N",
    "speed_mul": "speed x N",
    "life_mul": "lifetime x N",
    "size_mul": "particle size x N",
    "alpha_mul": "opacity x N",
    "tint": "multiply colors by a color",
    "hue": "shift hue, 0..1 around the wheel",
    "glow": "brightness boost",
}

NAMED = {
    "white": (255, 255, 255), "black": (0, 0, 0), "red": (255, 64, 64), "green": (64, 220, 96),
    "blue": (64, 128, 255), "yellow": (255, 220, 64), "orange": (255, 150, 50), "purple": (170, 90, 255),
    "pink": (255, 120, 190), "cyan": (64, 230, 255), "gray": (128, 128, 128), "grey": (128, 128, 128),
    "brown": (140, 90, 50), "gold": (255, 200, 40),
}


def close(name, options, n=3, cutoff=0.5):
    return difflib.get_close_matches(str(name), [str(o) for o in options], n=n, cutoff=cutoff)


def to_rgba(c):
    if isinstance(c, str):
        v = c.strip().lower()
        if v in NAMED:
            c = NAMED[v]
        elif v.startswith("#"):
            h = v[1:]
            if len(h) in (3, 4):
                h = "".join(ch * 2 for ch in h)
            if len(h) not in (6, 8):
                raise ValueError(f"bad color {c!r}")
            c = tuple(int(h[i:i + 2], 16) for i in range(0, len(h), 2))
        else:
            raise ValueError(f"unknown color {c!r}")
    if not isinstance(c, (list, tuple)) or len(c) not in (3, 4):
        raise ValueError(f"bad color {c!r}")
    vals = [float(x) for x in c]
    if not (any(isinstance(x, float) for x in c) and max(vals) <= 1.0):
        vals = [x / 255.0 for x in vals]
    if len(vals) == 3:
        vals.append(1.0)
    return tuple(min(1.0, max(0.0, x)) for x in vals)


def _is_color(v):
    return isinstance(v, str) or (isinstance(v, (list, tuple)) and len(v) in (3, 4) and all(isinstance(x, (int, float)) for x in v))


def stops(spec):
    if _is_color(spec):
        c = to_rgba(spec)
        return [(0.0, c), (1.0, c)]
    items = list(spec)
    if not items:
        raise ValueError("empty color list")
    if all(isinstance(i, (list, tuple)) and len(i) == 2 and isinstance(i[0], (int, float)) for i in items):
        out = [(float(p), to_rgba(c)) for p, c in items]
        out.sort(key=lambda s: s[0])
        return out
    n = len(items)
    return [(i / max(1, n - 1), to_rgba(c)) for i, c in enumerate(items)]


def gradient(spec, n=LUT):
    st = stops(spec)
    pos = [p for p, _ in st]
    cols = np.array([c for _, c in st], np.float32)
    t = np.linspace(0.0, 1.0, n)
    return np.stack([np.interp(t, pos, cols[:, i]) for i in range(4)], axis=1).astype(np.float32)


def curve(spec, n=LUT):
    if isinstance(spec, (int, float)):
        return np.full(n, float(spec), np.float32)
    items = list(spec)
    if all(isinstance(i, (list, tuple)) and len(i) == 2 for i in items):
        pos = [float(p) for p, _ in items]
        val = [float(v) for _, v in items]
    else:
        val = [float(v) for v in items]
        pos = [i / max(1, len(val) - 1) for i in range(len(val))]
    if len(val) == 1:
        return np.full(n, val[0], np.float32)
    return np.interp(np.linspace(0.0, 1.0, n), pos, val).astype(np.float32)


def as_range(v, name="value"):
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        return (float(v), float(v))
    if isinstance(v, (list, tuple)) and len(v) == 2:
        a, b = float(v[0]), float(v[1])
        return (a, b) if a <= b else (b, a)
    raise ValueError(f"'{name}' must be a number or (min, max), got {v!r}")


def as_vec(v, name="value"):
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        return (float(v), float(v))
    if isinstance(v, (list, tuple)) and len(v) == 2:
        return (float(v[0]), float(v[1]))
    raise ValueError(f"'{name}' must be (x, y), got {v!r}")


def _mul(v, k):
    if isinstance(v, bool):
        return v
    if isinstance(v, (int, float)):
        return v * k
    if isinstance(v, (list, tuple)):
        return type(v)(_mul(i, k) for i in v)
    return v


def _map_colors(spec, fn):
    if spec is None:
        return None
    if _is_color(spec):
        return fn(to_rgba(spec))
    out = []
    for it in spec:
        if isinstance(it, (list, tuple)) and len(it) == 2 and isinstance(it[0], (int, float)):
            out.append((it[0], fn(to_rgba(it[1]))))
        else:
            out.append(fn(to_rgba(it)))
    return out


def modify(cfg, m):
    c = dict(cfg)
    s = m.get("scale")
    if s is not None and s != 1:
        for k in ("radius", "inner", "width", "height", "length", "offset", "size", "speed", "max_speed", "accel",
                  "gravity", "turbulence", "stretch", "wind", "radial", "tangent"):
            if k in c:
                c[k] = _mul(c[k], s)
        if "turb_scale" in c:
            c["turb_scale"] = c["turb_scale"] / s
        if c.get("points"):
            c["points"] = tuple((p[0] * s, p[1] * s) for p in c["points"])
    a = m.get("amount")
    if a is not None and a != 1:
        for k in ("rate", "burst", "trail_rate", "on_death_count", "rate_distance"):
            if k in c:
                c[k] = c[k] * a
        if c.get("bursts"):
            c["bursts"] = tuple((t, max(1, int(round(n * a)))) for t, n in c["bursts"])
        if c.get("max"):
            c["max"] = int(c["max"] * a)
    k = m.get("speed_mul")
    if k is not None and k != 1:
        for key in ("speed", "max_speed", "accel", "turbulence"):
            if key in c:
                c[key] = _mul(c[key], k)
    k = m.get("life_mul")
    if k is not None and k != 1 and "life" in c:
        c["life"] = _mul(c["life"], k)
    k = m.get("size_mul")
    if k is not None and k != 1 and "size" in c:
        c["size"] = _mul(c["size"], k)
    k = m.get("alpha_mul")
    if k is not None and k != 1:
        c["opacity"] = c.get("opacity", 1.0) * k
    if m.get("glow") is not None:
        c["intensity"] = c.get("intensity", 1.0) * m["glow"]
    tint, hue = m.get("tint"), m.get("hue")
    if tint is not None:
        t = to_rgba(tint)
        fn = lambda col: (col[0] * t[0], col[1] * t[1], col[2] * t[2], col[3])
        for key in ("color", "color2", "palette"):
            if c.get(key) is not None:
                c[key] = _map_colors(c[key], fn)
    if hue:
        def shift(col):
            h, sat, v = colorsys.rgb_to_hsv(col[0], col[1], col[2])
            r, g, b = colorsys.hsv_to_rgb((h + hue) % 1.0, sat, v)
            return (r, g, b, col[3])
        for key in ("color", "color2", "palette"):
            if c.get(key) is not None:
                c[key] = _map_colors(c[key], shift)
    return c
